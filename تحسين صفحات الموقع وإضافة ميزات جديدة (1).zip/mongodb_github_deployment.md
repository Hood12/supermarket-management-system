# MongoDB and GitHub Pages Deployment Guide

## MongoDB Setup

### Local Development Setup

1. **Install MongoDB Community Edition**:
   - Download and install from [MongoDB website](https://www.mongodb.com/try/download/community)
   - Or use Docker: `docker run -d -p 27017:27017 --name mongodb mongo:latest`

2. **Update Environment Variables**:
   Create a `.env.local` file in the project root with:
   ```
   MONGODB_URI=mongodb://localhost:27017
   MONGODB_DB=supermarket
   ```

3. **Initialize Database**:
   ```javascript
   // Run this script to initialize your MongoDB database with sample data
   // Save as scripts/init-db.js
   const { MongoClient } = require('mongodb');

   async function initializeDatabase() {
     const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017';
     const client = new MongoClient(uri);
     
     try {
       await client.connect();
       const db = client.db('supermarket');
       
       // Create collections
       await db.createCollection('inventory');
       await db.createCollection('sales');
       await db.createCollection('branches');
       await db.createCollection('users');
       await db.createCollection('suppliers');
       await db.createCollection('notifications');
       
       // Insert sample data
       await db.collection('users').insertMany([
         {
           username: 'admin',
           password: '$2b$10$XpC5nKJ5Ggb4MqOiVVTrI.kJO.JK.j6E9abZcGQd7dULlZjLI9ldy', // admin123 (hashed)
           full_name: 'System Administrator',
           email: 'admin@supermarket.com',
           phone: '+966 50 123 4567',
           role: 'admin',
           branch_id: 1,
           is_active: true
         },
         {
           username: 'manager',
           password: '$2b$10$3GyiE6zC5Kh2rUgEVcL6NOWPqpGwXpFJXcQrIaZSGhAYQdSHnMy9e', // manager123 (hashed)
           full_name: 'Branch Manager',
           email: 'manager@supermarket.com',
           phone: '+966 50 234 5678',
           role: 'manager',
           branch_id: 1,
           is_active: true
         },
         // Add more users as needed
       ]);
       
       console.log('Database initialized successfully');
     } finally {
       await client.close();
     }
   }

   initializeDatabase().catch(console.error);
   ```

### Production Setup

For production, you'll need a MongoDB Atlas account:

1. **Create MongoDB Atlas Account**:
   - Sign up at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register)
   - Create a new cluster (the free tier is sufficient for starting)

2. **Configure Network Access**:
   - Go to Network Access in Atlas
   - Add your IP address or allow access from anywhere (for testing)

3. **Create Database User**:
   - Go to Database Access
   - Create a new user with read/write permissions

4. **Get Connection String**:
   - Go to Clusters > Connect > Connect your application
   - Copy the connection string
   - Replace `<password>` with your database user's password

5. **Update Environment Variables in Production**:
   - Set `MONGODB_URI` to your Atlas connection string
   - Set `MONGODB_DB` to your database name

## GitHub Pages Deployment

### Setup

1. **Update next.config.js**:
   ```javascript
   /** @type {import('next').NextConfig} */
   const nextConfig = {
     reactStrictMode: true,
     swcMinify: true,
     output: 'export',
     images: {
       unoptimized: true,
     },
     basePath: '/supermarket-management-system',
     assetPrefix: '/supermarket-management-system/',
   }

   module.exports = nextConfig
   ```

2. **Create GitHub Repository**:
   - Go to [GitHub](https://github.com/new)
   - Create a new repository named "supermarket-management-system"
   - Make it public

3. **Push Code to GitHub**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/Hood12/supermarket-management-system.git
   git push -u origin main
   ```

4. **Enable GitHub Pages**:
   - Go to repository Settings > Pages
   - Source: GitHub Actions
   - The workflow file is already included in `.github/workflows/nextjs.yml`

5. **Access Your Site**:
   - After the GitHub Action completes, your site will be available at:
   - https://hood12.github.io/supermarket-management-system/

### Connecting to MongoDB from GitHub Pages

Since GitHub Pages hosts static files only, you'll need a serverless backend for MongoDB operations:

1. **Create API Routes with Vercel Serverless Functions**:
   - Deploy the API portion to Vercel (free tier)
   - Update the frontend to point to your Vercel API endpoints

2. **Alternative: Use MongoDB Realm/Atlas App Services**:
   - Create a MongoDB Realm application
   - Set up Realm functions and rules
   - Use the Realm Web SDK in your frontend

## Login Information

| Username | Password | Role | Email |
|----------|----------|------|-------|
| admin | admin123 | Administrator | admin@supermarket.com |
| manager | manager123 | Branch Manager | manager@supermarket.com |
| cashier | cashier123 | Cashier | cashier@supermarket.com |
| inventory | inventory123 | Inventory Manager | inventory@supermarket.com |

## Security Considerations

1. **Password Hashing**:
   - In production, use bcrypt to hash passwords
   - Never store plain text passwords

2. **Environment Variables**:
   - Keep MongoDB connection strings in environment variables
   - Don't commit .env files to GitHub

3. **API Security**:
   - Implement JWT authentication for API routes
   - Add rate limiting to prevent abuse

4. **CORS Configuration**:
   - Configure CORS to only allow requests from your domain
