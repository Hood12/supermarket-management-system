/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  // Remove the outdated experimental.appDir option
  experimental: {},
  // Add basePath for proper routing
  basePath: '',
  // Ensure trailing slash for consistent routing
  trailingSlash: true,
}

module.exports = nextConfig
