import { db } from './database';

// Mock database implementation
class MockDatabase {
  private inventory = [
    { id: 1, name: 'Rice', name_ar: 'أرز', category: 'Grains', price: 15.99, cost: 10.50, quantity: 120, min_quantity: 20, branch_id: 1 },
    { id: 2, name: 'Milk', name_ar: 'حليب', category: 'Dairy', price: 5.99, cost: 3.75, quantity: 85, min_quantity: 30, branch_id: 1 },
    { id: 3, name: 'Bread', name_ar: 'خبز', category: 'Bakery', price: 3.49, cost: 1.25, quantity: 45, min_quantity: 15, branch_id: 1 },
    { id: 4, name: 'Chicken', name_ar: 'دجاج', category: 'Meat', price: 25.99, cost: 18.50, quantity: 30, min_quantity: 10, branch_id: 1 },
    { id: 5, name: 'Tomatoes', name_ar: 'طماطم', category: 'Vegetables', price: 4.99, cost: 2.25, quantity: 65, min_quantity: 20, branch_id: 1 },
    { id: 6, name: 'Apples', name_ar: 'تفاح', category: 'Fruits', price: 6.99, cost: 4.50, quantity: 75, min_quantity: 25, branch_id: 2 },
    { id: 7, name: 'Eggs', name_ar: 'بيض', category: 'Dairy', price: 7.99, cost: 5.25, quantity: 100, min_quantity: 30, branch_id: 2 },
    { id: 8, name: 'Sugar', name_ar: 'سكر', category: 'Baking', price: 4.49, cost: 2.75, quantity: 90, min_quantity: 20, branch_id: 2 },
    { id: 9, name: 'Salt', name_ar: 'ملح', category: 'Spices', price: 2.99, cost: 1.50, quantity: 110, min_quantity: 25, branch_id: 3 },
    { id: 10, name: 'Coffee', name_ar: 'قهوة', category: 'Beverages', price: 12.99, cost: 8.75, quantity: 40, min_quantity: 15, branch_id: 3 },
  ];

  private sales = [
    { id: 1, date: '2025-03-01', items: [{ product_id: 1, quantity: 5, price: 15.99 }, { product_id: 2, quantity: 3, price: 5.99 }], total: 97.92, branch_id: 1 },
    { id: 2, date: '2025-03-02', items: [{ product_id: 3, quantity: 2, price: 3.49 }, { product_id: 5, quantity: 4, price: 4.99 }], total: 26.94, branch_id: 1 },
    { id: 3, date: '2025-03-03', items: [{ product_id: 4, quantity: 1, price: 25.99 }, { product_id: 7, quantity: 2, price: 7.99 }], total: 41.97, branch_id: 2 },
    { id: 4, date: '2025-03-04', items: [{ product_id: 6, quantity: 3, price: 6.99 }, { product_id: 8, quantity: 1, price: 4.49 }], total: 25.46, branch_id: 2 },
    { id: 5, date: '2025-03-05', items: [{ product_id: 9, quantity: 2, price: 2.99 }, { product_id: 10, quantity: 1, price: 12.99 }], total: 18.97, branch_id: 3 },
    { id: 6, date: '2025-03-10', items: [{ product_id: 1, quantity: 3, price: 15.99 }, { product_id: 4, quantity: 2, price: 25.99 }], total: 99.95, branch_id: 1 },
    { id: 7, date: '2025-03-15', items: [{ product_id: 2, quantity: 4, price: 5.99 }, { product_id: 5, quantity: 3, price: 4.99 }], total: 38.93, branch_id: 1 },
    { id: 8, date: '2025-03-20', items: [{ product_id: 3, quantity: 5, price: 3.49 }, { product_id: 6, quantity: 2, price: 6.99 }], total: 31.43, branch_id: 2 },
    { id: 9, date: '2025-03-22', items: [{ product_id: 7, quantity: 3, price: 7.99 }, { product_id: 10, quantity: 2, price: 12.99 }], total: 49.95, branch_id: 3 },
    { id: 10, date: '2025-03-23', items: [{ product_id: 8, quantity: 2, price: 4.49 }, { product_id: 9, quantity: 4, price: 2.99 }], total: 20.94, branch_id: 3 },
  ];

  private branches = [
    { id: 1, name: 'Industrial', name_ar: 'الصناعية', location: 'Riyadh Industrial Area', manager: 'Mohammed Ali', phone: '+966 50 123 4567', employees: 15, is_active: true },
    { id: 2, name: 'Fesah', name_ar: 'فسح', location: 'Fesah District, Jeddah', manager: 'Ahmed Hassan', phone: '+966 50 234 5678', employees: 10, is_active: true },
    { id: 3, name: 'Omaq', name_ar: 'عمق', location: 'Omaq Street, Dammam', manager: 'Fatima Khalid', phone: '+966 50 345 6789', employees: 8, is_active: true },
  ];

  private users = [
    { id: 1, username: 'admin', password: 'admin123', full_name: 'System Administrator', email: 'admin@supermarket.com', phone: '+966 50 123 4567', role: 'admin', branch_id: 1, is_active: true },
    { id: 2, username: 'manager', password: 'manager123', full_name: 'Branch Manager', email: 'manager@supermarket.com', phone: '+966 50 234 5678', role: 'manager', branch_id: 1, is_active: true },
    { id: 3, username: 'cashier', password: 'cashier123', full_name: 'Cashier', email: 'cashier@supermarket.com', phone: '+966 50 345 6789', role: 'cashier', branch_id: 2, is_active: true },
    { id: 4, username: 'inventory', password: 'inventory123', full_name: 'Inventory Manager', email: 'inventory@supermarket.com', phone: '+966 50 456 7890', role: 'inventory', branch_id: 3, is_active: true },
  ];

  // Inventory methods
  async getInventory() {
    return this.inventory;
  }

  async getInventoryItem(id: number) {
    return this.inventory.find(item => item.id === id);
  }

  async addInventoryItem(item: any) {
    const newItem = { ...item, id: this.inventory.length + 1 };
    this.inventory.push(newItem);
    return newItem;
  }

  async updateInventoryItem(id: number, item: any) {
    const index = this.inventory.findIndex(i => i.id === id);
    if (index !== -1) {
      this.inventory[index] = { ...this.inventory[index], ...item };
      return this.inventory[index];
    }
    return null;
  }

  async deleteInventoryItem(id: number) {
    const index = this.inventory.findIndex(i => i.id === id);
    if (index !== -1) {
      const deletedItem = this.inventory[index];
      this.inventory.splice(index, 1);
      return deletedItem;
    }
    return null;
  }

  // Sales methods
  async getSales() {
    return this.sales;
  }

  async getSale(id: number) {
    return this.sales.find(sale => sale.id === id);
  }

  async addSale(sale: any) {
    const newSale = { ...sale, id: this.sales.length + 1 };
    this.sales.push(newSale);
    
    // Update inventory quantities
    for (const item of sale.items) {
      const inventoryItem = this.inventory.find(i => i.id === item.product_id);
      if (inventoryItem) {
        inventoryItem.quantity -= item.quantity;
      }
    }
    
    return newSale;
  }

  // Branch methods
  async getBranches() {
    return this.branches;
  }

  async getBranch(id: number) {
    return this.branches.find(branch => branch.id === id);
  }

  async addBranch(branch: any) {
    const newBranch = { ...branch, id: this.branches.length + 1 };
    this.branches.push(newBranch);
    return newBranch;
  }

  async updateBranch(id: number, branch: any) {
    const index = this.branches.findIndex(b => b.id === id);
    if (index !== -1) {
      this.branches[index] = { ...this.branches[index], ...branch };
      return this.branches[index];
    }
    return null;
  }

  async deleteBranch(id: number) {
    const index = this.branches.findIndex(b => b.id === id);
    if (index !== -1) {
      const deletedBranch = this.branches[index];
      this.branches.splice(index, 1);
      return deletedBranch;
    }
    return null;
  }

  // User methods
  async getUsers() {
    return this.users;
  }

  async getUser(id: number) {
    return this.users.find(user => user.id === id);
  }

  async getUserByUsername(username: string) {
    return this.users.find(user => user.username === username);
  }

  async addUser(user: any) {
    const newUser = { ...user, id: this.users.length + 1 };
    this.users.push(newUser);
    return newUser;
  }

  async updateUser(id: number, user: any) {
    const index = this.users.findIndex(u => u.id === id);
    if (index !== -1) {
      this.users[index] = { ...this.users[index], ...user };
      return this.users[index];
    }
    return null;
  }

  async deleteUser(id: number) {
    const index = this.users.findIndex(u => u.id === id);
    if (index !== -1) {
      const deletedUser = this.users[index];
      this.users.splice(index, 1);
      return deletedUser;
    }
    return null;
  }

  // Authentication method
  async authenticate(username: string, password: string) {
    const user = this.users.find(u => u.username === username && u.password === password && u.is_active);
    if (user) {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
    return null;
  }

  // Reports methods
  async getSalesByDateRange(startDate: string, endDate: string, branchId?: number) {
    return this.sales.filter(sale => {
      const saleDate = new Date(sale.date);
      const start = new Date(startDate);
      const end = new Date(endDate);
      const branchMatch = branchId ? sale.branch_id === branchId : true;
      return saleDate >= start && saleDate <= end && branchMatch;
    });
  }

  async getInventoryByBranch(branchId: number) {
    return this.inventory.filter(item => item.branch_id === branchId);
  }

  async getLowStockItems() {
    return this.inventory.filter(item => item.quantity <= item.min_quantity);
  }
}

// Export a singleton instance
export const mockDb = new MockDatabase();
