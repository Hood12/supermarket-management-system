// MongoDB Connection Setup
import { MongoClient, Db } from 'mongodb';

// Connection URL
const url = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const dbName = process.env.MONGODB_DB || 'supermarket';

let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

export async function connectToDatabase() {
  // If we have cached values, use them
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb };
  }

  // Connect to MongoDB
  const client = await MongoClient.connect(url);
  const db = client.db(dbName);

  // Cache the client and db connections
  cachedClient = client;
  cachedDb = db;

  return { client, db };
}

// Database collections
export const collections = {
  inventory: 'inventory',
  sales: 'sales',
  branches: 'branches',
  users: 'users',
  suppliers: 'suppliers',
  notifications: 'notifications'
};

// Export the database connection
export const db = {
  connect: connectToDatabase,
  collections
};
