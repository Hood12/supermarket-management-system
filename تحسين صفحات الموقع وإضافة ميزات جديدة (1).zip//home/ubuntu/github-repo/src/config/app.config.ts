// GitHub Pages Configuration
export const GITHUB_PAGES_CONFIG = {
  username: 'Hood12',
  repository: 'supermarket-management-system',
  branch: 'gh-pages',
  baseUrl: '/supermarket-management-system'
};

// MongoDB Configuration
export const MONGODB_CONFIG = {
  uri: process.env.MONGODB_URI || 'mongodb://localhost:27017',
  dbName: process.env.MONGODB_DB || 'supermarket',
  collections: {
    inventory: 'inventory',
    sales: 'sales',
    branches: 'branches',
    users: 'users',
    suppliers: 'suppliers',
    notifications: 'notifications'
  }
};

// Application Configuration
export const APP_CONFIG = {
  name: 'Supermarket Management System',
  version: '1.0.0',
  defaultLocale: 'ar',
  supportedLocales: ['ar', 'en'],
  theme: {
    defaultMode: 'light',
    supportsDarkMode: true
  },
  features: {
    dashboard: true,
    inventory: true,
    sales: true,
    reports: true,
    users: true,
    branches: true,
    suppliers: true,
    notifications: true
  }
};
