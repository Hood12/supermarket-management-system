# Supermarket Management System

A comprehensive web application for managing supermarket operations including inventory, sales, reporting, user management, branch management, supplier management, and notifications.

## Features

- **Dashboard**: Interactive charts and detailed statistics for sales and inventory
- **Inventory Management**: Track products, stock levels, and inventory movements
- **Sales Management**: Process sales transactions and track sales performance
- **Reporting System**: Generate various reports with multiple export options
- **User Management**: Manage users with different roles and permissions
- **Branch Management**: Manage multiple supermarket branches with detailed statistics
- **Supplier Management**: Track suppliers and manage purchase orders
- **Notification System**: Get alerts for low inventory, new orders, and more
- **Dark Mode**: Switch between light and dark themes for user comfort
- **Responsive Design**: Works on all devices from mobile to desktop

## Technology Stack

- **Frontend**: Next.js, React, TailwindCSS
- **Form Management**: React Hook Form, Zod
- **Charts**: Chart.js
- **Icons**: React Icons

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/supermarket-management-system.git
cd supermarket-management-system
```

2. Install dependencies
```bash
npm install
# or
yarn install
```

3. Run the development server
```bash
npm run dev
# or
yarn dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Database Information

This application uses a mock database for demonstration purposes. In a production environment, you would connect to a real database like MySQL, PostgreSQL, or MongoDB.

The mock database is implemented in `src/lib/db/mockDatabase.ts` and simulates database operations with in-memory data.

## Login Information

### Default User Accounts

| Username | Password | Role | Email |
|----------|----------|------|-------|
| admin | admin123 | Administrator | admin@supermarket.com |
| manager | manager123 | Branch Manager | manager@supermarket.com |
| cashier | cashier123 | Cashier | cashier@supermarket.com |
| inventory | inventory123 | Inventory Manager | inventory@supermarket.com |

## Documentation

- [Arabic Documentation](./documentation_ar.md)
- [English Documentation](./documentation_en.md)

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

For support or inquiries, please contact: muneer1122337@gmail.com
