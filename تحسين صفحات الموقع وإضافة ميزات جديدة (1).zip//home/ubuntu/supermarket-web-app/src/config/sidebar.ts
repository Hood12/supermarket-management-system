import { FiHome, FiShoppingCart, FiPackage, FiUsers, FiBarChart2, FiMapPin, FiTruck, FiBell } from 'react-icons/fi';

export const sidebarItems = [
  {
    title: 'dashboard',
    href: '/dashboard',
    icon: FiHome,
  },
  {
    title: 'inventory',
    href: '/inventory',
    icon: FiPackage,
  },
  {
    title: 'sales',
    href: '/sales',
    icon: FiShoppingCart,
  },
  {
    title: 'reports',
    href: '/reports',
    icon: FiBarChart2,
  },
  {
    title: 'branches',
    href: '/branches',
    icon: FiMapPin,
  },
  {
    title: 'suppliers',
    href: '/suppliers',
    icon: FiTruck,
  },
  {
    title: 'users',
    href: '/users',
    icon: FiUsers,
  },
  {
    title: 'notifications',
    href: '/notifications',
    icon: FiBell,
  },
];
