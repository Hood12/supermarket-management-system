"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { FiMenu, FiBell, FiUser, FiMoon, FiSun, FiSearch } from 'react-icons/fi';

export default function Header({ 
  toggleSidebar, 
  darkMode = false, 
  toggleDarkMode 
}: { 
  toggleSidebar: () => void, 
  darkMode?: boolean, 
  toggleDarkMode?: () => void 
}) {
  const t = useTranslations('common');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  // Sample notifications
  const notifications = [
    { id: 1, message: t('lowStockNotification'), time: '10 min', read: false },
    { id: 2, message: t('salesReportReady'), time: '1 hour', read: false },
    { id: 3, message: t('newOrderReceived'), time: '3 hours', read: true },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
    // Implement search functionality
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-10 ${darkMode ? 'bg-gray-800 text-white' : 'bg-white text-gray-800'} shadow-md h-16 ml-64`}>
      <div className="flex items-center justify-between h-full px-6">
        {/* Left side - Menu toggle and search */}
        <div className="flex items-center">
          <button 
            onClick={toggleSidebar}
            className={`p-2 rounded-md ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} mr-4`}
            aria-label={t('toggleMenu')}
          >
            <FiMenu size={20} />
          </button>
          
          <form onSubmit={handleSearch} className="hidden md:flex items-center">
            <div className="relative">
              <input
                type="text"
                placeholder={t('search')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`pl-10 pr-4 py-2 rounded-md ${darkMode ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-800'} focus:outline-none focus:ring-2 focus:ring-blue-500`}
              />
              <FiSearch className="absolute left-3 top-2.5 text-gray-400" size={18} />
            </div>
            <button 
              type="submit"
              className="ml-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {t('search')}
            </button>
          </form>
        </div>
        
        {/* Right side - Notifications, User menu, Dark mode toggle */}
        <div className="flex items-center space-x-4">
          {/* Dark mode toggle */}
          {toggleDarkMode && (
            <button 
              onClick={toggleDarkMode}
              className={`p-2 rounded-full ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
              aria-label={darkMode ? t('lightMode') : t('darkMode')}
            >
              {darkMode ? <FiSun size={20} /> : <FiMoon size={20} />}
            </button>
          )}
          
          {/* Notifications */}
          <div className="relative">
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className={`p-2 rounded-full ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'} relative`}
              aria-label={t('notifications')}
            >
              <FiBell size={20} />
              {notifications.filter(n => !n.read).length > 0 && (
                <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
                  {notifications.filter(n => !n.read).length}
                </span>
              )}
            </button>
            
            {showNotifications && (
              <div className={`absolute right-0 mt-2 w-80 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-md shadow-lg border overflow-hidden z-20`}>
                <div className="p-3 border-b border-gray-200 font-medium">
                  {t('notifications')}
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map(notification => (
                      <div 
                        key={notification.id} 
                        className={`p-3 border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'} ${notification.read ? '' : darkMode ? 'bg-gray-700' : 'bg-blue-50'} cursor-pointer hover:bg-gray-100`}
                      >
                        <div className="flex justify-between">
                          <p className={`${notification.read ? '' : 'font-semibold'}`}>{notification.message}</p>
                          <span className="text-xs text-gray-500">{notification.time}</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-center text-gray-500">
                      {t('noNotifications')}
                    </div>
                  )}
                </div>
                <div className="p-2 text-center border-t border-gray-200">
                  <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                    {t('markAllAsRead')}
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* User menu */}
          <div className="relative">
            <button 
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2"
              aria-label={t('userMenu')}
            >
              <div className={`h-8 w-8 rounded-full ${darkMode ? 'bg-gray-600' : 'bg-blue-100'} flex items-center justify-center`}>
                <FiUser size={18} className={darkMode ? 'text-white' : 'text-blue-600'} />
              </div>
              <span className="hidden md:inline-block font-medium">Admin</span>
            </button>
            
            {showUserMenu && (
              <div className={`absolute right-0 mt-2 w-48 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-md shadow-lg border overflow-hidden z-20`}>
                <div className="p-3 border-b border-gray-200 font-medium">
                  Admin
                </div>
                <div>
                  <button className={`w-full text-left p-3 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}>
                    {t('profile')}
                  </button>
                  <button className={`w-full text-left p-3 ${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}>
                    {t('settings')}
                  </button>
                  <button className={`w-full text-left p-3 ${darkMode ? 'hover:bg-gray-700 text-red-400' : 'hover:bg-gray-100 text-red-600'}`}>
                    {t('logout')}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
