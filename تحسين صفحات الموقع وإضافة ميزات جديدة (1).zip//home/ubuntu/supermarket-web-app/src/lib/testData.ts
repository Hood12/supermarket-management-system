// This file contains test data for the application
// In a production environment, this would be replaced with actual database queries

const testData = {
  branches: [
    { id: 1, name: 'Industrial', name_ar: 'الصناعية', location: 'North District' },
    { id: 2, name: 'Fesah', name_ar: 'فسح', location: 'East District' },
    { id: 3, name: 'Omaq', name_ar: 'عمق', location: 'West District' }
  ],
  
  expenseCategories: [
    { id: 1, name: 'Rent', name_ar: 'الإيجار' },
    { id: 2, name: 'Salaries', name_ar: 'الرواتب' },
    { id: 3, name: 'Utilities', name_ar: 'المرافق' },
    { id: 4, name: 'Inventory', name_ar: 'المخزون' },
    { id: 5, name: 'Marketing', name_ar: 'التسويق' },
    { id: 6, name: 'Maintenance', name_ar: 'الصيانة' },
    { id: 7, name: 'Other', name_ar: 'أخرى' }
  ],
  
  productCategories: [
    { id: 1, name: 'Beverages', name_ar: 'مشروبات' },
    { id: 2, name: 'Canned Goods', name_ar: 'معلبات' },
    { id: 3, name: 'Dairy', name_ar: 'منتجات الألبان' },
    { id: 4, name: 'Frozen Foods', name_ar: 'منتجات مجمدة' },
    { id: 5, name: 'Produce', name_ar: 'فواكه وخضروات' },
    { id: 6, name: 'Cleaning Products', name_ar: 'منتجات التنظيف' }
  ],
  
  products: [
    { 
      id: 1, 
      code: 'P1001', 
      name: 'Mineral Water', 
      name_ar: 'ماء معدني',
      category_id: 1,
      purchase_price: 5.00,
      selling_price: 7.50,
      min_stock_level: 10
    },
    { 
      id: 2, 
      code: 'P1002', 
      name: 'Milk', 
      name_ar: 'حليب',
      category_id: 3,
      purchase_price: 8.00,
      selling_price: 12.00,
      min_stock_level: 8
    },
    { 
      id: 3, 
      code: 'P1003', 
      name: 'Rice', 
      name_ar: 'أرز',
      category_id: 2,
      purchase_price: 15.00,
      selling_price: 22.50,
      min_stock_level: 5
    },
    { 
      id: 4, 
      code: 'P1004', 
      name: 'Sugar', 
      name_ar: 'سكر',
      category_id: 2,
      purchase_price: 10.00,
      selling_price: 15.00,
      min_stock_level: 5
    }
  ],
  
  inventory: [
    { id: 1, product_id: 1, branch_id: 1, quantity: 25, last_updated: '2025-03-20' },
    { id: 2, product_id: 2, branch_id: 1, quantity: 15, last_updated: '2025-03-21' },
    { id: 3, product_id: 3, branch_id: 1, quantity: 3, last_updated: '2025-03-22' },
    { id: 4, product_id: 4, branch_id: 2, quantity: 4, last_updated: '2025-03-22' },
    { id: 5, product_id: 1, branch_id: 2, quantity: 18, last_updated: '2025-03-21' },
    { id: 6, product_id: 2, branch_id: 2, quantity: 12, last_updated: '2025-03-20' },
    { id: 7, product_id: 3, branch_id: 3, quantity: 7, last_updated: '2025-03-22' },
    { id: 8, product_id: 4, branch_id: 3, quantity: 9, last_updated: '2025-03-21' }
  ],
  
  dailySales: [
    { 
      id: 1, 
      date: '2025-03-16', 
      branch_id: 1, 
      cash_sales: 4200, 
      visa_sales: 6000, 
      total_revenue: 10200, 
      expenses: 2550, 
      expense_category_id: 2, 
      daily_profit: 7650, 
      employee_name: 'Mohammed', 
      notes: '' 
    },
    { 
      id: 2, 
      date: '2025-03-17', 
      branch_id: 1, 
      cash_sales: 4800, 
      visa_sales: 6700, 
      total_revenue: 11500, 
      expenses: 2875, 
      expense_category_id: 3, 
      daily_profit: 8625, 
      employee_name: 'Mohammed', 
      notes: '' 
    },
    { 
      id: 3, 
      date: '2025-03-18', 
      branch_id: 1, 
      cash_sales: 4100, 
      visa_sales: 5700, 
      total_revenue: 9800, 
      expenses: 2450, 
      expense_category_id: 4, 
      daily_profit: 7350, 
      employee_name: 'Mohammed', 
      notes: '' 
    },
    { 
      id: 4, 
      date: '2025-03-19', 
      branch_id: 2, 
      cash_sales: 5200, 
      visa_sales: 7200, 
      total_revenue: 12400, 
      expenses: 3100, 
      expense_category_id: 2, 
      daily_profit: 9300, 
      employee_name: 'Ahmed', 
      notes: '' 
    },
    { 
      id: 5, 
      date: '2025-03-20', 
      branch_id: 2, 
      cash_sales: 4500, 
      visa_sales: 6500, 
      total_revenue: 11000, 
      expenses: 2750, 
      expense_category_id: 1, 
      daily_profit: 8250, 
      employee_name: 'Ahmed', 
      notes: '' 
    },
    { 
      id: 6, 
      date: '2025-03-21', 
      branch_id: 3, 
      cash_sales: 4500, 
      visa_sales: 6500, 
      total_revenue: 11000, 
      expenses: 2800, 
      expense_category_id: 5, 
      daily_profit: 8200, 
      employee_name: 'Fatima', 
      notes: '' 
    },
    { 
      id: 7, 
      date: '2025-03-22', 
      branch_id: 3, 
      cash_sales: 5000, 
      visa_sales: 7000, 
      total_revenue: 12000, 
      expenses: 3000, 
      expense_category_id: 6, 
      daily_profit: 9000, 
      employee_name: 'Fatima', 
      notes: '' 
    }
  ],
  
  emailConfig: {
    id: 1,
    recipient_email: 'muneer1122337@gmail.com',
    subject: 'تقرير السوبرماركت اليومي / Daily Supermarket Report',
    send_time: '18:00',
    frequency: 'daily',
    include_sales_summary: true,
    include_profit_summary: true,
    include_branch_comparison: true,
    include_inventory_alerts: true
  }
};

export default testData;