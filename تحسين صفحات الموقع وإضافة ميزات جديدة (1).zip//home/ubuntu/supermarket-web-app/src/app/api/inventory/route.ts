import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';

export async function GET(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    // Get query parameters
    const url = new URL(request.url);
    const branchId = url.searchParams.get('branch_id');
    const showLowStock = url.searchParams.get('low_stock');
    
    let inventoryItems;
    
    if (showLowStock === 'true') {
      inventoryItems = await dbService.getLowStockItems();
    } else if (branchId) {
      inventoryItems = await dbService.getInventoryByBranch(parseInt(branchId));
    } else {
      inventoryItems = await dbService.getInventory();
    }
    
    return NextResponse.json({ inventory: inventoryItems });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    return NextResponse.json(
      { error: 'Failed to fetch inventory' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const data = await request.json();
    
    // Update inventory quantity
    // This is a simplified example - in a real application, you would have more validation
    // and possibly transaction handling
    
    // Example data structure:
    // { product_id: 1, branch_id: 1, quantity: 10 }
    
    // In a real application, you would implement this method in the database service
    // For now, we'll just return a success response
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating inventory:', error);
    return NextResponse.json(
      { error: 'Failed to update inventory' },
      { status: 500 }
    );
  }
}