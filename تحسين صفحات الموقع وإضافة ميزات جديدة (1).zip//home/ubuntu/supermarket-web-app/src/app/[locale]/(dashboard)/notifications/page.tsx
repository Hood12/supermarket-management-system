"use client";

import { useState, useEffect } from 'react';
import { useTranslations } from 'next-intl';
import { FiBell, FiX, FiCheck, FiAlertTriangle, FiInfo, FiShoppingCart, FiPackage, FiTruck, FiCalendar, FiSettings, FiFilter, FiRefreshCw } from 'react-icons/fi';

export default function NotificationsPage() {
  const t = useTranslations('notifications');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<any>(null);
  const [showNotificationDetails, setShowNotificationDetails] = useState(false);

  // Sample data for demonstration
  const notifications = [
    {
      id: 1,
      type: 'inventory',
      title: 'Low Stock Alert',
      message: 'Rice is below minimum stock level (3 units remaining)',
      date: '2025-03-23 10:15',
      is_read: false,
      priority: 'high',
      related_item: 'Rice',
      related_id: 'P1003',
      branch: 'Industrial',
      actions: [
        { label: 'View Inventory', action: 'view_inventory', id: 'P1003' },
        { label: 'Create Order', action: 'create_order', supplier_id: 1 }
      ]
    },
    {
      id: 2,
      type: 'order',
      title: 'Order Delivered',
      message: 'Order #3 from Global Imports Ltd. has been delivered',
      date: '2025-03-22 14:30',
      is_read: true,
      priority: 'medium',
      related_item: 'Order #3',
      related_id: '3',
      branch: 'Industrial',
      actions: [
        { label: 'View Order', action: 'view_order', id: 3 }
      ]
    },
    {
      id: 3,
      type: 'sales',
      title: 'Daily Sales Target Achieved',
      message: 'Industrial branch has achieved the daily sales target of 12,000 SAR',
      date: '2025-03-22 21:00',
      is_read: false,
      priority: 'low',
      related_item: 'Sales Report',
      related_id: '2025-03-22',
      branch: 'Industrial',
      actions: [
        { label: 'View Sales Report', action: 'view_sales_report', date: '2025-03-22' }
      ]
    },
    {
      id: 4,
      type: 'system',
      title: 'System Update',
      message: 'System will be updated on March 25, 2025 at 02:00 AM. Please save your work before this time.',
      date: '2025-03-21 09:00',
      is_read: true,
      priority: 'medium',
      related_item: 'System Update',
      related_id: 'SYS-2025-03',
      branch: 'All',
      actions: []
    },
    {
      id: 5,
      type: 'inventory',
      title: 'Expiring Products',
      message: 'Milk products in Fesah branch will expire in 3 days',
      date: '2025-03-21 08:15',
      is_read: false,
      priority: 'high',
      related_item: 'Milk',
      related_id: 'P1001',
      branch: 'Fesah',
      actions: [
        { label: 'View Inventory', action: 'view_inventory', id: 'P1001' },
        { label: 'Apply Discount', action: 'apply_discount', id: 'P1001' }
      ]
    },
    {
      id: 6,
      type: 'order',
      title: 'Order In Transit',
      message: 'Order #4 from Al-Marai Foods is in transit and expected to arrive tomorrow',
      date: '2025-03-20 16:45',
      is_read: true,
      priority: 'medium',
      related_item: 'Order #4',
      related_id: '4',
      branch: 'Industrial',
      actions: [
        { label: 'View Order', action: 'view_order', id: 4 }
      ]
    },
    {
      id: 7,
      type: 'user',
      title: 'New User Added',
      message: 'Ahmed Hassan has been added as a Branch Manager for Fesah branch',
      date: '2025-03-20 11:30',
      is_read: true,
      priority: 'low',
      related_item: 'User',
      related_id: '3',
      branch: 'Fesah',
      actions: [
        { label: 'View User', action: 'view_user', id: 3 }
      ]
    },
  ];

  const getUnreadCount = () => {
    return notifications.filter(notification => !notification.is_read).length;
  };

  const getFilteredNotifications = () => {
    switch (activeTab) {
      case 'unread':
        return notifications.filter(notification => !notification.is_read);
      case 'high':
        return notifications.filter(notification => notification.priority === 'high');
      case 'inventory':
        return notifications.filter(notification => notification.type === 'inventory');
      case 'orders':
        return notifications.filter(notification => notification.type === 'order');
      case 'system':
        return notifications.filter(notification => notification.type === 'system' || notification.type === 'user');
      default:
        return notifications;
    }
  };

  const handleRefresh = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const handleMarkAsRead = (notificationId: number) => {
    console.log('Mark as read:', notificationId);
    // In a real application, this would update the notification status
  };

  const handleMarkAllAsRead = () => {
    console.log('Mark all as read');
    // In a real application, this would update all notification statuses
  };

  const handleDeleteNotification = (notificationId: number) => {
    console.log('Delete notification:', notificationId);
    // In a real application, this would delete the notification
  };

  const handleViewNotificationDetails = (notification: any) => {
    setSelectedNotification(notification);
    setShowNotificationDetails(true);
  };

  const handleCloseNotificationDetails = () => {
    setShowNotificationDetails(false);
    setSelectedNotification(null);
  };

  const handleAction = (action: string, params: any) => {
    console.log('Action:', action, params);
    // In a real application, this would navigate to the appropriate page or perform an action
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'inventory':
        return <FiPackage className="h-6 w-6 text-blue-500 dark:text-blue-400" />;
      case 'order':
        return <FiTruck className="h-6 w-6 text-green-500 dark:text-green-400" />;
      case 'sales':
        return <FiShoppingCart className="h-6 w-6 text-purple-500 dark:text-purple-400" />;
      case 'system':
        return <FiSettings className="h-6 w-6 text-gray-500 dark:text-gray-400" />;
      case 'user':
        return <FiInfo className="h-6 w-6 text-indigo-500 dark:text-indigo-400" />;
      default:
        return <FiBell className="h-6 w-6 text-gray-500 dark:text-gray-400" />;
    }
  };

  const getPriorityBadgeColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200';
      case 'medium':
        return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200';
      case 'low':
        return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
          {getUnreadCount() > 0 && (
            <span className="ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200">
              {getUnreadCount()} {t('unread')}
            </span>
          )}
        </div>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <button
            onClick={handleRefresh}
            disabled={isLoading}
            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none disabled:opacity-50"
          >
            <FiRefreshCw className={`mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </button>
          
          <button
            onClick={handleMarkAllAsRead}
            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none"
          >
            <FiCheck className="mr-2" />
            {t('markAllAsRead')}
          </button>
        </div>
      </div>
      
      {/* Notification Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            <button
              onClick={() => setActiveTab('all')}
              className={`${
                activeTab === 'all'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('all')}
            </button>
            <button
              onClick={() => setActiveTab('unread')}
              className={`${
                activeTab === 'unread'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('unread')}
            </button>
            <button
              onClick={() => setActiveTab('high')}
              className={`${
                activeTab === 'high'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('highPriority')}
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`${
                activeTab === 'inventory'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('inventory')}
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`${
                activeTab === 'orders'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('orders')}
            </button>
            <button
              onClick={() => setActiveTab('system')}
              className={`${
                activeTab === 'system'
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('system')}
            </button>
          </nav>
        </div>
      </div>
      
      {/* Notification List */}
      <div className="space-y-4">
        {getFilteredNotifications().map((notification) => (
          <div 
            key={notification.id} 
            className={`bg-white dark:bg-gray-800 shadow-md rounded-lg p-4 transition-all duration-200 ${
              !notification.is_read ? 'border-l-4 border-blue-500 dark:border-blue-400' : ''
            } hover:shadow-lg`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0 pt-0.5">
                {getNotificationIcon(notification.type)}
              </div>
              <div className="ml-3 flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {notification.title}
                  </p>
                  <div className="ml-2 flex-shrink-0 flex">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityBadgeColor(notification.priority)}`}>
                      {t(notification.priority)}
                    </span>
                  </div>
                </div>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  {notification.message}
                </p>
                <div className="mt-2 flex justify-between items-center">
                  <div className="flex space-x-4">
                    <button
                      onClick={() => handleViewNotificationDetails(notification)}
                      className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
                    >
                      {t('details')}
                    </button>
                    {!notification.is_read && (
                      <button
                        onClick={() => handleMarkAsRead(notification.id)}
                        className="text-sm text-green-600 dark:text-green-400 hover:text-green-800 dark:hover:text-green-300"
                      >
                        {t('markAsRead')}
                      </button>
                    )}
                    <button
                      onClick={() => handleDeleteNotification(notification.id)}
                      className="text-sm text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
                    >
                      {t('delete')}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {notification.date}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {getFilteredNotifications().length === 0 && (
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 text-center">
            <FiBell className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500" />
            <h3 className="mt-2 text-sm font-medium text-gray-900 dark:text-white">{t('noNotifications')}</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {t('noNotificationsDescription')}
            </p>
          </div>
        )}
      </div>
      
      {/* Notification Details Modal */}
      {showNotificationDetails && selectedNotification && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  {getNotificationIcon(selectedNotification.type)}
                </div>
                <h2 className="ml-3 text-xl font-semibold dark:text-white">
                  {selectedNotification.title}
                </h2>
              </div>
              <button
                onClick={handle<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>