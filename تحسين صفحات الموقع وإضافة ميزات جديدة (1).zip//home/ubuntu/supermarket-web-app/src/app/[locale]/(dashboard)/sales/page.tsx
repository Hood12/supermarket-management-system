"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiPlus, FiSave, FiDownload, FiUpload, FiCalendar, FiBarChart2, FiPrinter, FiMail } from 'react-icons/fi';

// Form validation schema
const salesEntrySchema = z.object({
  date: z.string().min(1, { message: 'Date is required' }),
  branch_id: z.string().min(1, { message: 'Branch is required' }),
  cash_sales: z.string().min(1, { message: 'Cash sales is required' }),
  visa_sales: z.string().min(1, { message: 'Visa sales is required' }),
  expenses: z.string().min(1, { message: 'Expenses is required' }),
  expense_category_id: z.string().optional(),
  employee_name: z.string().optional(),
  notes: z.string().optional(),
});

type SalesFormData = z.infer<typeof salesEntrySchema>;

export default function SalesPage() {
  const t = useTranslations('sales');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('entry');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSalesHistory, setShowSalesHistory] = useState(false);
  const [dateFilter, setDateFilter] = useState('week');
  const [isExporting, setIsExporting] = useState(false);

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const expenseCategories = [
    { id: '1', name: 'Rent', name_ar: 'الإيجار' },
    { id: '2', name: 'Salaries', name_ar: 'الرواتب' },
    { id: '3', name: 'Utilities', name_ar: 'المرافق' },
    { id: '4', name: 'Inventory', name_ar: 'المخزون' },
    { id: '5', name: 'Marketing', name_ar: 'التسويق' },
    { id: '6', name: 'Maintenance', name_ar: 'الصيانة' },
    { id: '7', name: 'Other', name_ar: 'أخرى' },
  ];

  const salesHistory = [
    { 
      id: 1,
      date: '2025-03-22', 
      branch_id: '1',
      branch: 'Industrial',
      cash_sales: 5000.00, 
      visa_sales: 7000.00, 
      total_revenue: 12000.00, 
      expenses: 3000.00, 
      expense_category_id: '6',
      expense_category: 'Maintenance',
      daily_profit: 9000.00, 
      employee_name: 'Mohammed', 
      notes: '' 
    },
    { 
      id: 2,
      date: '2025-03-21', 
      branch_id: '2',
      branch: 'Fesah',
      cash_sales: 4500.00, 
      visa_sales: 6500.00, 
      total_revenue: 11000.00, 
      expenses: 2800.00, 
      expense_category_id: '5',
      expense_category: 'Marketing',
      daily_profit: 8200.00, 
      employee_name: 'Ahmed', 
      notes: '' 
    },
    { 
      id: 3,
      date: '2025-03-20', 
      branch_id: '3',
      branch: 'Omaq',
      cash_sales: 5200.00, 
      visa_sales: 7200.00, 
      total_revenue: 12400.00, 
      expenses: 3200.00, 
      expense_category_id: '4',
      expense_category: 'Inventory',
      daily_profit: 9200.00, 
      employee_name: 'Fatima', 
      notes: '' 
    },
  ];

  const { control, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm<SalesFormData>({
    resolver: zodResolver(salesEntrySchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      branch_id: '',
      cash_sales: '',
      visa_sales: '',
      expenses: '',
      expense_category_id: '',
      employee_name: '',
      notes: '',
    }
  });

  // Calculate total revenue and daily profit
  const cashSales = parseFloat(watch('cash_sales') || '0');
  const visaSales = parseFloat(watch('visa_sales') || '0');
  const expenses = parseFloat(watch('expenses') || '0');
  const totalRevenue = cashSales + visaSales;
  const dailyProfit = totalRevenue - expenses;

  const onSubmit = async (data: SalesFormData) => {
    setIsSubmitting(true);
    
    try {
      // In a real application, this would be an API call
      console.log('Form data:', {
        ...data,
        total_revenue: totalRevenue,
        daily_profit: dailyProfit,
      });
      
      // Reset form or show success message
      setTimeout(() => {
        setIsSubmitting(false);
        reset({
          date: new Date().toISOString().split('T')[0],
          branch_id: '',
          cash_sales: '',
          visa_sales: '',
          expenses: '',
          expense_category_id: '',
          employee_name: '',
          notes: '',
        });
        alert(t('salesEntrySaved'));
      }, 1000);
    } catch (error) {
      console.error('Error saving sales entry:', error);
      alert(t('errorSavingSales'));
      setIsSubmitting(false);
    }
  };

  const handleExportSales = () => {
    setIsExporting(true);
    // Simulate export process
    setTimeout(() => {
      setIsExporting(false);
      alert(t('salesExported'));
    }, 1500);
  };

  const handlePrintSales = () => {
    alert(t('preparingPrint'));
    // In a real application, this would trigger print functionality
  };

  const handleEmailReport = () => {
    alert(t('emailSent'));
    // In a real application, this would send an email report
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setActiveTab('entry')}
              className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                activeTab === 'entry'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              <FiPlus className="inline-block mr-2" />
              {t('addSales')}
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('history');
                setShowSalesHistory(true);
              }}
              className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                activeTab === 'history'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              <FiBarChart2 className="inline-block mr-2" />
              {t('salesHistory')}
            </button>
          </div>
          
          {activeTab === 'history' && (
            <div className="flex space-x-2">
              <button
                onClick={handleExportSales}
                disabled={isExporting}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <FiDownload className={`mr-2 ${isExporting ? 'animate-spin' : ''}`} />
                {t('export')}
              </button>
              <button
                onClick={handlePrintSales}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiPrinter className="mr-2" />
                {t('print')}
              </button>
              <button
                onClick={handleEmailReport}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiMail className="mr-2" />
                {t('email')}
              </button>
            </div>
          )}
        </div>
      </div>
      
      {activeTab === 'entry' && (
        <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6 dark:text-white">{t('dailyEntry')}</h2>
          
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('date')}
                </label>
                <Controller
                  name="date"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="date"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-10"
                        {...field}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <FiCalendar className="text-gray-400" />
                      </div>
                    </div>
                  )}
                />
                {errors.date && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.date.message}</p>
                )}
              </div>
              
              {/* Branch */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('branch')}
                </label>
                <Controller
                  name="branch_id"
                  control={control}
                  render={({ field }) => (
                    <select
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    >
                      <option value="">{commonT('select')}</option>
                      {branches.map((branch) => (
                        <option key={branch.id} value={branch.id}>
                          {branch.name}
                        </option>
                      ))}
                    </select>
                  )}
                />
                {errors.branch_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.branch_id.message}</p>
                )}
              </div>
              
              {/* Cash Sales */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('cashSales')}
                </label>
                <Controller
                  name="cash_sales"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </div>
                  )}
                />
                {errors.cash_sales && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.cash_sales.message}</p>
                )}
              </div>
              
              {/* Visa Sales */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('visaSales')}
                </label>
                <Controller
                  name="visa_sales"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </div>
                  )}
                />
                {errors.visa_sales && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.visa_sales.message}</p>
                )}
              </div>
              
              {/* Total Revenue (calculated) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('totalRevenue')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-600 shadow-sm pl-8"
                    value={`${totalRevenue.toFixed(2)}`}
                    readOnly
                  />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500 dark:text-gray-400">﷼</span>
                  </div>
                </div>
              </div>
              
              {/* Expenses */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('expenses')}
                </label>
                <Controller
                  name="expenses"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </di<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>