"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiPlus, FiSave, FiSearch, FiFilter, FiDownload, FiUpload, FiEdit, FiTrash2, FiAlertCircle } from 'react-icons/fi';

// Form validation schema
const inventoryFilterSchema = z.object({
  branch_id: z.string().optional(),
  category_id: z.string().optional(),
  search: z.string().optional(),
  show_low_stock: z.boolean().optional(),
});

type InventoryFilterData = z.infer<typeof inventoryFilterSchema>;

// Product form schema
const productFormSchema = z.object({
  code: z.string().min(1, { message: 'Product code is required' }),
  name: z.string().min(1, { message: 'Product name is required' }),
  name_ar: z.string().min(1, { message: 'Arabic name is required' }),
  category_id: z.string().min(1, { message: 'Category is required' }),
  purchase_price: z.string().min(1, { message: 'Purchase price is required' }),
  selling_price: z.string().min(1, { message: 'Selling price is required' }),
  min_stock_level: z.string().min(1, { message: 'Minimum stock level is required' }),
  branch_id: z.string().min(1, { message: 'Branch is required' }),
  quantity: z.string().min(1, { message: 'Quantity is required' }),
});

type ProductFormData = z.infer<typeof productFormSchema>;

export default function InventoryPage() {
  const t = useTranslations('inventory');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('all');
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const categories = [
    { id: '1', name: 'Beverages', name_ar: 'مشروبات' },
    { id: '2', name: 'Canned Goods', name_ar: 'معلبات' },
    { id: '3', name: 'Dairy', name_ar: 'منتجات الألبان' },
    { id: '4', name: 'Frozen Foods', name_ar: 'منتجات مجمدة' },
    { id: '5', name: 'Produce', name_ar: 'فواكه وخضروات' },
    { id: '6', name: 'Cleaning Products', name_ar: 'منتجات التنظيف' },
  ];

  const inventoryItems = [
    { 
      id: 1, 
      code: 'P1001', 
      name: 'Mineral Water', 
      name_ar: 'ماء معدني',
      category: 'Beverages',
      category_ar: 'مشروبات',
      category_id: '1',
      purchase_price: 5.00,
      selling_price: 7.50,
      quantity: 25,
      min_stock_level: 10,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      branch_id: '1',
      last_updated: '2025-03-20'
    },
    { 
      id: 2, 
      code: 'P1002', 
      name: 'Milk', 
      name_ar: 'حليب',
      category: 'Dairy',
      category_ar: 'منتجات الألبان',
      category_id: '3',
      purchase_price: 8.00,
      selling_price: 12.00,
      quantity: 15,
      min_stock_level: 8,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      branch_id: '1',
      last_updated: '2025-03-21'
    },
    { 
      id: 3, 
      code: 'P1003', 
      name: 'Rice', 
      name_ar: 'أرز',
      category: 'Canned Goods',
      category_ar: 'معلبات',
      category_id: '2',
      purchase_price: 15.00,
      selling_price: 22.50,
      quantity: 3,
      min_stock_level: 5,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      branch_id: '1',
      last_updated: '2025-03-22'
    },
    { 
      id: 4, 
      code: 'P1004', 
      name: 'Sugar', 
      name_ar: 'سكر',
      category: 'Canned Goods',
      category_ar: 'معلبات',
      category_id: '2',
      purchase_price: 10.00,
      selling_price: 15.00,
      quantity: 4,
      min_stock_level: 5,
      branch: 'Fesah',
      branch_ar: 'فسح',
      branch_id: '2',
      last_updated: '2025-03-22'
    },
  ];

  const lowStockItems = inventoryItems.filter(item => item.quantity < item.min_stock_level);

  const { control: filterControl, handleSubmit: handleFilterSubmit } = useForm<InventoryFilterData>({
    resolver: zodResolver(inventoryFilterSchema),
    defaultValues: {
      branch_id: '',
      category_id: '',
      search: '',
      show_low_stock: false,
    }
  });

  const { control: productControl, handleSubmit: handleProductSubmit, reset: resetProductForm, formState: { errors: productErrors } } = useForm<ProductFormData>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      code: '',
      name: '',
      name_ar: '',
      category_id: '',
      purchase_price: '',
      selling_price: '',
      min_stock_level: '',
      branch_id: '',
      quantity: '',
    }
  });

  const onFilterSubmit = (data: InventoryFilterData) => {
    setIsLoading(true);
    console.log('Filter data:', data);
    // In a real application, this would filter the inventory items
    setTimeout(() => {
      setIsLoading(false);
    }, 800);
  };

  const onProductSubmit = (data: ProductFormData) => {
    console.log('Product data:', data);
    // In a real application, this would save the product
    setShowProductForm(false);
    resetProductForm();
    setEditingProduct(null);
  };

  const handleAddProduct = () => {
    resetProductForm();
    setEditingProduct(null);
    setShowProductForm(true);
  };

  const handleEditProduct = (product: any) => {
    setEditingProduct(product);
    resetProductForm({
      code: product.code,
      name: product.name,
      name_ar: product.name_ar,
      category_id: product.category_id,
      purchase_price: product.purchase_price.toString(),
      selling_price: product.selling_price.toString(),
      min_stock_level: product.min_stock_level.toString(),
      branch_id: product.branch_id,
      quantity: product.quantity.toString(),
    });
    setShowProductForm(true);
  };

  const handleDeleteProduct = (productId: number) => {
    if (confirm(t('confirmDelete'))) {
      console.log('Delete product:', productId);
      // In a real application, this would delete the product
    }
  };

  const handleExportInventory = () => {
    console.log('Export inventory');
    // In a real application, this would export the inventory to CSV/Excel
  };

  const handleImportInventory = () => {
    console.log('Import inventory');
    // In a real application, this would import inventory from CSV/Excel
  };

  const displayedItems = activeTab === 'low_stock' ? lowStockItems : inventoryItems;

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <button 
            onClick={handleAddProduct}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <FiPlus className="mr-2" />
            {t('addProduct')}
          </button>
          
          <div className="inline-flex rounded-md shadow-sm">
            <button
              onClick={handleExportInventory}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-l-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiDownload className="mr-2" />
              {t('export')}
            </button>
            <button
              onClick={handleImportInventory}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-r-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiUpload className="mr-2" />
              {t('import')}
            </button>
          </div>
        </div>
      </div>
      
      {/* Product Form Modal */}
      {showProductForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingProduct ? t('editProduct') : t('addProduct')}
            </h2>
            
            <form onSubmit={handleProductSubmit(onProductSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Product Code */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('productCode')}
                  </label>
                  <Controller
                    name="code"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.code && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.code.message}</p>
                  )}
                </div>
                
                {/* Product Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('productName')}
                  </label>
                  <Controller
                    name="name"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.name.message}</p>
                  )}
                </div>
                
                {/* Arabic Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('arabicName')}
                  </label>
                  <Controller
                    name="name_ar"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.name_ar && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.name_ar.message}</p>
                  )}
                </div>
                
                {/* Category */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('category')}
                  </label>
                  <Controller
                    name="category_id"
                    control={productControl}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="">{commonT('select')}</option>
                        {categories.map((category) => (
                          <option key={category.id} value={category.id}>
                            {category.name}
                          </option>
                        ))}
                      </select>
                    )}
                  />
                  {productErrors.category_id && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.category_id.message}</p>
                  )}
                </div>
                
                {/* Purchase Price */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('purchasePrice')}
                  </label>
                  <Controller
                    name="purchase_price"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.purchase_price && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.purchase_price.message}</p>
                  )}
                </div>
                
                {/* Selling Price */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('sellingPrice')}
                  </label>
                  <Controller
                    name="selling_price"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.selling_price && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{productErrors.selling_price.message}</p>
                  )}
                </div>
                
                {/* Min Stock Level */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('minStockLevel')}
                  </label>
                  <Controller
                    name="min_stock_level"
                    control={productControl}
                    render={({ field }) => (
                      <input
                        type="number"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {productErrors.min_stock_level && (
                  <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>