"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiSave, FiEdit, FiTrash2, FiPlus, FiUser, FiLock, FiEye, FiEyeOff, FiUserPlus, FiUserCheck, FiUserX } from 'react-icons/fi';

// Form validation schema
const userFormSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  full_name: z.string().min(1, { message: 'Full name is required' }),
  email: z.string().email({ message: 'Invalid email address' }),
  phone: z.string().min(1, { message: 'Phone number is required' }),
  role: z.string().min(1, { message: 'Role is required' }),
  branch_id: z.string().min(1, { message: 'Branch is required' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }).optional(),
  confirm_password: z.string().optional(),
  is_active: z.boolean().default(true),
}).refine((data) => !data.password || data.password === data.confirm_password, {
  message: "Passwords don't match",
  path: ['confirm_password'],
});

type UserFormData = z.infer<typeof userFormSchema>;

export default function UsersPage() {
  const t = useTranslations('users');
  const commonT = useTranslations('common');
  const [showUserForm, setShowUserForm] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [activeTab, setActiveTab] = useState('all');

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const roles = [
    { id: 'admin', name: 'Administrator', name_ar: 'مدير النظام' },
    { id: 'manager', name: 'Branch Manager', name_ar: 'مدير الفرع' },
    { id: 'cashier', name: 'Cashier', name_ar: 'أمين الصندوق' },
    { id: 'inventory', name: 'Inventory Manager', name_ar: 'مدير المخزون' },
  ];

  const users = [
    { 
      id: 1, 
      username: 'admin', 
      full_name: 'System Administrator', 
      email: 'admin@supermarket.com',
      phone: '+966 50 123 4567',
      role: 'admin',
      role_name: 'Administrator',
      branch_id: '1',
      branch_name: 'Industrial',
      last_login: '2025-03-23 10:15',
      is_active: true,
    },
    { 
      id: 2, 
      username: 'mohammed', 
      full_name: 'Mohammed Ali', 
      email: 'mohammed@supermarket.com',
      phone: '+966 50 234 5678',
      role: 'manager',
      role_name: 'Branch Manager',
      branch_id: '1',
      branch_name: 'Industrial',
      last_login: '2025-03-22 15:30',
      is_active: true,
    },
    { 
      id: 3, 
      username: 'ahmed', 
      full_name: 'Ahmed Hassan', 
      email: 'ahmed@supermarket.com',
      phone: '+966 50 345 6789',
      role: 'manager',
      role_name: 'Branch Manager',
      branch_id: '2',
      branch_name: 'Fesah',
      last_login: '2025-03-22 14:45',
      is_active: true,
    },
    { 
      id: 4, 
      username: 'fatima', 
      full_name: 'Fatima Khalid', 
      email: 'fatima@supermarket.com',
      phone: '+966 50 456 7890',
      role: 'manager',
      role_name: 'Branch Manager',
      branch_id: '3',
      branch_name: 'Omaq',
      last_login: '2025-03-21 09:20',
      is_active: true,
    },
    { 
      id: 5, 
      username: 'khalid', 
      full_name: 'Khalid Omar', 
      email: 'khalid@supermarket.com',
      phone: '+966 50 567 8901',
      role: 'cashier',
      role_name: 'Cashier',
      branch_id: '1',
      branch_name: 'Industrial',
      last_login: '2025-03-23 08:10',
      is_active: true,
    },
    { 
      id: 6, 
      username: 'sara', 
      full_name: 'Sara Ahmed', 
      email: 'sara@supermarket.com',
      phone: '+966 50 678 9012',
      role: 'inventory',
      role_name: 'Inventory Manager',
      branch_id: '1',
      branch_name: 'Industrial',
      last_login: '2025-03-22 11:05',
      is_active: false,
    },
  ];

  const { control, handleSubmit, reset: resetUserForm, formState: { errors } } = useForm<UserFormData>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      username: '',
      full_name: '',
      email: '',
      phone: '',
      role: '',
      branch_id: '',
      password: '',
      confirm_password: '',
      is_active: true,
    }
  });

  const onUserSubmit = (data: UserFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('User data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowUserForm(false);
      resetUserForm();
      setEditingUser(null);
      
      // Show success message
      alert(editingUser ? t('userUpdated') : t('userAdded'));
    }, 1000);
  };

  const handleAddUser = () => {
    resetUserForm();
    setEditingUser(null);
    setShowUserForm(true);
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    resetUserForm({
      username: user.username,
      full_name: user.full_name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      branch_id: user.branch_id,
      password: '',
      confirm_password: '',
      is_active: user.is_active,
    });
    setShowUserForm(true);
  };

  const handleDeleteUser = (userId: number) => {
    if (confirm(t('confirmDelete'))) {
      console.log('Delete user:', userId);
      // In a real application, this would delete the user
      alert(t('userDeleted'));
    }
  };

  const handleToggleUserStatus = (user: any) => {
    console.log('Toggle user status:', user.id, !user.is_active);
    // In a real application, this would update the user's status
    alert(user.is_active ? t('userDeactivated') : t('userActivated'));
  };

  const filteredUsers = activeTab === 'all' 
    ? users 
    : activeTab === 'active' 
      ? users.filter(user => user.is_active) 
      : users.filter(user => !user.is_active);

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <button 
          onClick={handleAddUser}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <FiUserPlus className="mr-2" />
          {t('addUser')}
        </button>
      </div>
      
      {/* User Form Modal */}
      {showUserForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingUser ? t('editUser') : t('addUser')}
            </h2>
            
            <form onSubmit={handleSubmit(onUserSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Username */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('username')}
                  </label>
                  <Controller
                    name="username"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                        readOnly={!!editingUser}
                      />
                    )}
                  />
                  {errors.username && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.username.message}</p>
                  )}
                </div>
                
                {/* Full Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('fullName')}
                  </label>
                  <Controller
                    name="full_name"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.full_name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.full_name.message}</p>
                  )}
                </div>
                
                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('email')}
                  </label>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="email"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.email.message}</p>
                  )}
                </div>
                
                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('phone')}
                  </label>
                  <Controller
                    name="phone"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="tel"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.phone && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.phone.message}</p>
                  )}
                </div>
                
                {/* Role */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('role')}
                  </label>
                  <Controller
                    name="role"
                    control={control}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="">{commonT('select')}</option>
                        {roles.map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.name}
                          </option>
                        ))}
                      </select>
                    )}
                  />
                  {errors.role && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.role.message}</p>
                  )}
                </div>
                
                {/* Branch */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('branch')}
                  </label>
                  <Controller
                    name="branch_id"
                    control={control}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="">{commonT('select')}</option>
                        {branches.map((branch) => (
                          <option key={branch.id} value={branch.id}>
                            {branch.name}
                          </option>
                        ))}
                      </select>
                    )}
                  />
                  {errors.branch_id && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.branch_id.message}</p>
                  )}
                </div>
                
                {/* Password */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {editingUser ? t('newPassword') : t('password')}
                  </label>
                  <div className="relative">
                    <Controller
                      name="password"
                      control={control}
                      render={({ field }) => (
                        <input
                          type={showPassword ? "text" : "password"}
                          className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pr-10"
                          placeholder={editingUser ? t('leaveBlankToKeep') : ''}
                          {...field}
                        />
                      )}
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <FiEyeOff className="h-5 w-5 text-gray-400" />
                      ) : (
                        <FiEye className="h-5 w-5 text-gray-400" />
                      )}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.password.message}</p>
                  )}
                </div>
                
                {/* Confirm Password */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('confirmPassword')}
                  </label>
                  <div className="relative">
                    <Controller
                      name="confirm_password"
                      control={control}
                      render={({ field }) => (
                        <input
                          type={showConfirmPassword ? "text" : "password"}
                          className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pr-10"
                          placeholder={editingUser ? t('l<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>