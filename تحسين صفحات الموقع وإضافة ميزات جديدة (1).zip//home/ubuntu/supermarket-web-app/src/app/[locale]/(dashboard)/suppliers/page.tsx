"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiSave, FiEdit, FiTrash2, FiPlus, FiPackage, FiPhone, FiMail, FiFileText, FiCalendar, FiDollarSign, FiTruck, FiCheck, FiX } from 'react-icons/fi';

// Form validation schema
const supplierFormSchema = z.object({
  name: z.string().min(1, { message: 'Supplier name is required' }),
  contact_person: z.string().min(1, { message: 'Contact person is required' }),
  phone: z.string().min(1, { message: 'Phone number is required' }),
  email: z.string().email({ message: 'Invalid email address' }).optional().or(z.literal('')),
  address: z.string().min(1, { message: 'Address is required' }),
  product_categories: z.string().min(1, { message: 'Product categories is required' }),
  payment_terms: z.string().optional(),
  notes: z.string().optional(),
  is_active: z.boolean().default(true),
});

type SupplierFormData = z.infer<typeof supplierFormSchema>;

// Order form schema
const orderFormSchema = z.object({
  supplier_id: z.string().min(1, { message: 'Supplier is required' }),
  order_date: z.string().min(1, { message: 'Order date is required' }),
  expected_delivery: z.string().min(1, { message: 'Expected delivery date is required' }),
  items: z.string().min(1, { message: 'Order items are required' }),
  total_amount: z.string().min(1, { message: 'Total amount is required' }),
  payment_status: z.string().min(1, { message: 'Payment status is required' }),
  delivery_status: z.string().min(1, { message: 'Delivery status is required' }),
  notes: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderFormSchema>;

export default function SuppliersPage() {
  const t = useTranslations('suppliers');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('suppliers');
  const [showSupplierForm, setShowSupplierForm] = useState(false);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<any>(null);
  const [editingOrder, setEditingOrder] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');

  // Sample data for demonstration
  const suppliers = [
    { 
      id: 1, 
      name: 'Al-Marai Foods', 
      contact_person: 'Abdullah Al-Otaibi',
      phone: '+966 50 123 4567',
      email: 'abdullah@almarai.com',
      address: '123 Industrial City, Riyadh',
      product_categories: 'Dairy, Juices, Bakery',
      payment_terms: 'Net 30',
      notes: 'Preferred supplier for dairy products',
      is_active: true,
      total_orders: 24,
      total_spent: 125000,
      last_order_date: '2025-03-15',
      avg_delivery_days: 2
    },
    { 
      id: 2, 
      name: 'Saudi Vegetables Co.', 
      contact_person: 'Mohammed Al-Qahtani',
      phone: '+966 50 234 5678',
      email: 'mohammed@saudiveg.com',
      address: '456 Farm District, Dammam',
      product_categories: 'Vegetables, Fruits',
      payment_terms: 'Net 15',
      notes: 'Local produce supplier',
      is_active: true,
      total_orders: 36,
      total_spent: 85000,
      last_order_date: '2025-03-20',
      avg_delivery_days: 1
    },
    { 
      id: 3, 
      name: 'Global Imports Ltd.', 
      contact_person: 'Sarah Johnson',
      phone: '+966 50 345 6789',
      email: 'sarah@globalimports.com',
      address: '789 Port Area, Jeddah',
      product_categories: 'Canned Goods, Imported Foods',
      payment_terms: 'Net 45',
      notes: 'International food importer',
      is_active: true,
      total_orders: 18,
      total_spent: 210000,
      last_order_date: '2025-03-10',
      avg_delivery_days: 5
    },
    { 
      id: 4, 
      name: 'Clean Supplies Co.', 
      contact_person: 'Khalid Al-Harbi',
      phone: '+966 50 456 7890',
      email: 'khalid@cleansupplies.com',
      address: '101 Commercial St, Riyadh',
      product_categories: 'Cleaning Products, Paper Goods',
      payment_terms: 'Net 30',
      notes: '',
      is_active: false,
      total_orders: 12,
      total_spent: 45000,
      last_order_date: '2025-02-25',
      avg_delivery_days: 3
    },
  ];

  const orders = [
    {
      id: 1,
      supplier_id: 1,
      supplier_name: 'Al-Marai Foods',
      order_date: '2025-03-15',
      expected_delivery: '2025-03-17',
      actual_delivery: '2025-03-17',
      items: 'Milk (100 units), Yogurt (200 units), Cheese (50 units)',
      total_amount: 12500,
      payment_status: 'paid',
      delivery_status: 'delivered',
      notes: ''
    },
    {
      id: 2,
      supplier_id: 2,
      supplier_name: 'Saudi Vegetables Co.',
      order_date: '2025-03-20',
      expected_delivery: '2025-03-21',
      actual_delivery: '2025-03-21',
      items: 'Tomatoes (100kg), Cucumbers (80kg), Lettuce (50kg)',
      total_amount: 8500,
      payment_status: 'paid',
      delivery_status: 'delivered',
      notes: ''
    },
    {
      id: 3,
      supplier_id: 3,
      supplier_name: 'Global Imports Ltd.',
      order_date: '2025-03-10',
      expected_delivery: '2025-03-15',
      actual_delivery: '2025-03-16',
      items: 'Canned Tuna (200 units), Pasta (300 units), Olive Oil (100 units)',
      total_amount: 15000,
      payment_status: 'pending',
      delivery_status: 'delivered',
      notes: 'Delivery was delayed by one day'
    },
    {
      id: 4,
      supplier_id: 1,
      supplier_name: 'Al-Marai Foods',
      order_date: '2025-03-22',
      expected_delivery: '2025-03-24',
      actual_delivery: null,
      items: 'Milk (150 units), Yogurt (250 units), Juice (100 units)',
      total_amount: 14000,
      payment_status: 'pending',
      delivery_status: 'in_transit',
      notes: ''
    },
    {
      id: 5,
      supplier_id: 2,
      supplier_name: 'Saudi Vegetables Co.',
      order_date: '2025-03-23',
      expected_delivery: '2025-03-24',
      actual_delivery: null,
      items: 'Potatoes (200kg), Onions (150kg), Carrots (100kg)',
      total_amount: 9000,
      payment_status: 'pending',
      delivery_status: 'processing',
      notes: ''
    },
  ];

  const { control: supplierControl, handleSubmit: handleSupplierSubmit, reset: resetSupplierForm, formState: { errors: supplierErrors } } = useForm<SupplierFormData>({
    resolver: zodResolver(supplierFormSchema),
    defaultValues: {
      name: '',
      contact_person: '',
      phone: '',
      email: '',
      address: '',
      product_categories: '',
      payment_terms: '',
      notes: '',
      is_active: true,
    }
  });

  const { control: orderControl, handleSubmit: handleOrderSubmit, reset: resetOrderForm, formState: { errors: orderErrors } } = useForm<OrderFormData>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      supplier_id: '',
      order_date: new Date().toISOString().split('T')[0],
      expected_delivery: '',
      items: '',
      total_amount: '',
      payment_status: 'pending',
      delivery_status: 'processing',
      notes: '',
    }
  });

  const onSupplierSubmit = (data: SupplierFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('Supplier data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSupplierForm(false);
      resetSupplierForm();
      setEditingSupplier(null);
      
      // Show success message
      alert(editingSupplier ? t('supplierUpdated') : t('supplierAdded'));
    }, 1000);
  };

  const onOrderSubmit = (data: OrderFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('Order data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowOrderForm(false);
      resetOrderForm();
      setEditingOrder(null);
      
      // Show success message
      alert(editingOrder ? t('orderUpdated') : t('orderAdded'));
    }, 1000);
  };

  const handleAddSupplier = () => {
    resetSupplierForm();
    setEditingSupplier(null);
    setShowSupplierForm(true);
  };

  const handleEditSupplier = (supplier: any) => {
    setEditingSupplier(supplier);
    resetSupplierForm({
      name: supplier.name,
      contact_person: supplier.contact_person,
      phone: supplier.phone,
      email: supplier.email || '',
      address: supplier.address,
      product_categories: supplier.product_categories,
      payment_terms: supplier.payment_terms || '',
      notes: supplier.notes || '',
      is_active: supplier.is_active,
    });
    setShowSupplierForm(true);
  };

  const handleDeleteSupplier = (supplierId: number) => {
    if (confirm(t('confirmDeleteSupplier'))) {
      console.log('Delete supplier:', supplierId);
      // In a real application, this would delete the supplier
      alert(t('supplierDeleted'));
    }
  };

  const handleViewSupplierDetails = (supplier: any) => {
    setSelectedSupplier(supplier);
    setViewMode('detail');
  };

  const handleBackToList = () => {
    setSelectedSupplier(null);
    setViewMode('list');
  };

  const handleAddOrder = () => {
    resetOrderForm();
    setEditingOrder(null);
    setShowOrderForm(true);
  };

  const handleEditOrder = (order: any) => {
    setEditingOrder(order);
    resetOrderForm({
      supplier_id: order.supplier_id.toString(),
      order_date: order.order_date,
      expected_delivery: order.expected_delivery,
      items: order.items,
      total_amount: order.total_amount.toString(),
      payment_status: order.payment_status,
      delivery_status: order.delivery_status,
      notes: order.notes || '',
    });
    setShowOrderForm(true);
  };

  const handleDeleteOrder = (orderId: number) => {
    if (confirm(t('confirmDeleteOrder'))) {
      console.log('Delete order:', orderId);
      // In a real application, this would delete the order
      alert(t('orderDeleted'));
    }
  };

  const getSupplierOrders = (supplierId: number) => {
    return orders.filter(order => order.supplier_id === supplierId);
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setActiveTab('suppliers')}
              className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                activeTab === 'suppliers'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('suppliers')}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                activeTab === 'orders'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('orders')}
            </button>
          </div>
          
          {activeTab === 'suppliers' && viewMode === 'list' && (
            <button 
              onClick={handleAddSupplier}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiPlus className="mr-2" />
              {t('addSupplier')}
            </button>
          )}
          
          {activeTab === 'orders' && (
            <button 
              onClick={handleAddOrder}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiPlus className="mr-2" />
              {t('addOrder')}
            </button>
          )}
          
          {activeTab === 'suppliers' && viewMode === 'detail' && (
            <div className="flex space-x-3">
              <button 
                onClick={() => handleEditSupplier(selectedSupplier)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiEdit className="mr-2" />
                {t('editSupplier')}
              </button>
              <button 
                onClick={handleBackToList}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {t('backToList')}
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Supplier Form Modal */}
      {showSupplierForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingSupplier ? t('editSupplier') : t('addSupplier')}
            </h2>
            
            <form onSubmit={handleSupplierSubmit(onSupplierSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Supplier Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('supplierName')}
                  </label>
                  <Controller
                    name="name"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.name.message}</p>
                  )}
                </div>
                
                {/* Contact Person */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('contactPerson')}
                  </label>
                  <Controller
                    name="contact_person"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
  <response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>