import { getDbService } from '@/lib/db/mockDatabase';

// Override the database service import in the main database.ts file
// This allows us to use the mock database for testing
export { getDbService };
