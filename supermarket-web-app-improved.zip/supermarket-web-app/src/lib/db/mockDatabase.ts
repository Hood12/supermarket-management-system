import testData from '@/lib/testData';

// Mock database service that uses test data instead of actual database
export function getDbService(db: any) {
  return {
    // Branch methods
    getBranches: async () => {
      return testData.branches;
    },
    
    // Sales methods
    getDailySales: async () => {
      return testData.dailySales;
    },
    createDailySales: async (data: any) => {
      // In a real app, this would insert into the database
      // For testing, we just return a mock ID
      return testData.dailySales.length + 1;
    },
    
    // Inventory methods
    getInventory: async () => {
      // Join inventory with products and branches to get complete data
      return testData.inventory.map(item => {
        const product = testData.products.find(p => p.id === item.product_id);
        const branch = testData.branches.find(b => b.id === item.branch_id);
        const category = testData.productCategories.find(c => c.id === product?.category_id);
        
        return {
          id: item.id,
          product_id: item.product_id,
          product_code: product?.code,
          product_name: product?.name,
          product_name_ar: product?.name_ar,
          category_id: product?.category_id,
          category_name: category?.name,
          category_name_ar: category?.name_ar,
          purchase_price: product?.purchase_price,
          selling_price: product?.selling_price,
          quantity: item.quantity,
          min_stock_level: product?.min_stock_level,
          branch_id: item.branch_id,
          branch_name: branch?.name,
          branch_name_ar: branch?.name_ar,
          last_updated: item.last_updated
        };
      });
    },
    getInventoryByBranch: async (branchId: number) => {
      const allInventory = await getDbService(db).getInventory();
      return allInventory.filter(item => item.branch_id === branchId);
    },
    getLowStockItems: async () => {
      const allInventory = await getDbService(db).getInventory();
      return allInventory.filter(item => item.quantity < item.min_stock_level);
    },
    
    // Email report methods
    getEmailReportConfig: async () => {
      return testData.emailConfig;
    },
    updateEmailReportConfig: async (data: any) => {
      // In a real app, this would update the database
      // For testing, we just return success
      return true;
    }
  };
}
