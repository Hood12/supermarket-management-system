"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { FiDownload, FiPrinter, FiMail } from 'react-icons/fi';

export default function ReportActions() {
  const t = useTranslations('reports');
  const [isSending, setIsSending] = useState(false);
  
  const handleSendReport = async () => {
    try {
      setIsSending(true);
      
      const response = await fetch('/api/reports/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert(`Report sent successfully to ${data.message.split(' ').pop()}`);
      } else {
        alert('Failed to send report: ' + (data.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Error sending report:', error);
      alert('Error sending report. Please try again.');
    } finally {
      setIsSending(false);
    }
  };
  
  const handleDownloadPDF = () => {
    // In a real application, this would call an API endpoint to generate and download a PDF
    alert('PDF download functionality would be implemented here');
  };
  
  const handlePrintReport = () => {
    window.print();
  };
  
  return (
    <div className="flex space-x-4">
      <button
        onClick={handleSendReport}
        disabled={isSending}
        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
      >
        <FiMail className="mr-2" />
        {isSending ? t('sending') : t('sendReport')}
      </button>
      
      <button
        onClick={handleDownloadPDF}
        className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <FiDownload className="mr-2" />
        {t('downloadPDF')}
      </button>
      
      <button
        onClick={handlePrintReport}
        className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
      >
        <FiPrinter className="mr-2" />
        {t('printReport')}
      </button>
    </div>
  );
}
