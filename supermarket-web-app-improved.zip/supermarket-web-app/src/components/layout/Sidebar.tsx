"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Link } from '@/lib/navigation';
import { FiHome, FiShoppingCart, FiPackage, FiBarChart2, FiSettings, FiGlobe, FiChevronDown, FiUsers, FiTruck, FiLogOut } from 'react-icons/fi';

export default function Sidebar({ locale, collapsed = false, toggleCollapse }: { 
  locale: string, 
  collapsed?: boolean,
  toggleCollapse?: () => void
}) {
  const t = useTranslations('common');
  const otherLocale = locale === 'en' ? 'ar' : 'en';
  const [activeSubmenu, setActiveSubmenu] = useState<string | null>(null);
  
  const menuItems = [
    { 
      id: 'dashboard',
      href: '/dashboard', 
      label: t('dashboard'), 
      icon: FiHome 
    },
    { 
      id: 'sales',
      href: '/sales', 
      label: t('sales'), 
      icon: FiShoppingCart 
    },
    { 
      id: 'inventory',
      href: '/inventory', 
      label: t('inventory'), 
      icon: FiPackage,
      submenu: [
        { id: 'products', href: '/inventory/products', label: t('products') },
        { id: 'categories', href: '/inventory/categories', label: t('categories') },
        { id: 'stock-alerts', href: '/inventory/stock-alerts', label: t('stockAlerts') }
      ]
    },
    { 
      id: 'reports',
      href: '/reports', 
      label: t('reports'), 
      icon: FiBarChart2,
      submenu: [
        { id: 'sales-reports', href: '/reports/sales', label: t('salesReports') },
        { id: 'inventory-reports', href: '/reports/inventory', label: t('inventoryReports') },
        { id: 'profit-reports', href: '/reports/profit', label: t('profitReports') }
      ]
    },
    { 
      id: 'branches',
      href: '/branches', 
      label: t('branches'), 
      icon: FiUsers 
    },
    { 
      id: 'suppliers',
      href: '/suppliers', 
      label: t('suppliers'), 
      icon: FiTruck 
    },
    { 
      id: 'settings',
      href: '/settings', 
      label: t('settings'), 
      icon: FiSettings,
      submenu: [
        { id: 'profile', href: '/settings/profile', label: t('profile') },
        { id: 'users', href: '/settings/users', label: t('users') },
        { id: 'system', href: '/settings/system', label: t('system') }
      ]
    },
  ];

  const toggleSubmenu = (id: string) => {
    setActiveSubmenu(activeSubmenu === id ? null : id);
  };

  return (
    <aside className={`bg-white dark:bg-gray-800 shadow-md h-screen fixed top-0 left-0 overflow-y-auto transition-all duration-300 ${collapsed ? 'w-20' : 'w-64'}`}>
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        {!collapsed && <h1 className="text-xl font-bold text-blue-600 dark:text-blue-400">{t('appName')}</h1>}
        {collapsed && <div className="w-full flex justify-center">
          <span className="text-xl font-bold text-blue-600 dark:text-blue-400">SM</span>
        </div>}
        {toggleCollapse && (
          <button 
            onClick={toggleCollapse}
            className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400"
            aria-label={collapsed ? t('expandSidebar') : t('collapseSidebar')}
          >
            {collapsed ? '→' : '←'}
          </button>
        )}
      </div>
      
      <nav className="mt-6">
        <ul>
          {menuItems.map((item) => (
            <li key={item.id} className="mb-1">
              {item.submenu ? (
                <div>
                  <button
                    onClick={() => toggleSubmenu(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition-colors ${activeSubmenu === item.id ? 'bg-blue-50 dark:bg-gray-700 text-blue-600 dark:text-blue-400' : ''}`}
                  >
                    <div className="flex items-center">
                      <item.icon className={`${collapsed ? 'mx-auto' : 'mr-3'}`} />
                      {!collapsed && <span>{item.label}</span>}
                    </div>
                    {!collapsed && <FiChevronDown className={`transition-transform ${activeSubmenu === item.id ? 'transform rotate-180' : ''}`} />}
                  </button>
                  
                  {!collapsed && activeSubmenu === item.id && (
                    <ul className="ml-6 mt-1 space-y-1">
                      {item.submenu.map((subItem) => (
                        <li key={subItem.id}>
                          <Link
                            href={subItem.href}
                            className="flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition-colors"
                          >
                            <span>{subItem.label}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <Link 
                  href={item.href}
                  className="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition-colors"
                >
                  <item.icon className={`${collapsed ? 'mx-auto' : 'mr-3'}`} />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="absolute bottom-0 w-full p-4 border-t border-gray-200 dark:border-gray-700">
        <Link 
          href={menuItems[0].href} 
          locale={otherLocale}
          className="flex items-center px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-blue-400 rounded-lg transition-colors"
        >
          <FiGlobe className={`${collapsed ? 'mx-auto' : 'mr-3'}`} />
          {!collapsed && <span>{otherLocale === 'ar' ? 'العربية' : 'English'}</span>}
        </Link>
        
        {!collapsed && (
          <Link 
            href="/logout"
            className="flex items-center px-4 py-2 mt-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          >
            <FiLogOut className="mr-3" />
            <span>{t('logout')}</span>
          </Link>
        )}
        
        {collapsed && (
          <Link 
            href="/logout"
            className="flex items-center justify-center px-4 py-2 mt-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          >
            <FiLogOut />
          </Link>
        )}
      </div>
    </aside>
  );
}
