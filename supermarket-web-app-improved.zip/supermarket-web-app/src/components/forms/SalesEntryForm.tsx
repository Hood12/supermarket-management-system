"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiPlus, FiSave, FiX } from 'react-icons/fi';

// Form validation schema
const salesFormSchema = z.object({
  date: z.string().min(1, { message: 'Date is required' }),
  branch_id: z.string().min(1, { message: 'Branch is required' }),
  cash_sales: z.string().min(1, { message: 'Cash sales is required' }),
  visa_sales: z.string().min(1, { message: 'Visa sales is required' }),
  expenses: z.string().min(1, { message: 'Expenses is required' }),
  expense_category_id: z.string().optional(),
  employee_name: z.string().optional(),
  notes: z.string().optional(),
});

type SalesFormData = z.infer<typeof salesFormSchema>;

export default function SalesEntryForm() {
  const t = useTranslations('sales');
  const commonT = useTranslations('common');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const expenseCategories = [
    { id: '1', name: 'Rent', name_ar: 'الإيجار' },
    { id: '2', name: 'Salaries', name_ar: 'الرواتب' },
    { id: '3', name: 'Utilities', name_ar: 'المرافق' },
    { id: '4', name: 'Inventory', name_ar: 'المخزون' },
    { id: '5', name: 'Marketing', name_ar: 'التسويق' },
    { id: '6', name: 'Maintenance', name_ar: 'الصيانة' },
    { id: '7', name: 'Other', name_ar: 'أخرى' },
  ];

  const { control, handleSubmit, watch, setValue, formState: { errors } } = useForm<SalesFormData>({
    resolver: zodResolver(salesFormSchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      branch_id: '',
      cash_sales: '',
      visa_sales: '',
      expenses: '',
      expense_category_id: '',
      employee_name: '',
      notes: '',
    }
  });

  // Calculate total revenue and daily profit
  const cashSales = parseFloat(watch('cash_sales') || '0');
  const visaSales = parseFloat(watch('visa_sales') || '0');
  const expenses = parseFloat(watch('expenses') || '0');
  const totalRevenue = cashSales + visaSales;
  const dailyProfit = totalRevenue - expenses;

  const onSubmit = async (data: SalesFormData) => {
    setIsSubmitting(true);
    
    try {
      // In a real application, this would be an API call
      console.log('Form data:', {
        ...data,
        total_revenue: totalRevenue,
        daily_profit: dailyProfit,
      });
      
      // Reset form or show success message
      alert('Sales entry saved successfully!');
    } catch (error) {
      console.error('Error saving sales entry:', error);
      alert('Error saving sales entry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-6">{t('dailyEntry')}</h2>
      
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('date')}
            </label>
            <Controller
              name="date"
              control={control}
              render={({ field }) => (
                <input
                  type="date"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                />
              )}
            />
            {errors.date && (
              <p className="mt-1 text-sm text-red-600">{errors.date.message}</p>
            )}
          </div>
          
          {/* Branch */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('branch')}
            </label>
            <Controller
              name="branch_id"
              control={control}
              render={({ field }) => (
                <select
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                >
                  <option value="">{commonT('select')}</option>
                  {branches.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.name}
                    </option>
                  ))}
                </select>
              )}
            />
            {errors.branch_id && (
              <p className="mt-1 text-sm text-red-600">{errors.branch_id.message}</p>
            )}
          </div>
          
          {/* Cash Sales */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('cashSales')}
            </label>
            <Controller
              name="cash_sales"
              control={control}
              render={({ field }) => (
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0.00"
                  {...field}
                  onChange={(e) => {
                    field.onChange(e);
                  }}
                />
              )}
            />
            {errors.cash_sales && (
              <p className="mt-1 text-sm text-red-600">{errors.cash_sales.message}</p>
            )}
          </div>
          
          {/* Visa Sales */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('visaSales')}
            </label>
            <Controller
              name="visa_sales"
              control={control}
              render={({ field }) => (
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0.00"
                  {...field}
                  onChange={(e) => {
                    field.onChange(e);
                  }}
                />
              )}
            />
            {errors.visa_sales && (
              <p className="mt-1 text-sm text-red-600">{errors.visa_sales.message}</p>
            )}
          </div>
          
          {/* Total Revenue (calculated) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('totalRevenue')}
            </label>
            <input
              type="text"
              className="w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              value={`${totalRevenue.toFixed(2)} ﷼`}
              readOnly
            />
          </div>
          
          {/* Expenses */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('expenses')}
            </label>
            <Controller
              name="expenses"
              control={control}
              render={({ field }) => (
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="0.00"
                  {...field}
                  onChange={(e) => {
                    field.onChange(e);
                  }}
                />
              )}
            />
            {errors.expenses && (
              <p className="mt-1 text-sm text-red-600">{errors.expenses.message}</p>
            )}
          </div>
          
          {/* Expense Category */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('expenseCategory')}
            </label>
            <Controller
              name="expense_category_id"
              control={control}
              render={({ field }) => (
                <select
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                >
                  <option value="">{commonT('select')}</option>
                  {expenseCategories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              )}
            />
          </div>
          
          {/* Daily Profit (calculated) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('dailyProfit')}
            </label>
            <input
              type="text"
              className="w-full rounded-md border-gray-300 bg-gray-50 shadow-sm"
              value={`${dailyProfit.toFixed(2)} ﷼`}
              readOnly
            />
          </div>
          
          {/* Employee Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('employeeName')}
            </label>
            <Controller
              name="employee_name"
              control={control}
              render={({ field }) => (
                <input
                  type="text"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                />
              )}
            />
          </div>
        </div>
        
        {/* Notes */}
        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            {t('notes')}
          </label>
          <Controller
            name="notes"
            control={control}
            render={({ field }) => (
              <textarea
                rows={3}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                {...field}
              />
            )}
          />
        </div>
        
        {/* Submit Button */}
        <div className="mt-6 flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            <FiSave className="mr-2" />
            {commonT('save')}
          </button>
        </div>
      </form>
    </div>
  );
}
