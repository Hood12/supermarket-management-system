import { ReactNode } from 'react';
import { NextIntlClientProvider } from 'next-intl';
import { dictionary } from '@/lib/config';
import { inter, cairo } from '@/lib/navigation';

export function generateStaticParams() {
  return [{ locale: 'en' }, { locale: 'ar' }];
}

export default async function RootLayout({
  children,
  params: { locale }
}: {
  children: ReactNode;
  params: { locale: string };
}) {
  const direction = locale === 'ar' ? 'rtl' : 'ltr';
  const fontClass = locale === 'ar' ? cairo.variable : inter.variable;

  return (
    <html lang={locale} dir={direction}>
      <body className={`${fontClass} font-sans min-h-screen bg-gray-50`}>
        <NextIntlClientProvider locale={locale} messages={dictionary[locale as 'en' | 'ar']}>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
