"use client";

import { useTranslations } from 'next-intl';
import { useState, useEffect } from 'react';
import { FiDollarSign, FiTrendingUp, FiShoppingBag, FiAlertTriangle, FiUsers, FiCalendar, FiRefreshCw } from 'react-icons/fi';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend } from 'recharts';

export default function Dashboard() {
  const t = useTranslations('dashboard');
  const commonT = useTranslations('common');
  const [timeFilter, setTimeFilter] = useState('today');
  const [isLoading, setIsLoading] = useState(false);
  
  // Sample data for demonstration
  const salesData = [
    { name: 'Industrial', sales: 12000, profit: 9000 },
    { name: 'Fesah', sales: 11000, profit: 8200 },
    { name: 'Omaq', sales: 12400, profit: 9200 },
  ];

  const salesTrendData = [
    { date: '03/17', sales: 9800 },
    { date: '03/18', sales: 10200 },
    { date: '03/19', sales: 11000 },
    { date: '03/20', sales: 10500 },
    { date: '03/21', sales: 11500 },
    { date: '03/22', sales: 12400 },
    { date: '03/23', sales: 12000 },
  ];

  const categoryData = [
    { name: 'Beverages', value: 35 },
    { name: 'Dairy', value: 25 },
    { name: 'Canned Goods', value: 20 },
    { name: 'Produce', value: 15 },
    { name: 'Other', value: 5 },
  ];

  const lowStockItems = [
    { id: 1, code: 'P1003', name: 'Rice', quantity: 3, minLevel: 5, branch: 'Industrial' },
    { id: 2, code: 'P1004', name: 'Sugar', quantity: 4, minLevel: 5, branch: 'Fesah' },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  const refreshData = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  useEffect(() => {
    refreshData();
  }, [timeFilter]);

  const StatCard = ({ title, value, icon: Icon, color, percentage, trend }) => (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5 transition-all hover:shadow-md">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-gray-500 dark:text-gray-400 text-sm">{title}</p>
          <p className="text-2xl font-bold mt-1 dark:text-white">{value}</p>
          {percentage && (
            <div className={`flex items-center mt-2 ${trend === 'up' ? 'text-green-500' : 'text-red-500'}`}>
              <span className="text-sm font-medium">{percentage}%</span>
              <FiTrendingUp className={`ml-1 ${trend === 'up' ? '' : 'transform rotate-180'}`} />
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">{t('vsPrevPeriod')}</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="text-white" size={20} />
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setTimeFilter('today')}
              className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                timeFilter === 'today'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('today')}
            </button>
            <button
              type="button"
              onClick={() => setTimeFilter('week')}
              className={`px-4 py-2 text-sm font-medium ${
                timeFilter === 'week'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border-t border-b border-gray-300 dark:border-gray-600`}
            >
              {t('thisWeek')}
            </button>
            <button
              type="button"
              onClick={() => setTimeFilter('month')}
              className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                timeFilter === 'month'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('thisMonth')}
            </button>
          </div>
          
          <button
            onClick={refreshData}
            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none"
          >
            <FiRefreshCw className={`mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </button>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title={t('todaySales')} 
          value="₹ 35,400" 
          icon={FiDollarSign} 
          color="bg-blue-500" 
          percentage="8.2"
          trend="up"
        />
        <StatCard 
          title={t('todayProfit')} 
          value="₹ 26,400" 
          icon={FiTrendingUp} 
          color="bg-green-500" 
          percentage="5.1"
          trend="up"
        />
        <StatCard 
          title={t('lowStockItems')} 
          value={lowStockItems.length.toString()} 
          icon={FiAlertTriangle} 
          color="bg-orange-500" 
        />
        <StatCard 
          title={t('avgTransactionValue')} 
          value="₹ 1,180" 
          icon={FiShoppingBag} 
          color="bg-purple-500" 
          percentage="3.2"
          trend="down"
        />
      </div>
      
      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Sales Trend Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4 dark:text-white">{t('salesTrend')}</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={salesTrendData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                    borderColor: '#E5E7EB',
                    borderRadius: '0.375rem' 
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="sales" 
                  name={t('sales')}
                  stroke="#3B82F6" 
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Branch Comparison Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4 dark:text-white">{t('branchComparison')}</h2>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={salesData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                    borderColor: '#E5E7EB',
                    borderRadius: '0.375rem' 
                  }} 
                />
                <Legend />
                <Bar dataKey="sales" name={t('monthlySales')} fill="#3b82f6" />
                <Bar dataKey="profit" name={t('monthlyProfit')} fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Sales by Category */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4 dark:text-white">{t('salesByCategory')}</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => [`${value}%`, t('percentage')]}
                  contentStyle={{ 
                    backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                    borderColor: '#E5E7EB',
                    borderRadius: '0.375rem' 
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4 dark:text-white">{t('recentActivity')}</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                  <FiDollarSign className="text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium dark:text-white">New sale recorded</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">₹ 12,400 - Omaq Branch</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">10 minutes ago</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                  <FiUsers className="text-green-600 dark:text-green-400" />
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium dark:text-white">New employee added</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Ahmed - Fesah Branch</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">1 hour ago</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900 flex items-center justify-center">
                  <FiAlertTriangle className="text-orange-600 dark:text-orange-400" />
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium dark:text-white">Low stock alert</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Rice - Industrial Branch</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
                  <FiCalendar className="text-purple-600 dark:text-purple-400" />
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium dark:text-white">Daily report sent</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">All branches</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">3 hours ago</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Low Stock Items */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5">
          <h2 className="text-lg font-semibold mb-4 dark:text-white">{t('lowStockItems')}</h2>
          {lowStockItems.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('productCode', { ns: 'inventory' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('productName', { ns: 'inventory' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('availableQuantity', { ns: 'inventory' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('branch', { ns: 'inventory' })}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {lowStockItems.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                        {item.code}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        {item.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200">
                          {item.quantity}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                        {item.branch}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-gray-500 dark:text-gray-400">{commonT('noData')}</p>
          )}
        </div>
      </div>
    </div>
  );
}
