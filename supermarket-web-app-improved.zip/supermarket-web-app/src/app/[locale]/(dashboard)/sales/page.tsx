"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiPlus, FiSave, FiDownload, FiUpload, FiCalendar, FiBarChart2, FiPrinter, FiMail } from 'react-icons/fi';

// Form validation schema
const salesEntrySchema = z.object({
  date: z.string().min(1, { message: 'Date is required' }),
  branch_id: z.string().min(1, { message: 'Branch is required' }),
  cash_sales: z.string().min(1, { message: 'Cash sales is required' }),
  visa_sales: z.string().min(1, { message: 'Visa sales is required' }),
  expenses: z.string().min(1, { message: 'Expenses is required' }),
  expense_category_id: z.string().optional(),
  employee_name: z.string().optional(),
  notes: z.string().optional(),
});

type SalesFormData = z.infer<typeof salesEntrySchema>;

export default function SalesPage() {
  const t = useTranslations('sales');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('entry');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSalesHistory, setShowSalesHistory] = useState(false);
  const [dateFilter, setDateFilter] = useState('week');
  const [isExporting, setIsExporting] = useState(false);

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const expenseCategories = [
    { id: '1', name: 'Rent', name_ar: 'الإيجار' },
    { id: '2', name: 'Salaries', name_ar: 'الرواتب' },
    { id: '3', name: 'Utilities', name_ar: 'المرافق' },
    { id: '4', name: 'Inventory', name_ar: 'المخزون' },
    { id: '5', name: 'Marketing', name_ar: 'التسويق' },
    { id: '6', name: 'Maintenance', name_ar: 'الصيانة' },
    { id: '7', name: 'Other', name_ar: 'أخرى' },
  ];

  const salesHistory = [
    { 
      id: 1,
      date: '2025-03-22', 
      branch_id: '1',
      branch: 'Industrial',
      cash_sales: 5000.00, 
      visa_sales: 7000.00, 
      total_revenue: 12000.00, 
      expenses: 3000.00, 
      expense_category_id: '6',
      expense_category: 'Maintenance',
      daily_profit: 9000.00, 
      employee_name: 'Mohammed', 
      notes: '' 
    },
    { 
      id: 2,
      date: '2025-03-21', 
      branch_id: '2',
      branch: 'Fesah',
      cash_sales: 4500.00, 
      visa_sales: 6500.00, 
      total_revenue: 11000.00, 
      expenses: 2800.00, 
      expense_category_id: '5',
      expense_category: 'Marketing',
      daily_profit: 8200.00, 
      employee_name: 'Ahmed', 
      notes: '' 
    },
    { 
      id: 3,
      date: '2025-03-20', 
      branch_id: '3',
      branch: 'Omaq',
      cash_sales: 5200.00, 
      visa_sales: 7200.00, 
      total_revenue: 12400.00, 
      expenses: 3200.00, 
      expense_category_id: '4',
      expense_category: 'Inventory',
      daily_profit: 9200.00, 
      employee_name: 'Fatima', 
      notes: '' 
    },
  ];

  const { control, handleSubmit, watch, setValue, reset, formState: { errors } } = useForm<SalesFormData>({
    resolver: zodResolver(salesEntrySchema),
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      branch_id: '',
      cash_sales: '',
      visa_sales: '',
      expenses: '',
      expense_category_id: '',
      employee_name: '',
      notes: '',
    }
  });

  // Calculate total revenue and daily profit
  const cashSales = parseFloat(watch('cash_sales') || '0');
  const visaSales = parseFloat(watch('visa_sales') || '0');
  const expenses = parseFloat(watch('expenses') || '0');
  const totalRevenue = cashSales + visaSales;
  const dailyProfit = totalRevenue - expenses;

  const onSubmit = async (data: SalesFormData) => {
    setIsSubmitting(true);
    
    try {
      // In a real application, this would be an API call
      console.log('Form data:', {
        ...data,
        total_revenue: totalRevenue,
        daily_profit: dailyProfit,
      });
      
      // Reset form or show success message
      setTimeout(() => {
        setIsSubmitting(false);
        reset({
          date: new Date().toISOString().split('T')[0],
          branch_id: '',
          cash_sales: '',
          visa_sales: '',
          expenses: '',
          expense_category_id: '',
          employee_name: '',
          notes: '',
        });
        alert(t('salesEntrySaved'));
      }, 1000);
    } catch (error) {
      console.error('Error saving sales entry:', error);
      alert(t('errorSavingSales'));
      setIsSubmitting(false);
    }
  };

  const handleExportSales = () => {
    setIsExporting(true);
    // Simulate export process
    setTimeout(() => {
      setIsExporting(false);
      alert(t('salesExported'));
    }, 1500);
  };

  const handlePrintSales = () => {
    alert(t('preparingPrint'));
    // In a real application, this would trigger print functionality
  };

  const handleEmailReport = () => {
    alert(t('emailSent'));
    // In a real application, this would send an email report
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setActiveTab('entry')}
              className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                activeTab === 'entry'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              <FiPlus className="inline-block mr-2" />
              {t('addSales')}
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('history');
                setShowSalesHistory(true);
              }}
              className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                activeTab === 'history'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              <FiBarChart2 className="inline-block mr-2" />
              {t('salesHistory')}
            </button>
          </div>
          
          {activeTab === 'history' && (
            <div className="flex space-x-2">
              <button
                onClick={handleExportSales}
                disabled={isExporting}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <FiDownload className={`mr-2 ${isExporting ? 'animate-spin' : ''}`} />
                {t('export')}
              </button>
              <button
                onClick={handlePrintSales}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiPrinter className="mr-2" />
                {t('print')}
              </button>
              <button
                onClick={handleEmailReport}
                className="inline-flex items-center px-3 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiMail className="mr-2" />
                {t('email')}
              </button>
            </div>
          )}
        </div>
      </div>
      
      {activeTab === 'entry' && (
        <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6 dark:text-white">{t('dailyEntry')}</h2>
          
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('date')}
                </label>
                <Controller
                  name="date"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="date"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-10"
                        {...field}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <FiCalendar className="text-gray-400" />
                      </div>
                    </div>
                  )}
                />
                {errors.date && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.date.message}</p>
                )}
              </div>
              
              {/* Branch */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('branch')}
                </label>
                <Controller
                  name="branch_id"
                  control={control}
                  render={({ field }) => (
                    <select
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    >
                      <option value="">{commonT('select')}</option>
                      {branches.map((branch) => (
                        <option key={branch.id} value={branch.id}>
                          {branch.name}
                        </option>
                      ))}
                    </select>
                  )}
                />
                {errors.branch_id && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.branch_id.message}</p>
                )}
              </div>
              
              {/* Cash Sales */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('cashSales')}
                </label>
                <Controller
                  name="cash_sales"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </div>
                  )}
                />
                {errors.cash_sales && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.cash_sales.message}</p>
                )}
              </div>
              
              {/* Visa Sales */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('visaSales')}
                </label>
                <Controller
                  name="visa_sales"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </div>
                  )}
                />
                {errors.visa_sales && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.visa_sales.message}</p>
                )}
              </div>
              
              {/* Total Revenue (calculated) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('totalRevenue')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-600 shadow-sm pl-8"
                    value={`${totalRevenue.toFixed(2)}`}
                    readOnly
                  />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500 dark:text-gray-400">﷼</span>
                  </div>
                </div>
              </div>
              
              {/* Expenses */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('expenses')}
                </label>
                <Controller
                  name="expenses"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                        placeholder="0.00"
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                        }}
                      />
                      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <span className="text-gray-500 dark:text-gray-400">﷼</span>
                      </div>
                    </div>
                  )}
                />
                {errors.expenses && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.expenses.message}</p>
                )}
              </div>
              
              {/* Expense Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('expenseCategory')}
                </label>
                <Controller
                  name="expense_category_id"
                  control={control}
                  render={({ field }) => (
                    <select
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    >
                      <option value="">{commonT('select')}</option>
                      {expenseCategories.map((category) => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  )}
                />
              </div>
              
              {/* Daily Profit (calculated) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('dailyProfit')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    className={`w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-600 shadow-sm pl-8 ${
                      dailyProfit < 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'
                    }`}
                    value={`${dailyProfit.toFixed(2)}`}
                    readOnly
                  />
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <span className="text-gray-500 dark:text-gray-400">﷼</span>
                  </div>
                </div>
              </div>
              
              {/* Employee Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('employeeName')}
                </label>
                <Controller
                  name="employee_name"
                  control={control}
                  render={({ field }) => (
                    <input
                      type="text"
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    />
                  )}
                />
              </div>
            </div>
            
            {/* Notes */}
            <div className="mt-6">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {t('notes')}
              </label>
              <Controller
                name="notes"
                control={control}
                render={({ field }) => (
                  <textarea
                    rows={3}
                    className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    {...field}
                  />
                )}
              />
            </div>
            
            {/* Submit Button */}
            <div className="mt-6 flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                <FiSave className="mr-2" />
                {isSubmitting ? t('saving') : commonT('save')}
              </button>
            </div>
          </form>
        </div>
      )}
      
      {activeTab === 'history' && (
        <div>
          {/* Date Filter */}
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-4 mb-6">
            <div className="flex flex-wrap items-center">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 mr-3">{t('filterByDate')}:</span>
              <div className="inline-flex rounded-md shadow-sm">
                <button
                  type="button"
                  onClick={() => setDateFilter('today')}
                  className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                    dateFilter === 'today'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  } border border-gray-300 dark:border-gray-600`}
                >
                  {t('today')}
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilter('week')}
                  className={`px-4 py-2 text-sm font-medium ${
                    dateFilter === 'week'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  } border-t border-b border-gray-300 dark:border-gray-600`}
                >
                  {t('thisWeek')}
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilter('month')}
                  className={`px-4 py-2 text-sm font-medium ${
                    dateFilter === 'month'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  } border-t border-b border-gray-300 dark:border-gray-600`}
                >
                  {t('thisMonth')}
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilter('custom')}
                  className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                    dateFilter === 'custom'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                  } border border-gray-300 dark:border-gray-600`}
                >
                  {t('custom')}
                </button>
              </div>
              
              {dateFilter === 'custom' && (
                <div className="flex items-center mt-3 sm:mt-0 sm:ml-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="date"
                      className="rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                    <span className="text-gray-500 dark:text-gray-400">-</span>
                    <input
                      type="date"
                      className="rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      className="px-3 py-2 text-sm font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      {t('apply')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Sales History Table */}
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 dark:text-white">{t('salesHistory')}</h2>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('date')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('branch')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('cashSales')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('visaSales')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('totalRevenue')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('expenses')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('expenseCategory')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('dailyProfit')}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      {t('employeeName')}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {salesHistory.map((entry) => (
                    <tr key={entry.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.date}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.branch}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.cash_sales.toFixed(2)} ﷼</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.visa_sales.toFixed(2)} ﷼</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{entry.total_revenue.toFixed(2)} ﷼</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.expenses.toFixed(2)} ﷼</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.expense_category}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600 dark:text-green-400">{entry.daily_profit.toFixed(2)} ﷼</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{entry.employee_name}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">{t('total')}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300"></td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                      {salesHistory.reduce((sum, entry) => sum + entry.cash_sales, 0).toFixed(2)} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                      {salesHistory.reduce((sum, entry) => sum + entry.visa_sales, 0).toFixed(2)} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                      {salesHistory.reduce((sum, entry) => sum + entry.total_revenue, 0).toFixed(2)} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                      {salesHistory.reduce((sum, entry) => sum + entry.expenses, 0).toFixed(2)} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300"></td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-green-600 dark:text-green-400">
                      {salesHistory.reduce((sum, entry) => sum + entry.daily_profit, 0).toFixed(2)} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300"></td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
