"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';

export default function DashboardLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  
  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };
  
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // Add class to html element for global dark mode
    if (!darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <div className={`${darkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
        <Sidebar 
          locale={locale} 
          collapsed={sidebarCollapsed} 
          toggleCollapse={toggleSidebar} 
        />
        <Header 
          toggleSidebar={toggleSidebar} 
          darkMode={darkMode} 
          toggleDarkMode={toggleDarkMode} 
        />
        
        <main className={`transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-64'} pt-16 min-h-screen`}>
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
