"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiSave, FiEdit, FiTrash2, FiPlus, FiMapPin, FiPhone, FiMail, FiUser } from 'react-icons/fi';

// Form validation schema
const branchFormSchema = z.object({
  name: z.string().min(1, { message: 'Branch name is required' }),
  name_ar: z.string().min(1, { message: 'Arabic name is required' }),
  location: z.string().min(1, { message: 'Location is required' }),
  manager_name: z.string().min(1, { message: 'Manager name is required' }),
  phone: z.string().min(1, { message: 'Phone number is required' }),
  email: z.string().email({ message: 'Invalid email address' }).optional().or(z.literal('')),
  address: z.string().min(1, { message: 'Address is required' }),
  opening_hours: z.string().optional(),
  is_active: z.boolean().default(true),
});

type BranchFormData = z.infer<typeof branchFormSchema>;

export default function BranchesPage() {
  const t = useTranslations('branches');
  const commonT = useTranslations('common');
  const [showBranchForm, setShowBranchForm] = useState(false);
  const [editingBranch, setEditingBranch] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedBranch, setSelectedBranch] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');

  // Sample data for demonstration
  const branches = [
    { 
      id: 1, 
      name: 'Industrial', 
      name_ar: 'الصناعية', 
      location: 'North District',
      manager_name: 'Mohammed Ali',
      phone: '+966 50 123 4567',
      email: 'industrial@supermarket.com',
      address: '123 Industrial Ave, North District',
      opening_hours: '8:00 AM - 11:00 PM',
      is_active: true,
      sales_last_month: 350000,
      profit_last_month: 87500,
      employees: 12,
      inventory_value: 125000
    },
    { 
      id: 2, 
      name: 'Fesah', 
      name_ar: 'فسح', 
      location: 'East District',
      manager_name: 'Ahmed Hassan',
      phone: '+966 50 765 4321',
      email: 'fesah@supermarket.com',
      address: '456 Fesah St, East District',
      opening_hours: '7:00 AM - 12:00 AM',
      is_active: true,
      sales_last_month: 320000,
      profit_last_month: 80000,
      employees: 10,
      inventory_value: 110000
    },
    { 
      id: 3, 
      name: 'Omaq', 
      name_ar: 'عمق', 
      location: 'West District',
      manager_name: 'Fatima Khalid',
      phone: '+966 50 987 6543',
      email: 'omaq@supermarket.com',
      address: '789 Omaq Blvd, West District',
      opening_hours: '8:00 AM - 10:00 PM',
      is_active: true,
      sales_last_month: 290000,
      profit_last_month: 72500,
      employees: 8,
      inventory_value: 95000
    },
  ];

  const { control, handleSubmit, reset: resetBranchForm, formState: { errors } } = useForm<BranchFormData>({
    resolver: zodResolver(branchFormSchema),
    defaultValues: {
      name: '',
      name_ar: '',
      location: '',
      manager_name: '',
      phone: '',
      email: '',
      address: '',
      opening_hours: '',
      is_active: true,
    }
  });

  const onBranchSubmit = (data: BranchFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('Branch data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowBranchForm(false);
      resetBranchForm();
      setEditingBranch(null);
      
      // Show success message
      alert(editingBranch ? t('branchUpdated') : t('branchAdded'));
    }, 1000);
  };

  const handleAddBranch = () => {
    resetBranchForm();
    setEditingBranch(null);
    setShowBranchForm(true);
  };

  const handleEditBranch = (branch: any) => {
    setEditingBranch(branch);
    resetBranchForm({
      name: branch.name,
      name_ar: branch.name_ar,
      location: branch.location,
      manager_name: branch.manager_name,
      phone: branch.phone,
      email: branch.email || '',
      address: branch.address,
      opening_hours: branch.opening_hours || '',
      is_active: branch.is_active,
    });
    setShowBranchForm(true);
  };

  const handleDeleteBranch = (branchId: number) => {
    if (confirm(t('confirmDelete'))) {
      console.log('Delete branch:', branchId);
      // In a real application, this would delete the branch
      alert(t('branchDeleted'));
    }
  };

  const handleViewBranchDetails = (branch: any) => {
    setSelectedBranch(branch);
    setViewMode('detail');
  };

  const handleBackToList = () => {
    setSelectedBranch(null);
    setViewMode('list');
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        {viewMode === 'list' && (
          <button 
            onClick={handleAddBranch}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <FiPlus className="mr-2" />
            {t('addBranch')}
          </button>
        )}
        
        {viewMode === 'detail' && (
          <div className="flex space-x-3">
            <button 
              onClick={() => handleEditBranch(selectedBranch)}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiEdit className="mr-2" />
              {t('editBranch')}
            </button>
            <button 
              onClick={handleBackToList}
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {t('backToList')}
            </button>
          </div>
        )}
      </div>
      
      {/* Branch Form Modal */}
      {showBranchForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingBranch ? t('editBranch') : t('addBranch')}
            </h2>
            
            <form onSubmit={handleSubmit(onBranchSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Branch Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('branchName')}
                  </label>
                  <Controller
                    name="name"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.name.message}</p>
                  )}
                </div>
                
                {/* Arabic Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('arabicName')}
                  </label>
                  <Controller
                    name="name_ar"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.name_ar && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.name_ar.message}</p>
                  )}
                </div>
                
                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('location')}
                  </label>
                  <Controller
                    name="location"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.location && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.location.message}</p>
                  )}
                </div>
                
                {/* Manager Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('managerName')}
                  </label>
                  <Controller
                    name="manager_name"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.manager_name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.manager_name.message}</p>
                  )}
                </div>
                
                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('phone')}
                  </label>
                  <Controller
                    name="phone"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="tel"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.phone && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.phone.message}</p>
                  )}
                </div>
                
                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('email')}
                  </label>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="email"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {errors.email && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.email.message}</p>
                  )}
                </div>
                
                {/* Opening Hours */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('openingHours')}
                  </label>
                  <Controller
                    name="opening_hours"
                    control={control}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="e.g. 8:00 AM - 10:00 PM"
                        {...field}
                      />
                    )}
                  />
                </div>
                
                {/* Is Active */}
                <div>
                  <div className="flex items-center h-full">
                    <Controller
                      name="is_active"
                      control={control}
                      render={({ field }) => (
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="is_active"
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 rounded"
                            checked={field.value}
                            onChange={field.onChange}
                          />
                          <label htmlFor="is_active" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            {t('isActive')}
                          </label>
                        </div>
                      )}
                    />
                  </div>
                </div>
              </div>
              
              {/* Address */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('address')}
                </label>
                <Controller
                  name="address"
                  control={control}
                  render={({ field }) => (
                    <textarea
                      rows={3}
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    />
                  )}
                />
                {errors.address && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.address.message}</p>
                )}
              </div>
              
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowBranchForm(false)}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  {commonT('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  <FiSave className="mr-2" />
                  {isSubmitting ? commonT('saving') : commonT('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Branch List View */}
      {viewMode === 'list' && (
        <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('branchName')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('location')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('managerName')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('phone')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('status')}
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('actions')}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {branches.map((branch) => (
                  <tr key={branch.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                          <span className="text-blue-600 dark:text-blue-400 font-semibold">
                            {branch.name.charAt(0)}
                          </span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900 dark:text-white cursor-pointer hover:text-blue-600 dark:hover:text-blue-400" onClick={() => handleViewBranchDetails(branch)}>
                            {branch.name}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {branch.name_ar}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {branch.location}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {branch.manager_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {branch.phone}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        branch.is_active 
                          ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                          : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                      }`}>
                        {branch.is_active ? t('active') : t('inactive')}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleViewBranchDetails(branch)}
                        className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                      >
                        {t('view')}
                      </button>
                      <button
                        onClick={() => handleEditBranch(branch)}
                        className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                      >
                        <FiEdit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteBranch(branch.id)}
                        className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Branch Detail View */}
      {viewMode === 'detail' && selectedBranch && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div className="flex items-center">
                <div className="h-16 w-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                  <span className="text-blue-600 dark:text-blue-400 text-2xl font-semibold">
                    {selectedBranch.name.charAt(0)}
                  </span>
                </div>
                <div className="ml-4">
                  <h2 className="text-2xl font-bold dark:text-white">{selectedBranch.name}</h2>
                  <p className="text-gray-500 dark:text-gray-400">{selectedBranch.name_ar}</p>
                </div>
              </div>
              <div>
                <span className={`px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full ${
                  selectedBranch.is_active 
                    ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                    : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                }`}>
                  {selectedBranch.is_active ? t('active') : t('inactive')}
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium dark:text-white mb-4">{t('contactInformation')}</h3>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <FiMapPin className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('address')}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.address}</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <FiPhone className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('phone')}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.phone}</p>
                    </div>
                  </div>
                  {selectedBranch.email && (
                    <div className="flex items-start">
                      <FiMail className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('email')}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.email}</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-start">
                    <FiUser className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('managerName')}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.manager_name}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium dark:text-white mb-4">{t('operationalDetails')}</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('location')}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.location}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('openingHours')}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.opening_hours || t('notSpecified')}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('employees')}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{selectedBranch.employees}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
              <h3 className="text-lg font-medium dark:text-white mb-4">{t('salesLastMonth')}</h3>
              <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">{selectedBranch.sales_last_month.toLocaleString()} ﷼</p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
              <h3 className="text-lg font-medium dark:text-white mb-4">{t('profitLastMonth')}</h3>
              <p className="text-3xl font-bold text-green-600 dark:text-green-400">{selectedBranch.profit_last_month.toLocaleString()} ﷼</p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
              <h3 className="text-lg font-medium dark:text-white mb-4">{t('inventoryValue')}</h3>
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{selectedBranch.inventory_value.toLocaleString()} ﷼</p>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
            <h3 className="text-lg font-medium dark:text-white mb-4">{t('recentActivity')}</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                    <FiShoppingCart className="text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium dark:text-white">{t('salesRecorded')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">₹ 12,400</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">10 minutes ago</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                    <FiUser className="text-green-600 dark:text-green-400" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium dark:text-white">{t('employeeAdded')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Ahmed Hassan</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">1 hour ago</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900 flex items-center justify-center">
                    <FiAlertTriangle className="text-orange-600 dark:text-orange-400" />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium dark:text-white">{t('lowStockAlert')}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Rice - 3 units remaining</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">2 hours ago</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
