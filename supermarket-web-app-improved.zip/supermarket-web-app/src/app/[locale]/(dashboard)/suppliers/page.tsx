"use client";

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiSave, FiEdit, FiTrash2, FiPlus, FiPackage, FiPhone, FiMail, FiFileText, FiCalendar, FiDollarSign, FiTruck, FiCheck, FiX } from 'react-icons/fi';

// Form validation schema
const supplierFormSchema = z.object({
  name: z.string().min(1, { message: 'Supplier name is required' }),
  contact_person: z.string().min(1, { message: 'Contact person is required' }),
  phone: z.string().min(1, { message: 'Phone number is required' }),
  email: z.string().email({ message: 'Invalid email address' }).optional().or(z.literal('')),
  address: z.string().min(1, { message: 'Address is required' }),
  product_categories: z.string().min(1, { message: 'Product categories is required' }),
  payment_terms: z.string().optional(),
  notes: z.string().optional(),
  is_active: z.boolean().default(true),
});

type SupplierFormData = z.infer<typeof supplierFormSchema>;

// Order form schema
const orderFormSchema = z.object({
  supplier_id: z.string().min(1, { message: 'Supplier is required' }),
  order_date: z.string().min(1, { message: 'Order date is required' }),
  expected_delivery: z.string().min(1, { message: 'Expected delivery date is required' }),
  items: z.string().min(1, { message: 'Order items are required' }),
  total_amount: z.string().min(1, { message: 'Total amount is required' }),
  payment_status: z.string().min(1, { message: 'Payment status is required' }),
  delivery_status: z.string().min(1, { message: 'Delivery status is required' }),
  notes: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderFormSchema>;

export default function SuppliersPage() {
  const t = useTranslations('suppliers');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('suppliers');
  const [showSupplierForm, setShowSupplierForm] = useState(false);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<any>(null);
  const [editingOrder, setEditingOrder] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');

  // Sample data for demonstration
  const suppliers = [
    { 
      id: 1, 
      name: 'Al-Marai Foods', 
      contact_person: 'Abdullah Al-Otaibi',
      phone: '+966 50 123 4567',
      email: 'abdullah@almarai.com',
      address: '123 Industrial City, Riyadh',
      product_categories: 'Dairy, Juices, Bakery',
      payment_terms: 'Net 30',
      notes: 'Preferred supplier for dairy products',
      is_active: true,
      total_orders: 24,
      total_spent: 125000,
      last_order_date: '2025-03-15',
      avg_delivery_days: 2
    },
    { 
      id: 2, 
      name: 'Saudi Vegetables Co.', 
      contact_person: 'Mohammed Al-Qahtani',
      phone: '+966 50 234 5678',
      email: 'mohammed@saudiveg.com',
      address: '456 Farm District, Dammam',
      product_categories: 'Vegetables, Fruits',
      payment_terms: 'Net 15',
      notes: 'Local produce supplier',
      is_active: true,
      total_orders: 36,
      total_spent: 85000,
      last_order_date: '2025-03-20',
      avg_delivery_days: 1
    },
    { 
      id: 3, 
      name: 'Global Imports Ltd.', 
      contact_person: 'Sarah Johnson',
      phone: '+966 50 345 6789',
      email: 'sarah@globalimports.com',
      address: '789 Port Area, Jeddah',
      product_categories: 'Canned Goods, Imported Foods',
      payment_terms: 'Net 45',
      notes: 'International food importer',
      is_active: true,
      total_orders: 18,
      total_spent: 210000,
      last_order_date: '2025-03-10',
      avg_delivery_days: 5
    },
    { 
      id: 4, 
      name: 'Clean Supplies Co.', 
      contact_person: 'Khalid Al-Harbi',
      phone: '+966 50 456 7890',
      email: 'khalid@cleansupplies.com',
      address: '101 Commercial St, Riyadh',
      product_categories: 'Cleaning Products, Paper Goods',
      payment_terms: 'Net 30',
      notes: '',
      is_active: false,
      total_orders: 12,
      total_spent: 45000,
      last_order_date: '2025-02-25',
      avg_delivery_days: 3
    },
  ];

  const orders = [
    {
      id: 1,
      supplier_id: 1,
      supplier_name: 'Al-Marai Foods',
      order_date: '2025-03-15',
      expected_delivery: '2025-03-17',
      actual_delivery: '2025-03-17',
      items: 'Milk (100 units), Yogurt (200 units), Cheese (50 units)',
      total_amount: 12500,
      payment_status: 'paid',
      delivery_status: 'delivered',
      notes: ''
    },
    {
      id: 2,
      supplier_id: 2,
      supplier_name: 'Saudi Vegetables Co.',
      order_date: '2025-03-20',
      expected_delivery: '2025-03-21',
      actual_delivery: '2025-03-21',
      items: 'Tomatoes (100kg), Cucumbers (80kg), Lettuce (50kg)',
      total_amount: 8500,
      payment_status: 'paid',
      delivery_status: 'delivered',
      notes: ''
    },
    {
      id: 3,
      supplier_id: 3,
      supplier_name: 'Global Imports Ltd.',
      order_date: '2025-03-10',
      expected_delivery: '2025-03-15',
      actual_delivery: '2025-03-16',
      items: 'Canned Tuna (200 units), Pasta (300 units), Olive Oil (100 units)',
      total_amount: 15000,
      payment_status: 'pending',
      delivery_status: 'delivered',
      notes: 'Delivery was delayed by one day'
    },
    {
      id: 4,
      supplier_id: 1,
      supplier_name: 'Al-Marai Foods',
      order_date: '2025-03-22',
      expected_delivery: '2025-03-24',
      actual_delivery: null,
      items: 'Milk (150 units), Yogurt (250 units), Juice (100 units)',
      total_amount: 14000,
      payment_status: 'pending',
      delivery_status: 'in_transit',
      notes: ''
    },
    {
      id: 5,
      supplier_id: 2,
      supplier_name: 'Saudi Vegetables Co.',
      order_date: '2025-03-23',
      expected_delivery: '2025-03-24',
      actual_delivery: null,
      items: 'Potatoes (200kg), Onions (150kg), Carrots (100kg)',
      total_amount: 9000,
      payment_status: 'pending',
      delivery_status: 'processing',
      notes: ''
    },
  ];

  const { control: supplierControl, handleSubmit: handleSupplierSubmit, reset: resetSupplierForm, formState: { errors: supplierErrors } } = useForm<SupplierFormData>({
    resolver: zodResolver(supplierFormSchema),
    defaultValues: {
      name: '',
      contact_person: '',
      phone: '',
      email: '',
      address: '',
      product_categories: '',
      payment_terms: '',
      notes: '',
      is_active: true,
    }
  });

  const { control: orderControl, handleSubmit: handleOrderSubmit, reset: resetOrderForm, formState: { errors: orderErrors } } = useForm<OrderFormData>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      supplier_id: '',
      order_date: new Date().toISOString().split('T')[0],
      expected_delivery: '',
      items: '',
      total_amount: '',
      payment_status: 'pending',
      delivery_status: 'processing',
      notes: '',
    }
  });

  const onSupplierSubmit = (data: SupplierFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('Supplier data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSupplierForm(false);
      resetSupplierForm();
      setEditingSupplier(null);
      
      // Show success message
      alert(editingSupplier ? t('supplierUpdated') : t('supplierAdded'));
    }, 1000);
  };

  const onOrderSubmit = (data: OrderFormData) => {
    setIsSubmitting(true);
    
    // In a real application, this would be an API call
    console.log('Order data:', data);
    
    setTimeout(() => {
      setIsSubmitting(false);
      setShowOrderForm(false);
      resetOrderForm();
      setEditingOrder(null);
      
      // Show success message
      alert(editingOrder ? t('orderUpdated') : t('orderAdded'));
    }, 1000);
  };

  const handleAddSupplier = () => {
    resetSupplierForm();
    setEditingSupplier(null);
    setShowSupplierForm(true);
  };

  const handleEditSupplier = (supplier: any) => {
    setEditingSupplier(supplier);
    resetSupplierForm({
      name: supplier.name,
      contact_person: supplier.contact_person,
      phone: supplier.phone,
      email: supplier.email || '',
      address: supplier.address,
      product_categories: supplier.product_categories,
      payment_terms: supplier.payment_terms || '',
      notes: supplier.notes || '',
      is_active: supplier.is_active,
    });
    setShowSupplierForm(true);
  };

  const handleDeleteSupplier = (supplierId: number) => {
    if (confirm(t('confirmDeleteSupplier'))) {
      console.log('Delete supplier:', supplierId);
      // In a real application, this would delete the supplier
      alert(t('supplierDeleted'));
    }
  };

  const handleViewSupplierDetails = (supplier: any) => {
    setSelectedSupplier(supplier);
    setViewMode('detail');
  };

  const handleBackToList = () => {
    setSelectedSupplier(null);
    setViewMode('list');
  };

  const handleAddOrder = () => {
    resetOrderForm();
    setEditingOrder(null);
    setShowOrderForm(true);
  };

  const handleEditOrder = (order: any) => {
    setEditingOrder(order);
    resetOrderForm({
      supplier_id: order.supplier_id.toString(),
      order_date: order.order_date,
      expected_delivery: order.expected_delivery,
      items: order.items,
      total_amount: order.total_amount.toString(),
      payment_status: order.payment_status,
      delivery_status: order.delivery_status,
      notes: order.notes || '',
    });
    setShowOrderForm(true);
  };

  const handleDeleteOrder = (orderId: number) => {
    if (confirm(t('confirmDeleteOrder'))) {
      console.log('Delete order:', orderId);
      // In a real application, this would delete the order
      alert(t('orderDeleted'));
    }
  };

  const getSupplierOrders = (supplierId: number) => {
    return orders.filter(order => order.supplier_id === supplierId);
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold dark:text-white mb-4 md:mb-0">{t('title')}</h1>
        
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => setActiveTab('suppliers')}
              className={`px-4 py-2 text-sm font-medium rounded-l-lg ${
                activeTab === 'suppliers'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('suppliers')}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('orders')}
              className={`px-4 py-2 text-sm font-medium rounded-r-lg ${
                activeTab === 'orders'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              } border border-gray-300 dark:border-gray-600`}
            >
              {t('orders')}
            </button>
          </div>
          
          {activeTab === 'suppliers' && viewMode === 'list' && (
            <button 
              onClick={handleAddSupplier}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiPlus className="mr-2" />
              {t('addSupplier')}
            </button>
          )}
          
          {activeTab === 'orders' && (
            <button 
              onClick={handleAddOrder}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiPlus className="mr-2" />
              {t('addOrder')}
            </button>
          )}
          
          {activeTab === 'suppliers' && viewMode === 'detail' && (
            <div className="flex space-x-3">
              <button 
                onClick={() => handleEditSupplier(selectedSupplier)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiEdit className="mr-2" />
                {t('editSupplier')}
              </button>
              <button 
                onClick={handleBackToList}
                className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {t('backToList')}
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Supplier Form Modal */}
      {showSupplierForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingSupplier ? t('editSupplier') : t('addSupplier')}
            </h2>
            
            <form onSubmit={handleSupplierSubmit(onSupplierSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Supplier Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('supplierName')}
                  </label>
                  <Controller
                    name="name"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.name && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.name.message}</p>
                  )}
                </div>
                
                {/* Contact Person */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('contactPerson')}
                  </label>
                  <Controller
                    name="contact_person"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.contact_person && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.contact_person.message}</p>
                  )}
                </div>
                
                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('phone')}
                  </label>
                  <Controller
                    name="phone"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="tel"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.phone && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.phone.message}</p>
                  )}
                </div>
                
                {/* Email */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('email')}
                  </label>
                  <Controller
                    name="email"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="email"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.email && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.email.message}</p>
                  )}
                </div>
                
                {/* Product Categories */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('productCategories')}
                  </label>
                  <Controller
                    name="product_categories"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder={t('categoriesPlaceholder')}
                        {...field}
                      />
                    )}
                  />
                  {supplierErrors.product_categories && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.product_categories.message}</p>
                  )}
                </div>
                
                {/* Payment Terms */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('paymentTerms')}
                  </label>
                  <Controller
                    name="payment_terms"
                    control={supplierControl}
                    render={({ field }) => (
                      <input
                        type="text"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="e.g. Net 30"
                        {...field}
                      />
                    )}
                  />
                </div>
                
                {/* Is Active */}
                <div>
                  <div className="flex items-center h-full pt-6">
                    <Controller
                      name="is_active"
                      control={supplierControl}
                      render={({ field }) => (
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="is_active"
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600 rounded"
                            checked={field.value}
                            onChange={field.onChange}
                          />
                          <label htmlFor="is_active" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                            {t('isActive')}
                          </label>
                        </div>
                      )}
                    />
                  </div>
                </div>
              </div>
              
              {/* Address */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('address')}
                </label>
                <Controller
                  name="address"
                  control={supplierControl}
                  render={({ field }) => (
                    <textarea
                      rows={2}
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    />
                  )}
                />
                {supplierErrors.address && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{supplierErrors.address.message}</p>
                )}
              </div>
              
              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('notes')}
                </label>
                <Controller
                  name="notes"
                  control={supplierControl}
                  render={({ field }) => (
                    <textarea
                      rows={3}
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    />
                  )}
                />
              </div>
              
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowSupplierForm(false)}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  {commonT('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  <FiSave className="mr-2" />
                  {isSubmitting ? commonT('saving') : commonT('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Order Form Modal */}
      {showOrderForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">
              {editingOrder ? t('editOrder') : t('addOrder')}
            </h2>
            
            <form onSubmit={handleOrderSubmit(onOrderSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Supplier */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('supplier')}
                  </label>
                  <Controller
                    name="supplier_id"
                    control={orderControl}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="">{commonT('select')}</option>
                        {suppliers.filter(s => s.is_active).map((supplier) => (
                          <option key={supplier.id} value={supplier.id}>
                            {supplier.name}
                          </option>
                        ))}
                      </select>
                    )}
                  />
                  {orderErrors.supplier_id && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.supplier_id.message}</p>
                  )}
                </div>
                
                {/* Order Date */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('orderDate')}
                  </label>
                  <Controller
                    name="order_date"
                    control={orderControl}
                    render={({ field }) => (
                      <input
                        type="date"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {orderErrors.order_date && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.order_date.message}</p>
                  )}
                </div>
                
                {/* Expected Delivery */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('expectedDelivery')}
                  </label>
                  <Controller
                    name="expected_delivery"
                    control={orderControl}
                    render={({ field }) => (
                      <input
                        type="date"
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      />
                    )}
                  />
                  {orderErrors.expected_delivery && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.expected_delivery.message}</p>
                  )}
                </div>
                
                {/* Total Amount */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('totalAmount')}
                  </label>
                  <Controller
                    name="total_amount"
                    control={orderControl}
                    render={({ field }) => (
                      <div className="relative">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-8"
                          {...field}
                        />
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                          <span className="text-gray-500 dark:text-gray-400">﷼</span>
                        </div>
                      </div>
                    )}
                  />
                  {orderErrors.total_amount && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.total_amount.message}</p>
                  )}
                </div>
                
                {/* Payment Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('paymentStatus')}
                  </label>
                  <Controller
                    name="payment_status"
                    control={orderControl}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="pending">{t('pending')}</option>
                        <option value="partial">{t('partial')}</option>
                        <option value="paid">{t('paid')}</option>
                      </select>
                    )}
                  />
                  {orderErrors.payment_status && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.payment_status.message}</p>
                  )}
                </div>
                
                {/* Delivery Status */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('deliveryStatus')}
                  </label>
                  <Controller
                    name="delivery_status"
                    control={orderControl}
                    render={({ field }) => (
                      <select
                        className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        {...field}
                      >
                        <option value="processing">{t('processing')}</option>
                        <option value="in_transit">{t('inTransit')}</option>
                        <option value="delivered">{t('delivered')}</option>
                      </select>
                    )}
                  />
                  {orderErrors.delivery_status && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.delivery_status.message}</p>
                  )}
                </div>
              </div>
              
              {/* Order Items */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('orderItems')}
                </label>
                <Controller
                  name="items"
                  control={orderControl}
                  render={({ field }) => (
                    <textarea
                      rows={3}
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder={t('itemsPlaceholder')}
                      {...field}
                    />
                  )}
                />
                {orderErrors.items && (
                  <p className="mt-1 text-sm text-red-600 dark:text-red-400">{orderErrors.items.message}</p>
                )}
              </div>
              
              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  {t('notes')}
                </label>
                <Controller
                  name="notes"
                  control={orderControl}
                  render={({ field }) => (
                    <textarea
                      rows={2}
                      className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      {...field}
                    />
                  )}
                />
              </div>
              
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowOrderForm(false)}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  {commonT('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                >
                  <FiSave className="mr-2" />
                  {isSubmitting ? commonT('saving') : commonT('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Suppliers Tab Content */}
      {activeTab === 'suppliers' && (
        <>
          {/* Supplier List View */}
          {viewMode === 'list' && (
            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('supplierName')}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('contact')}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('productCategories')}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('totalOrders')}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('lastOrder')}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('status')}
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        {t('actions')}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {suppliers.map((supplier) => (
                      <tr key={supplier.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                              <FiPackage className="text-blue-600 dark:text-blue-400" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900 dark:text-white cursor-pointer hover:text-blue-600 dark:hover:text-blue-400" onClick={() => handleViewSupplierDetails(supplier)}>
                                {supplier.name}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                {supplier.payment_terms}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900 dark:text-white">{supplier.contact_person}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{supplier.phone}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {supplier.product_categories}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {supplier.total_orders}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {supplier.last_order_date}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            supplier.is_active 
                              ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                              : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                          }`}>
                            {supplier.is_active ? t('active') : t('inactive')}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => handleViewSupplierDetails(supplier)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                          >
                            {t('view')}
                          </button>
                          <button
                            onClick={() => handleEditSupplier(supplier)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                          >
                            <FiEdit size={18} />
                          </button>
                          <button
                            onClick={() => handleDeleteSupplier(supplier.id)}
                            className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                          >
                            <FiTrash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          {/* Supplier Detail View */}
          {viewMode === 'detail' && selectedSupplier && (
            <div className="space-y-6">
              <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                  <div className="flex items-center">
                    <div className="h-16 w-16 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                      <FiPackage className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="ml-4">
                      <h2 className="text-2xl font-bold dark:text-white">{selectedSupplier.name}</h2>
                      <p className="text-gray-500 dark:text-gray-400">{selectedSupplier.product_categories}</p>
                    </div>
                  </div>
                  <div>
                    <span className={`px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full ${
                      selectedSupplier.is_active 
                        ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                        : 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
                    }`}>
                      {selectedSupplier.is_active ? t('active') : t('inactive')}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium dark:text-white mb-4">{t('contactInformation')}</h3>
                    <div className="space-y-3">
                      <div className="flex items-start">
                        <FiUser className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('contactPerson')}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.contact_person}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <FiPhone className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('phone')}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.phone}</p>
                        </div>
                      </div>
                      {selectedSupplier.email && (
                        <div className="flex items-start">
                          <FiMail className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                          <div>
                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('email')}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.email}</p>
                          </div>
                        </div>
                      )}
                      <div className="flex items-start">
                        <FiMapPin className="mt-1 text-gray-500 dark:text-gray-400 mr-3" />
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('address')}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.address}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium dark:text-white mb-4">{t('businessDetails')}</h3>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('productCategories')}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.product_categories}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('paymentTerms')}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.payment_terms || t('notSpecified')}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('avgDeliveryDays')}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.avg_delivery_days}</p>
                      </div>
                      {selectedSupplier.notes && (
                        <div>
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('notes')}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{selectedSupplier.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                  <h3 className="text-lg font-medium dark:text-white mb-4">{t('totalOrders')}</h3>
                  <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">{selectedSupplier.total_orders}</p>
                </div>
                
                <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                  <h3 className="text-lg font-medium dark:text-white mb-4">{t('totalSpent')}</h3>
                  <p className="text-3xl font-bold text-green-600 dark:text-green-400">{selectedSupplier.total_spent.toLocaleString()} ﷼</p>
                </div>
                
                <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                  <h3 className="text-lg font-medium dark:text-white mb-4">{t('lastOrderDate')}</h3>
                  <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{selectedSupplier.last_order_date}</p>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-lg font-medium dark:text-white">{t('recentOrders')}</h3>
                  <button
                    onClick={handleAddOrder}
                    className="mt-2 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <FiPlus className="mr-2" />
                    {t('newOrder')}
                  </button>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead className="bg-gray-50 dark:bg-gray-700">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                          {t('orderDate')}
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                          {t('items')}
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                          {t('totalAmount')}
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                          {t('status')}
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                          {t('actions')}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                      {getSupplierOrders(selectedSupplier.id).map((order) => (
                        <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {order.order_date}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 max-w-xs truncate">
                            {order.items}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {order.total_amount.toLocaleString()} ﷼
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col space-y-1">
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                order.payment_status === 'paid' 
                                  ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                                  : order.payment_status === 'partial'
                                    ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300'
                              }`}>
                                {t(order.payment_status)}
                              </span>
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                order.delivery_status === 'delivered' 
                                  ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                                  : order.delivery_status === 'in_transit'
                                    ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'
                                    : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                              }`}>
                                {t(order.delivery_status)}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => handleEditOrder(order)}
                              className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                            >
                              <FiEdit size={18} />
                            </button>
                            <button
                              onClick={() => handleDeleteOrder(order.id)}
                              className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                            >
                              <FiTrash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {getSupplierOrders(selectedSupplier.id).length === 0 && (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                            {t('noOrders')}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}
      
      {/* Orders Tab Content */}
      {activeTab === 'orders' && (
        <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('orderInfo')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('supplier')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('items')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('amount')}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('status')}
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    {t('actions')}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {orders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                          <FiFileText className="text-blue-600 dark:text-blue-400" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            #{order.id}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {order.order_date}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {order.supplier_name}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 max-w-xs truncate">
                      {order.items}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {order.total_amount.toLocaleString()} ﷼
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col space-y-1">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          order.payment_status === 'paid' 
                            ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                            : order.payment_status === 'partial'
                              ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300'
                        }`}>
                          {t(order.payment_status)}
                        </span>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          order.delivery_status === 'delivered' 
                            ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                            : order.delivery_status === 'in_transit'
                              ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'
                              : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                        }`}>
                          {t(order.delivery_status)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => handleEditOrder(order)}
                        className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-3"
                      >
                        <FiEdit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteOrder(order.id)}
                        className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
