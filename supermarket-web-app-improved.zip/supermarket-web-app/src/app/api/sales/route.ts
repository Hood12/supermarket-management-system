import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';

export async function GET(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const dailySales = await dbService.getDailySales();
    
    return NextResponse.json({ dailySales });
  } catch (error) {
    console.error('Error fetching daily sales:', error);
    return NextResponse.json(
      { error: 'Failed to fetch daily sales' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const data = await request.json();
    
    // Calculate total revenue and daily profit
    const cashSales = parseFloat(data.cash_sales);
    const visaSales = parseFloat(data.visa_sales);
    const expenses = parseFloat(data.expenses);
    const totalRevenue = cashSales + visaSales;
    const dailyProfit = totalRevenue - expenses;
    
    const salesData = {
      date: data.date,
      branch_id: parseInt(data.branch_id),
      cash_sales: cashSales,
      visa_sales: visaSales,
      total_revenue: totalRevenue,
      expenses: expenses,
      expense_category_id: data.expense_category_id ? parseInt(data.expense_category_id) : null,
      daily_profit: dailyProfit,
      employee_name: data.employee_name,
      notes: data.notes
    };
    
    const id = await dbService.createDailySales(salesData);
    
    return NextResponse.json({ id, success: true });
  } catch (error) {
    console.error('Error creating daily sales:', error);
    return NextResponse.json(
      { error: 'Failed to create daily sales entry' },
      { status: 500 }
    );
  }
}
