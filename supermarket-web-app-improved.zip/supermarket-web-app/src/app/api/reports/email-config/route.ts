import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';

export async function GET(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const emailConfig = await dbService.getEmailReportConfig();
    
    return NextResponse.json({ config: emailConfig });
  } catch (error) {
    console.error('Error fetching email config:', error);
    return NextResponse.json(
      { error: 'Failed to fetch email configuration' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const data = await request.json();
    
    await dbService.updateEmailReportConfig({
      recipient_email: data.recipient_email,
      subject: data.subject,
      send_time: data.send_time,
      frequency: data.frequency,
      include_sales_summary: data.include_sales_summary,
      include_profit_summary: data.include_profit_summary,
      include_branch_comparison: data.include_branch_comparison,
      include_inventory_alerts: data.include_inventory_alerts
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error updating email config:', error);
    return NextResponse.json(
      { error: 'Failed to update email configuration' },
      { status: 500 }
    );
  }
}
