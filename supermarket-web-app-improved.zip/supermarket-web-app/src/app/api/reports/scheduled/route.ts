import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';
import { Resend } from 'resend';

// Create a scheduled task that runs daily to send reports
export async function GET(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    // Get email configuration
    const emailConfig = await dbService.getEmailReportConfig();
    
    if (!emailConfig) {
      return NextResponse.json(
        { error: 'Email configuration not found' },
        { status: 404 }
      );
    }
    
    // Check if it's time to send the report
    const now = new Date();
    const [hours, minutes] = emailConfig.send_time.split(':').map(Number);
    const scheduledTime = new Date();
    scheduledTime.setHours(hours, minutes, 0, 0);
    
    // Only send if current time is within 5 minutes of scheduled time
    // This is a simplified approach for demonstration
    const timeDiff = Math.abs(now.getTime() - scheduledTime.getTime());
    const withinScheduledWindow = timeDiff <= 5 * 60 * 1000; // 5 minutes
    
    // Check frequency
    let shouldSend = false;
    if (emailConfig.frequency === 'daily') {
      shouldSend = withinScheduledWindow;
    } else if (emailConfig.frequency === 'weekly') {
      shouldSend = withinScheduledWindow && now.getDay() === 0; // Sunday
    } else if (emailConfig.frequency === 'monthly') {
      shouldSend = withinScheduledWindow && now.getDate() === 1; // First day of month
    }
    
    if (!shouldSend) {
      return NextResponse.json({
        success: false,
        message: 'Not scheduled to send at this time'
      });
    }
    
    // If it's time to send, call the send-email endpoint
    const response = await fetch(`${request.nextUrl.origin}/api/reports/send-email`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const result = await response.json();
    
    return NextResponse.json({
      success: true,
      message: 'Scheduled report sent successfully',
      result
    });
  } catch (error) {
    console.error('Error in scheduled report:', error);
    return NextResponse.json(
      { error: 'Failed to process scheduled report' },
      { status: 500 }
    );
  }
}
