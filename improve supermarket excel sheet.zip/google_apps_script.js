/**
 * Supermarket Management System - Google Apps Script for Email Reporting
 * This script provides automated email reporting functionality for the Supermarket Management System
 */

// Create a custom menu when the spreadsheet is opened
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('Supermarket Reports')
    .addItem('Send Report Now', 'sendDailyReport')
    .addItem('Schedule Daily Reports', 'setupTrigger')
    .addToUi();
}

/**
 * Sends a daily report email with supermarket data
 */
function sendDailyReport() {
  // Get the active spreadsheet and the Reports sheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var reportsSheet = ss.getSheetByName('Reports');
  
  // If Reports sheet doesn't exist, show an error
  if (!reportsSheet) {
    SpreadsheetApp.getUi().alert('Reports sheet not found. Please make sure the sheet exists.');
    return;
  }
  
  // Get email settings from the Reports sheet
  var recipientEmail = reportsSheet.getRange('B4').getValue();
  var emailSubject = reportsSheet.getRange('B5').getValue();
  
  // If no email is specified, use default
  if (!recipientEmail) {
    recipientEmail = 'muneer1122337@gmail.com';
  }
  
  // If no subject is specified, use default
  if (!emailSubject) {
    emailSubject = 'تقرير السوبرماركت اليومي / Daily Supermarket Report';
  }
  
  // Get the Daily Entry sheet for data
  var dailyEntrySheet = ss.getSheetByName('Daily Entry');
  if (!dailyEntrySheet) {
    SpreadsheetApp.getUi().alert('Daily Entry sheet not found. Please make sure the sheet exists.');
    return;
  }
  
  // Prepare email body
  var today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  var emailBody = 'تقرير السوبرماركت اليومي / Daily Supermarket Report\n\n';
  emailBody += 'التاريخ / Date: ' + today + '\n\n';
  
  // Add daily sales summary to email body
  emailBody += 'ملخص المبيعات اليومية / Daily Sales Summary:\n';
  emailBody += '-------------------------------------------\n';
  
  // Get total values from the Reports sheet
  var totalCashSales = reportsSheet.getRange('B22').getValue();
  var totalVisaSales = reportsSheet.getRange('C22').getValue();
  var totalRevenue = reportsSheet.getRange('D22').getValue();
  var totalExpenses = reportsSheet.getRange('E22').getValue();
  var netProfit = reportsSheet.getRange('F22').getValue();
  
  // Format currency values
  var formatCurrency = function(value) {
    return Utilities.formatString('%.2f ﷼', value);
  };
  
  // Add summary data to email
  emailBody += 'إجمالي المبيعات (كاش) / Total Cash Sales: ' + formatCurrency(totalCashSales) + '\n';
  emailBody += 'إجمالي المبيعات (فيزا) / Total Visa Sales: ' + formatCurrency(totalVisaSales) + '\n';
  emailBody += 'إجمالي الإيرادات / Total Revenue: ' + formatCurrency(totalRevenue) + '\n';
  emailBody += 'إجمالي المصروفات / Total Expenses: ' + formatCurrency(totalExpenses) + '\n';
  emailBody += 'صافي الربح / Net Profit: ' + formatCurrency(netProfit) + '\n\n';
  
  // Add branch comparison to email body
  emailBody += 'مقارنة الفروع / Branch Comparison:\n';
  emailBody += '-------------------------------------------\n';
  
  // Get branch data from the Reports sheet
  var branches = ['Industrial', 'Fesah', 'Omaq'];
  for (var i = 0; i < branches.length; i++) {
    var row = 26 + i;
    var branchName = reportsSheet.getRange('A' + row).getValue();
    var branchSales = reportsSheet.getRange('B' + row).getValue();
    var branchProfit = reportsSheet.getRange('D' + row).getValue();
    var branchMargin = reportsSheet.getRange('E' + row).getValue();
    
    emailBody += branchName + ':\n';
    emailBody += '  المبيعات / Sales: ' + formatCurrency(branchSales) + '\n';
    emailBody += '  الربح / Profit: ' + formatCurrency(branchProfit) + '\n';
    emailBody += '  نسبة الربح / Margin: ' + Utilities.formatString('%.2f%%', branchMargin * 100) + '\n\n';
  }
  
  // Add inventory alerts if enabled
  var includeInventoryAlerts = reportsSheet.getRange('B13').getValue() === '✓';
  if (includeInventoryAlerts) {
    var inventorySheet = ss.getSheetByName('Inventory');
    if (inventorySheet) {
      emailBody += 'تنبيهات المخزون / Inventory Alerts:\n';
      emailBody += '-------------------------------------------\n';
      
      // Check for low inventory items
      var lastRow = inventorySheet.getLastRow();
      var lowInventoryCount = 0;
      
      for (var row = 2; row <= lastRow; row++) {
        var quantity = inventorySheet.getRange('F' + row).getValue();
        var minLevel = inventorySheet.getRange('G' + row).getValue();
        
        if (quantity < minLevel) {
          var productCode = inventorySheet.getRange('A' + row).getValue();
          var productName = inventorySheet.getRange('B' + row).getValue();
          var available = inventorySheet.getRange('F' + row).getValue();
          
          emailBody += productCode + ' - ' + productName + ': ' + available + ' (الحد الأدنى / Min: ' + minLevel + ')\n';
          lowInventoryCount++;
        }
      }
      
      if (lowInventoryCount === 0) {
        emailBody += 'لا توجد منتجات تحت الحد الأدنى للمخزون / No products below minimum stock level.\n\n';
      } else {
        emailBody += '\n';
      }
    }
  }
  
  // Add footer
  emailBody += '-------------------------------------------\n';
  emailBody += 'تم إنشاء هذا التقرير تلقائيًا بواسطة نظام إدارة السوبرماركت\n';
  emailBody += 'This report was automatically generated by the Supermarket Management System';
  
  // Create a PDF of the Reports sheet to attach to the email
  var reportBlob = createReportPDF();
  
  // Send the email
  if (reportBlob) {
    // Send with attachment
    MailApp.sendEmail({
      to: recipientEmail,
      subject: emailSubject,
      body: emailBody,
      attachments: [reportBlob]
    });
  } else {
    // Send without attachment if PDF creation failed
    MailApp.sendEmail(recipientEmail, emailSubject, emailBody);
  }
  
  // Show confirmation
  SpreadsheetApp.getUi().alert('تم إرسال التقرير بنجاح إلى ' + recipientEmail + '\nReport sent successfully to ' + recipientEmail);
}

/**
 * Creates a PDF of the Reports sheet
 * @return {Blob} PDF blob of the report
 */
function createReportPDF() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var reportsSheet = ss.getSheetByName('Reports');
    
    // Get the spreadsheet URL
    var url = ss.getUrl();
    
    // Replace /edit with /export?format=pdf
    url = url.replace(/\/edit.*$/, '/export?');
    
    // Add parameters for exporting
    var exportOptions = 
        'exportFormat=pdf&' +
        'format=pdf&' +
        'size=letter&' +
        'portrait=true&' +
        'fitw=true&' +
        'sheetnames=false&' +
        'printtitle=false&' +
        'pagenumbers=true&' +
        'gridlines=false&' +
        'fzr=false&' +
        'gid=' + reportsSheet.getSheetId();
    
    var params = {method: 'GET', headers: {'Authorization': 'Bearer ' + ScriptApp.getOAuthToken()}};
    
    // Fetch the PDF
    var response = UrlFetchApp.fetch(url + exportOptions, params);
    
    // Return the PDF as a blob
    return response.getBlob().setName('SupermarketReport_' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd') + '.pdf');
  } catch (error) {
    Logger.log('Error creating PDF: ' + error.toString());
    return null;
  }
}

/**
 * Sets up a daily trigger to send the report automatically
 */
function setupTrigger() {
  // Delete any existing triggers
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendDailyReport') {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }
  
  // Get the time from the Reports sheet
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var reportsSheet = ss.getSheetByName('Reports');
  var timeString = reportsSheet.getRange('B6').getValue();
  
  // Default to 18:00 if not specified
  if (!timeString) {
    timeString = '18:00';
  }
  
  // Parse the time
  var timeParts = timeString.split(':');
  var hours = parseInt(timeParts[0]);
  var minutes = parseInt(timeParts[1] || '0');
  
  // Create a new trigger to run at the specified time
  ScriptApp.newTrigger('sendDailyReport')
    .timeBased()
    .atHour(hours)
    .nearMinute(minutes)
    .everyDays(1)
    .create();
  
  // Show confirmation
  SpreadsheetApp.getUi().alert(
    'تم جدولة التقرير ليتم إرساله تلقائيًا كل يوم في الساعة ' + timeString + '\n' +
    'Report has been scheduled to be sent automatically every day at ' + timeString
  );
}

/**
 * Updates the report preview data
 */
function updateReportPreview() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var reportsSheet = ss.getSheetByName('Reports');
  var dailyEntrySheet = ss.getSheetByName('Daily Entry');
  
  if (!reportsSheet || !dailyEntrySheet) {
    return;
  }
  
  // Update the daily sales summary preview
  var lastRow = dailyEntrySheet.getLastRow();
  var data = dailyEntrySheet.getRange(2, 1, Math.min(5, lastRow-1), 7).getValues();
  
  // Copy data to the Reports sheet preview section
  for (var i = 0; i < data.length; i++) {
    var row = 18 + i;
    reportsSheet.getRange(row, 1).setValue(data[i][0]); // Date
    reportsSheet.getRange(row, 2).setValue(data[i][2]); // Cash Sales
    reportsSheet.getRange(row, 3).setValue(data[i][3]); // Visa Sales
    reportsSheet.getRange(row, 4).setValue(data[i][4]); // Total Revenue
    reportsSheet.getRange(row, 5).setValue(data[i][5]); // Expenses
    reportsSheet.getRange(row, 6).setValue(data[i][6]); // Daily Profit
  }
  
  // Update totals
  reportsSheet.getRange('B22').setFormula('=SUM(B18:B21)');
  reportsSheet.getRange('C22').setFormula('=SUM(C18:C21)');
  reportsSheet.getRange('D22').setFormula('=SUM(D18:D21)');
  reportsSheet.getRange('E22').setFormula('=SUM(E18:E21)');
  reportsSheet.getRange('F22').setFormula('=SUM(F18:F21)');
}
