import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import Rule
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference, LineChart
from openpyxl.worksheet.datavalidation import DataValidation
import datetime

# Define improvement areas based on analysis
improvement_areas = {
    "Structure": [
        "Add a Dashboard/Summary sheet",
        "Add an Inventory sheet",
        "Add a Monthly Summary sheet",
        "Add a Yearly Summary sheet",
        "Add an Expenses Categories sheet"
    ],
    "Formulas": [
        "Add automatic calculation of Total Revenue (Cash + Visa)",
        "Add automatic calculation of Daily Profit (Revenue - Expenses)",
        "Add monthly and yearly summaries with totals and averages",
        "Add inventory tracking formulas",
        "Add expense tracking by category"
    ],
    "Formatting": [
        "Add consistent formatting across all sheets",
        "Add conditional formatting for profits/losses",
        "Add header styling and freezing",
        "Add currency formatting for monetary values",
        "Add date formatting"
    ],
    "Data Validation": [
        "Add data validation for dates",
        "Add data validation for monetary values",
        "Add dropdown lists for branch selection",
        "Add dropdown lists for expense categories",
        "Add employee name validation"
    ],
    "Visualization": [
        "Add charts for sales trends",
        "Add charts for profit comparison by branch",
        "Add charts for expense breakdown",
        "Add KPI indicators",
        "Add a dashboard with key metrics"
    ],
    "Usability": [
        "Add navigation buttons between sheets",
        "Add input forms for easier data entry",
        "Add print areas and settings",
        "Add cell protection for formula cells",
        "Add user instructions"
    ]
}

# Print the improvement areas
print("# Supermarket System Excel Improvement Areas\n")
for category, items in improvement_areas.items():
    print(f"## {category}")
    for item in items:
        print(f"- {item}")
    print()

# Save the improvement areas to a file
with open('/home/ubuntu/improvement_areas.md', 'w') as f:
    f.write("# Supermarket System Excel Improvement Areas\n\n")
    for category, items in improvement_areas.items():
        f.write(f"## {category}\n")
        for item in items:
            f.write(f"- {item}\n")
        f.write("\n")

print("Improvement areas have been identified and saved to 'improvement_areas.md'")
