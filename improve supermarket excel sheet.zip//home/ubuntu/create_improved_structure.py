import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
import datetime
import os
from openpyxl.chart import BarChart, Reference, LineChart
from openpyxl.drawing.image import Image
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import Rule

# Define paths
input_file = '/home/ubuntu/upload/نظام_محدث_للسوبرماركت.xlsx'
output_file = '/home/ubuntu/improved_supermarket_system.xlsx'

# Load the original workbook to extract data
original_wb = openpyxl.load_workbook(input_file)

# Create a new workbook
wb = openpyxl.Workbook()

# Remove the default sheet
default_sheet = wb.active
wb.remove(default_sheet)

# Define common styles
header_font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
header_fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
header_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

data_font = Font(name='Arial', size=11)
data_alignment = Alignment(horizontal='center', vertical='center')
data_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

# Create Dashboard sheet
dashboard = wb.create_sheet('Dashboard')
dashboard.sheet_properties.tabColor = "1072BA"

# Create Monthly Summary sheet
monthly_summary = wb.create_sheet('Monthly Summary')
monthly_summary.sheet_properties.tabColor = "00B050"

# Create Yearly Summary sheet
yearly_summary = wb.create_sheet('Yearly Summary')
yearly_summary.sheet_properties.tabColor = "9B5DE5"

# Create Inventory sheet
inventory = wb.create_sheet('Inventory')
inventory.sheet_properties.tabColor = "FFA500"

# Create Expenses Categories sheet
expenses = wb.create_sheet('Expenses Categories')
expenses.sheet_properties.tabColor = "FF0000"

# Create Daily Entry sheet (main data entry)
daily_entry = wb.create_sheet('Daily Entry')
daily_entry.sheet_properties.tabColor = "00B0F0"

# Create branch-specific sheets
branches = ['Industrial', 'Fesah', 'Omaq']
branch_sheets = {}

for branch in branches:
    sheet_name = f"{branch}"
    branch_sheets[branch] = wb.create_sheet(sheet_name)
    branch_sheets[branch].sheet_properties.tabColor = "92D050"

# Set up Daily Entry sheet
daily_headers = [
    'التاريخ / Date', 
    'الفرع / Branch', 
    'المبيعات (كاش) / Cash Sales', 
    'المبيعات (فيزا) / Visa Sales', 
    'إجمالي الإيرادات / Total Revenue', 
    'المصروفات / Expenses', 
    'فئة المصروفات / Expense Category',
    'الربح اليومي / Daily Profit', 
    'اسم الموظف / Employee Name',
    'ملاحظات / Notes'
]

for col_idx, header in enumerate(daily_headers, 1):
    cell = daily_entry.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    daily_entry.column_dimensions[get_column_letter(col_idx)].width = 20

# Set up branch-specific sheets with the same headers
for branch, sheet in branch_sheets.items():
    for col_idx, header in enumerate(daily_headers, 1):
        cell = sheet.cell(row=1, column=col_idx)
        cell.value = header
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = header_border
        # Set column width
        sheet.column_dimensions[get_column_letter(col_idx)].width = 20

# Set up Inventory sheet
inventory_headers = [
    'رمز المنتج / Product Code',
    'اسم المنتج / Product Name',
    'الفئة / Category',
    'سعر الشراء / Purchase Price',
    'سعر البيع / Selling Price',
    'الكمية المتوفرة / Available Quantity',
    'الحد الأدنى للمخزون / Min Stock Level',
    'تاريخ آخر تحديث / Last Update Date',
    'الفرع / Branch',
    'ملاحظات / Notes'
]

for col_idx, header in enumerate(inventory_headers, 1):
    cell = inventory.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    inventory.column_dimensions[get_column_letter(col_idx)].width = 20

# Set up Expenses Categories sheet
expense_headers = [
    'رمز الفئة / Category Code',
    'اسم الفئة / Category Name',
    'الوصف / Description',
    'الميزانية الشهرية / Monthly Budget',
    'ملاحظات / Notes'
]

for col_idx, header in enumerate(expense_headers, 1):
    cell = expenses.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    expenses.column_dimensions[get_column_letter(col_idx)].width = 25

# Add some sample expense categories
expense_categories = [
    ('EXP001', 'الإيجار / Rent', 'إيجار المحل / Store rent', 5000, ''),
    ('EXP002', 'الرواتب / Salaries', 'رواتب الموظفين / Employee salaries', 10000, ''),
    ('EXP003', 'المرافق / Utilities', 'كهرباء، ماء، إنترنت / Electricity, water, internet', 2000, ''),
    ('EXP004', 'المخزون / Inventory', 'شراء البضائع / Purchasing goods', 20000, ''),
    ('EXP005', 'التسويق / Marketing', 'إعلانات وترويج / Advertising and promotion', 1500, ''),
    ('EXP006', 'الصيانة / Maintenance', 'صيانة المعدات والمبنى / Equipment and building maintenance', 1000, ''),
    ('EXP007', 'أخرى / Other', 'مصاريف متنوعة / Miscellaneous expenses', 1000, '')
]

for row_idx, category in enumerate(expense_categories, 2):
    for col_idx, value in enumerate(category, 1):
        cell = expenses.cell(row=row_idx, column=col_idx)
        cell.value = value
        cell.font = data_font
        cell.alignment = data_alignment
        cell.border = data_border

# Set up Monthly Summary sheet
monthly_headers = [
    'الشهر / Month',
    'السنة / Year',
    'الفرع / Branch',
    'إجمالي المبيعات (كاش) / Total Cash Sales',
    'إجمالي المبيعات (فيزا) / Total Visa Sales',
    'إجمالي الإيرادات / Total Revenue',
    'إجمالي المصروفات / Total Expenses',
    'صافي الربح / Net Profit',
    'عدد المعاملات / Transaction Count',
    'متوسط قيمة المعاملة / Average Transaction Value'
]

for col_idx, header in enumerate(monthly_headers, 1):
    cell = monthly_summary.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    monthly_summary.column_dimensions[get_column_letter(col_idx)].width = 25

# Set up Yearly Summary sheet
yearly_headers = [
    'السنة / Year',
    'الفرع / Branch',
    'إجمالي المبيعات (كاش) / Total Cash Sales',
    'إجمالي المبيعات (فيزا) / Total Visa Sales',
    'إجمالي الإيرادات / Total Revenue',
    'إجمالي المصروفات / Total Expenses',
    'صافي الربح / Net Profit',
    'نسبة النمو عن العام السابق / Growth Rate from Previous Year',
    'عدد المعاملات / Transaction Count',
    'متوسط قيمة المعاملة / Average Transaction Value'
]

for col_idx, header in enumerate(yearly_headers, 1):
    cell = yearly_summary.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    yearly_summary.column_dimensions[get_column_letter(col_idx)].width = 25

# Set up Dashboard
dashboard_titles = [
    'نظام إدارة السوبرماركت / Supermarket Management System',
    'لوحة المعلومات / Dashboard',
    'آخر تحديث / Last Update: ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
]

# Add title to dashboard
dashboard.merge_cells('A1:J2')
title_cell = dashboard.cell(row=1, column=1)
title_cell.value = dashboard_titles[0]
title_cell.font = Font(name='Arial', size=16, bold=True, color='000000')
title_cell.alignment = Alignment(horizontal='center', vertical='center')

dashboard.merge_cells('A3:J3')
subtitle_cell = dashboard.cell(row=3, column=1)
subtitle_cell.value = dashboard_titles[1]
subtitle_cell.font = Font(name='Arial', size=14, bold=True, color='000000')
subtitle_cell.alignment = Alignment(horizontal='center', vertical='center')

dashboard.merge_cells('A4:J4')
update_cell = dashboard.cell(row=4, column=1)
update_cell.value = dashboard_titles[2]
update_cell.font = Font(name='Arial', size=10, italic=True, color='000000')
update_cell.alignment = Alignment(horizontal='center', vertical='center')

# Dashboard sections
dashboard.merge_cells('A6:E6')
section1_cell = dashboard.cell(row=6, column=1)
section1_cell.value = 'ملخص المبيعات / Sales Summary'
section1_cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
section1_cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
section1_cell.alignment = Alignment(horizontal='center', vertical='center')

dashboard.merge_cells('F6:J6')
section2_cell = dashboard.cell(row=6, column=6)
section2_cell.value = 'ملخص الأرباح / Profit Summary'
section2_cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
section2_cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
section2_cell.alignment = Alignment(horizontal='center', vertical='center')

dashboard.merge_cells('A15:E15')
section3_cell = dashboard.cell(row=15, column=1)
section3_cell.value = 'مؤشرات الأداء الرئيسية / Key Performance Indicators'
section3_cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
section3_cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
section3_cell.alignment = Alignment(horizontal='center', vertical='center')

dashboard.merge_cells('F15:J15')
section4_cell = dashboard.cell(row=15, column=6)
section4_cell.value = 'تنبيهات المخزون / Inventory Alerts'
section4_cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
section4_cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
section4_cell.alignment = Alignment(horizontal='center', vertical='center')

# Set column widths for dashboard
for col in range(1, 11):
    dashboard.column_dimensions[get_column_letter(col)].width = 15

# Save the workbook
wb.save(output_file)

print(f"Improved Excel structure created and saved to {output_file}")
print("The following improvements have been made to the structure:")
print("1. Added Dashboard sheet with sections for key metrics")
print("2. Added Monthly and Yearly Summary sheets for aggregated data")
print("3. Added Inventory sheet for product tracking")
print("4. Added Expenses Categories sheet with predefined categories")
print("5. Enhanced Daily Entry sheet with additional columns")
print("6. Created separate sheets for each branch with consistent structure")
print("7. Applied consistent header formatting across all sheets")
print("8. Set appropriate column widths for better readability")
