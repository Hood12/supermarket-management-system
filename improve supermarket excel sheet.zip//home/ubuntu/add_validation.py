import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
import datetime
import os

# Define paths
input_file = '/home/ubuntu/improved_supermarket_system_with_visuals.xlsx'
output_file = '/home/ubuntu/improved_supermarket_system_final.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(input_file)

# Function to add data validation
def add_data_validation():
    # Add data validation to Daily Entry sheet
    daily_entry = wb['Daily Entry']
    
    # Date validation
    date_validation = DataValidation(type="date", operator="between", 
                                    formula1="=DATE(2020,1,1)", 
                                    formula2="=DATE(2030,12,31)",
                                    allow_blank=True)
    date_validation.error = "Please enter a valid date between 2020 and 2030"
    date_validation.errorTitle = "Invalid Date"
    date_validation.prompt = "Enter date (YYYY-MM-DD)"
    date_validation.promptTitle = "Date"
    daily_entry.add_data_validation(date_validation)
    
    # Apply date validation to date column
    date_validation.add(f"A2:A1000")
    
    # Branch validation (dropdown list)
    branch_validation = DataValidation(type="list", formula1='"Industrial,Fesah,Omaq"', allow_blank=True)
    branch_validation.error = "Please select a valid branch from the list"
    branch_validation.errorTitle = "Invalid Branch"
    branch_validation.prompt = "Select a branch"
    branch_validation.promptTitle = "Branch"
    daily_entry.add_data_validation(branch_validation)
    
    # Apply branch validation to branch column
    branch_validation.add(f"B2:B1000")
    
    # Numeric validation for monetary values
    numeric_validation = DataValidation(type="decimal", operator="greaterThanOrEqual", 
                                       formula1="0", allow_blank=True)
    numeric_validation.error = "Please enter a positive number"
    numeric_validation.errorTitle = "Invalid Amount"
    numeric_validation.prompt = "Enter a positive number"
    numeric_validation.promptTitle = "Amount"
    daily_entry.add_data_validation(numeric_validation)
    
    # Apply numeric validation to monetary columns
    numeric_validation.add(f"C2:D1000")  # Cash and Visa sales
    numeric_validation.add(f"F2:F1000")  # Expenses
    
    # Expense category validation (dropdown list)
    expense_categories = []
    expenses_sheet = wb['Expenses Categories']
    for row in range(2, expenses_sheet.max_row + 1):
        category = expenses_sheet.cell(row=row, column=2).value
        if category:
            expense_categories.append(category)
    
    expense_validation = DataValidation(type="list", 
                                       formula1=f'"{",".join(expense_categories)}"', 
                                       allow_blank=True)
    expense_validation.error = "Please select a valid expense category from the list"
    expense_validation.errorTitle = "Invalid Category"
    expense_validation.prompt = "Select an expense category"
    expense_validation.promptTitle = "Expense Category"
    daily_entry.add_data_validation(expense_validation)
    
    # Apply expense category validation
    expense_validation.add(f"G2:G1000")
    
    # Apply similar validations to branch sheets
    for branch in ['Industrial', 'Fesah', 'Omaq']:
        branch_sheet = wb[branch]
        
        # Date validation
        branch_sheet.add_data_validation(date_validation)
        date_validation.add(f"A2:A1000")
        
        # Numeric validation
        branch_sheet.add_data_validation(numeric_validation)
        numeric_validation.add(f"C2:D1000")  # Cash and Visa sales
        numeric_validation.add(f"F2:F1000")  # Expenses
        
        # Expense category validation
        branch_sheet.add_data_validation(expense_validation)
        expense_validation.add(f"G2:G1000")
    
    # Add data validation to Inventory sheet
    inventory = wb['Inventory']
    
    # Numeric validation for prices and quantities
    inventory.add_data_validation(numeric_validation)
    numeric_validation.add(f"D2:E1000")  # Purchase and Selling prices
    numeric_validation.add(f"F2:G1000")  # Available Quantity and Min Stock Level
    
    # Branch validation for inventory
    inventory.add_data_validation(branch_validation)
    branch_validation.add(f"I2:I1000")
    
    # Category validation for inventory
    inventory_categories = ["مشروبات / Beverages", "معلبات / Canned Goods", "منتجات الألبان / Dairy", 
                           "منتجات مجمدة / Frozen Foods", "فواكه وخضروات / Produce", "منتجات التنظيف / Cleaning Products"]
    
    category_validation = DataValidation(type="list", 
                                        formula1=f'"{",".join(inventory_categories)}"', 
                                        allow_blank=True)
    inventory.add_data_validation(category_validation)
    category_validation.add(f"C2:C1000")

# Function to add cell protection
def add_cell_protection():
    # Protect formula cells in all sheets
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        
        # Unprotect the sheet first (in case it's already protected)
        sheet.protection.sheet = False
        
        # Set all cells to locked=False by default
        for row in range(1, sheet.max_row + 1):
            for col in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=row, column=col)
                cell.protection = openpyxl.styles.Protection(locked=False)
        
        # Lock header cells (first row)
        for col in range(1, sheet.max_column + 1):
            cell = sheet.cell(row=1, column=col)
            cell.protection = openpyxl.styles.Protection(locked=True)
        
        # Lock formula cells
        for row in range(2, sheet.max_row + 1):
            for col in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=row, column=col)
                if cell.data_type == 'f':  # Formula cell
                    cell.protection = openpyxl.styles.Protection(locked=True)
        
        # Protect the sheet with a password
        sheet.protection.sheet = True
        sheet.protection.password = 'supermarket'  # Simple password for demonstration
        sheet.protection.enable()

# Function to add user instructions
def add_instructions():
    # Create a new sheet for instructions
    if 'Instructions' in wb.sheetnames:
        wb.remove(wb['Instructions'])
    
    instructions = wb.create_sheet('Instructions', 0)  # Add at the beginning
    instructions.sheet_properties.tabColor = "7030A0"  # Purple
    
    # Add title
    instructions.merge_cells('A1:J2')
    title_cell = instructions.cell(row=1, column=1)
    title_cell.value = "تعليمات استخدام نظام إدارة السوبرماركت / Supermarket Management System Instructions"
    title_cell.font = Font(name='Arial', size=16, bold=True, color='FFFFFF')
    title_cell.fill = PatternFill(start_color='7030A0', end_color='7030A0', fill_type='solid')
    title_cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Add section headers and instructions
    sections = [
        ("نظرة عامة / Overview", [
            "يوفر هذا النظام إدارة شاملة لبيانات السوبرماركت بما في ذلك المبيعات والمصروفات والمخزون.",
            "This system provides comprehensive management of supermarket data including sales, expenses, and inventory."
        ]),
        ("الصفحات / Sheets", [
            "Dashboard: لوحة المعلومات الرئيسية مع ملخص للمؤشرات الرئيسية والرسوم البيانية.",
            "Daily Entry: إدخال البيانات اليومية للمبيعات والمصروفات.",
            "Industrial, Fesah, Omaq: صفحات خاصة بكل فرع.",
            "Monthly Summary: ملخص شهري للمبيعات والأرباح.",
            "Yearly Summary: ملخص سنوي للمبيعات والأرباح.",
            "Inventory: إدارة المخزون والمنتجات.",
            "Expenses Categories: فئات المصروفات."
        ]),
        ("إدخال البيانات / Data Entry", [
            "أدخل البيانات في الخلايا البيضاء فقط. الخلايا الملونة محمية وتحتوي على صيغ.",
            "Enter data in white cells only. Colored cells are protected and contain formulas.",
            "استخدم القوائم المنسدلة لاختيار الفروع وفئات المصروفات.",
            "Use dropdown lists to select branches and expense categories."
        ]),
        ("الصيغ والحسابات / Formulas and Calculations", [
            "إجمالي الإيرادات = المبيعات (كاش) + المبيعات (فيزا)",
            "Total Revenue = Cash Sales + Visa Sales",
            "الربح اليومي = إجمالي الإيرادات - المصروفات",
            "Daily Profit = Total Revenue - Expenses",
            "يتم حساب الملخصات الشهرية والسنوية تلقائيًا من بيانات الإدخال اليومي.",
            "Monthly and yearly summaries are calculated automatically from daily entry data."
        ]),
        ("الرسوم البيانية / Charts", [
            "تعرض الرسوم البيانية اتجاهات المبيعات والأرباح ومقارنات الفروع.",
            "Charts display sales trends, profit trends, and branch comparisons.",
            "يتم تحديث الرسوم البيانية تلقائيًا عند تغيير البيانات.",
            "Charts update automatically when data changes."
        ]),
        ("تنبيهات المخزون / Inventory Alerts", [
            "يتم تمييز المنتجات التي تقل عن الحد الأدنى للمخزون باللون الأحمر.",
            "Products below minimum stock level are highlighted in red.",
            "راجع قسم تنبيهات المخزون في صفحة المخزون وفي لوحة المعلومات.",
            "Check the inventory alerts section in the Inventory sheet and Dashboard."
        ]),
        ("حماية البيانات / Data Protection", [
            "الصفحات محمية بكلمة مرور لمنع التغييرات العرضية في الصيغ.",
            "Sheets are password-protected to prevent accidental changes to formulas.",
            "كلمة المرور الافتراضية هي: supermarket",
            "The default password is: supermarket"
        ]),
        ("الدعم / Support", [
            "للحصول على المساعدة أو الإبلاغ عن المشكلات، يرجى الاتصال بفريق الدعم.",
            "For help or to report issues, please contact the support team."
        ])
    ]
    
    row = 4
    for section, instructions_list in sections:
        # Add section header
        instructions.merge_cells(f'A{row}:J{row}')
        header_cell = instructions.cell(row=row, column=1)
        header_cell.value = section
        header_cell.font = Font(name='Arial', size=14, bold=True, color='FFFFFF')
        header_cell.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
        header_cell.alignment = Alignment(horizontal='center', vertical='center')
        row += 1
        
        # Add instructions
        for instruction in instructions_list:
            instructions.merge_cells(f'B{row}:J{row}')
            instruction_cell = instructions.cell(row=row, column=2)
            instruction_cell.value = instruction
            instruction_cell.font = Font(name='Arial', size=11)
            instruction_cell.alignment = Alignment(horizontal='right' if instruction.startswith('ا') else 'left', vertical='center')
            row += 1
        
        row += 1  # Add space between sections
    
    # Set column widths
    for col in range(1, 11):
        instructions.column_dimensions[get_column_letter(col)].width = 15

# Add data validation
print("Adding data validation...")
add_data_validation()

# Add cell protection
print("Adding cell protection...")
add_cell_protection()

# Add user instructions
print("Adding user instructions...")
add_instructions()

# Save the workbook
wb.save(output_file)

print(f"Validation, protection, and instructions added and saved to {output_file}")
print("The following improvements have been made:")
print("1. Added data validation for dates, ensuring they are within a valid range")
print("2. Added dropdown lists for branches and expense categories")
print("3. Added numeric validation for monetary values, ensuring they are positive")
print("4. Protected formula cells to prevent accidental changes")
print("5. Added comprehensive user instructions in a dedicated sheet")
print("6. Set sheet protection with password 'supermarket'")
print("7. Added data validation for inventory categories and branches")
