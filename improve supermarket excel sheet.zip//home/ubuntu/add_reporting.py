import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
import datetime

# Define paths
input_file = '/home/ubuntu/fixed_supermarket_system.xlsx'
output_file = '/home/ubuntu/supermarket_system_with_reporting.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(input_file)

# Create a Reports sheet
reports = wb.create_sheet('Reports')
reports.sheet_properties.tabColor = "FF0000"  # Red

# Define common styles
header_font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
header_fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
header_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

subheader_font = Font(name='Arial', size=11, bold=True)
subheader_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
subheader_alignment = Alignment(horizontal='center', vertical='center')
subheader_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

data_font = Font(name='Arial', size=11)
data_alignment = Alignment(horizontal='center', vertical='center')
data_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

# Set up Reports sheet
reports.merge_cells('A1:G1')
title_cell = reports.cell(row=1, column=1)
title_cell.value = "تقارير نظام إدارة السوبرماركت / Supermarket Management System Reports"
title_cell.font = Font(name='Arial', size=16, bold=True, color='FFFFFF')
title_cell.fill = PatternFill(start_color='7030A0', end_color='7030A0', fill_type='solid')
title_cell.alignment = Alignment(horizontal='center', vertical='center')

# Add email settings section
reports.merge_cells('A3:G3')
email_title = reports.cell(row=3, column=1)
email_title.value = "إعدادات البريد الإلكتروني / Email Settings"
email_title.font = Font(name='Arial', size=14, bold=True, color='FFFFFF')
email_title.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
email_title.alignment = Alignment(horizontal='center', vertical='center')

# Email settings fields
email_fields = [
    ("عنوان البريد الإلكتروني للمستلم / Recipient Email", "muneer1122337@gmail.com"),
    ("موضوع البريد الإلكتروني / Email Subject", "تقرير السوبرماركت اليومي / Daily Supermarket Report"),
    ("وقت الإرسال / Send Time", "18:00"),
    ("تكرار الإرسال / Send Frequency", "يومي / Daily")
]

for i, (label, value) in enumerate(email_fields):
    row = i + 4
    
    # Label
    reports.cell(row=row, column=1).value = label
    reports.cell(row=row, column=1).font = subheader_font
    reports.cell(row=row, column=1).alignment = Alignment(horizontal='right', vertical='center')
    reports.cell(row=row, column=1).border = subheader_border
    
    # Value
    reports.cell(row=row, column=2).value = value
    reports.cell(row=row, column=2).font = data_font
    reports.cell(row=row, column=2).alignment = data_alignment
    reports.cell(row=row, column=2).border = data_border

# Add report content section
reports.merge_cells('A9:G9')
report_title = reports.cell(row=9, column=1)
report_title.value = "محتوى التقرير / Report Content"
report_title.font = Font(name='Arial', size=14, bold=True, color='FFFFFF')
report_title.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
report_title.alignment = Alignment(horizontal='center', vertical='center')

# Report content options
report_options = [
    ("ملخص المبيعات اليومية / Daily Sales Summary", True),
    ("ملخص الأرباح / Profit Summary", True),
    ("مقارنة الفروع / Branch Comparison", True),
    ("تنبيهات المخزون / Inventory Alerts", True)
]

for i, (option, selected) in enumerate(report_options):
    row = i + 10
    
    # Option
    reports.cell(row=row, column=1).value = option
    reports.cell(row=row, column=1).font = subheader_font
    reports.cell(row=row, column=1).alignment = Alignment(horizontal='right', vertical='center')
    reports.cell(row=row, column=1).border = subheader_border
    
    # Selected
    reports.cell(row=row, column=2).value = "✓" if selected else "✗"
    reports.cell(row=row, column=2).font = data_font
    reports.cell(row=row, column=2).alignment = data_alignment
    reports.cell(row=row, column=2).border = data_border

# Add report preview section
reports.merge_cells('A15:G15')
preview_title = reports.cell(row=15, column=1)
preview_title.value = "معاينة التقرير / Report Preview"
preview_title.font = Font(name='Arial', size=14, bold=True, color='FFFFFF')
preview_title.fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
preview_title.alignment = Alignment(horizontal='center', vertical='center')

# Add daily sales summary preview
reports.merge_cells('A16:G16')
summary_title = reports.cell(row=16, column=1)
summary_title.value = "ملخص المبيعات اليومية / Daily Sales Summary"
summary_title.font = Font(name='Arial', size=12, bold=True)
summary_title.fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
summary_title.alignment = Alignment(horizontal='center', vertical='center')

# Add summary headers
summary_headers = [
    "التاريخ / Date",
    "المبيعات (كاش) / Cash Sales",
    "المبيعات (فيزا) / Visa Sales",
    "إجمالي الإيرادات / Total Revenue",
    "المصروفات / Expenses",
    "الربح اليومي / Daily Profit"
]

for col, header in enumerate(summary_headers, 1):
    cell = reports.cell(row=17, column=col)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    reports.column_dimensions[get_column_letter(col)].width = 20

# Add sample data from Daily Entry sheet
daily_entry = wb['Daily Entry']
for row in range(2, 7):  # Copy first 5 data rows
    for col in range(1, 8):  # Copy relevant columns
        if col != 2 and col != 8:  # Skip Branch and Employee columns
            source_cell = daily_entry.cell(row=row, column=col)
            target_col = col if col == 1 else col - 1  # Adjust column index
            target_cell = reports.cell(row=row + 16, column=target_col)
            
            # Copy value
            target_cell.value = source_cell.value
            
            # Copy formatting
            target_cell.font = data_font
            target_cell.alignment = data_alignment
            target_cell.border = data_border
            
            # Apply number formatting for monetary values
            if col in [3, 4, 5, 6, 7]:  # Cash, Visa, Revenue, Expenses, Profit
                target_cell.number_format = '#,##0.00 [$﷼]'
            elif col == 1:  # Date
                target_cell.number_format = 'yyyy-mm-dd'

# Add totals row
total_row = 22
reports.cell(row=total_row, column=1).value = "المجموع / Total"
reports.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
reports.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')

# Add sum formulas for numeric columns
for col in range(2, 7):
    reports.cell(row=total_row, column=col).value = f"=SUM({get_column_letter(col)}18:{get_column_letter(col)}21)"
    reports.cell(row=total_row, column=col).font = Font(name='Arial', size=12, bold=True)
    reports.cell(row=total_row, column=col).border = Border(
        left=Side(style='thin', color='000000'),
        right=Side(style='thin', color='000000'),
        top=Side(style='thin', color='000000'),
        bottom=Side(style='double', color='000000')
    )
    reports.cell(row=total_row, column=col).number_format = '#,##0.00 [$﷼]'

# Add branch comparison preview
reports.merge_cells('A24:G24')
branch_title = reports.cell(row=24, column=1)
branch_title.value = "مقارنة الفروع / Branch Comparison"
branch_title.font = Font(name='Arial', size=12, bold=True)
branch_title.fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
branch_title.alignment = Alignment(horizontal='center', vertical='center')

# Add branch comparison headers
branch_headers = [
    "الفرع / Branch",
    "إجمالي المبيعات / Total Sales",
    "إجمالي المصروفات / Total Expenses",
    "صافي الربح / Net Profit",
    "نسبة الربح / Profit Margin"
]

for col, header in enumerate(branch_headers, 1):
    cell = reports.cell(row=25, column=col)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    reports.column_dimensions[get_column_letter(col)].width = 20

# Add branch data
branches = ['Industrial', 'Fesah', 'Omaq']
for i, branch in enumerate(branches):
    row = 26 + i
    
    # Branch name
    reports.cell(row=row, column=1).value = branch
    reports.cell(row=row, column=1).font = data_font
    reports.cell(row=row, column=1).alignment = data_alignment
    reports.cell(row=row, column=1).border = data_border
    
    # Sample data for each branch
    sales = 12000 + i * 1000
    expenses = 7000 + i * 500
    profit = sales - expenses
    margin = profit / sales
    
    # Total Sales
    reports.cell(row=row, column=2).value = sales
    reports.cell(row=row, column=2).font = data_font
    reports.cell(row=row, column=2).alignment = data_alignment
    reports.cell(row=row, column=2).border = data_border
    reports.cell(row=row, column=2).number_format = '#,##0.00 [$﷼]'
    
    # Total Expenses
    reports.cell(row=row, column=3).value = expenses
    reports.cell(row=row, column=3).font = data_font
    reports.cell(row=row, column=3).alignment = data_alignment
    reports.cell(row=row, column=3).border = data_border
    reports.cell(row=row, column=3).number_format = '#,##0.00 [$﷼]'
    
    # Net Profit
    reports.cell(row=row, column=4).value = profit
    reports.cell(row=row, column=4).font = data_font
    reports.cell(row=row, column=4).alignment = data_alignment
    reports.cell(row=row, column=4).border = data_border
    reports.cell(row=row, column=4).number_format = '#,##0.00 [$﷼]'
    
    # Profit Margin
    reports.cell(row=row, column=5).value = margin
    reports.cell(row=row, column=5).font = data_font
    reports.cell(row=row, column=5).alignment = data_alignment
    reports.cell(row=row, column=5).border = data_border
    reports.cell(row=row, column=5).number_format = '0.00%'

# Add send report button
reports.merge_cells('A32:G32')
button_cell = reports.cell(row=32, column=1)
button_cell.value = "إرسال التقرير الآن / Send Report Now"
button_cell.font = Font(name='Arial', size=14, bold=True, color='FFFFFF')
button_cell.fill = PatternFill(start_color='00B050', end_color='00B050', fill_type='solid')
button_cell.alignment = Alignment(horizontal='center', vertical='center')

# Add VBA macro for sending email (note: this is a placeholder, actual VBA would need to be added separately)
reports.merge_cells('A34:G34')
macro_note = reports.cell(row=34, column=1)
macro_note.value = "ملاحظة: انقر على الزر أعلاه لإرسال التقرير إلى muneer1122337@gmail.com / Note: Click the button above to send the report to muneer1122337@gmail.com"
macro_note.font = Font(name='Arial', size=11, italic=True)
macro_note.alignment = Alignment(horizontal='center', vertical='center')

# Add automated scheduling note
reports.merge_cells('A36:G36')
schedule_note = reports.cell(row=36, column=1)
schedule_note.value = "ملاحظة: سيتم إرسال التقرير تلقائيًا كل يوم في الساعة 18:00 / Note: The report will be sent automatically every day at 18:00"
schedule_note.font = Font(name='Arial', size=11, italic=True)
schedule_note.alignment = Alignment(horizontal='center', vertical='center')

# Set column widths
for col in range(1, 8):
    reports.column_dimensions[get_column_letter(col)].width = 20

# Save the workbook
wb.save(output_file)

print(f"Supermarket system with reporting functionality created and saved to {output_file}")
print("The file includes:")
print("1. All previous functionality from the fixed supermarket system")
print("2. New Reports sheet with email configuration")
print("3. Report content selection options")
print("4. Report preview showing daily sales summary")
print("5. Branch comparison section")
print("6. Send report button (note: actual email functionality would require VBA macros)")
print("7. Scheduled reporting information")
