import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
import datetime
from openpyxl.chart import BarChart, Reference, LineChart, PieChart

# Define paths
input_file = '/home/ubuntu/improved_supermarket_system_formatted.xlsx'
output_file = '/home/ubuntu/improved_supermarket_system_with_formulas.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(input_file)

# Function to add formulas to Daily Entry and branch sheets
def add_daily_entry_formulas(sheet):
    # Get the last row with data
    max_row = sheet.max_row
    
    # Add formulas for each row
    for row in range(2, max_row + 1):
        # Total Revenue = Cash Sales + Visa Sales
        sheet.cell(row=row, column=5).value = f"=C{row}+D{row}"
        
        # Daily Profit = Total Revenue - Expenses
        sheet.cell(row=row, column=8).value = f"=E{row}-F{row}"
    
    # Add a totals row
    total_row = max_row + 2
    sheet.cell(row=total_row, column=1).value = "المجموع / Total"
    sheet.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add sum formulas for numeric columns
    sheet.cell(row=total_row, column=3).value = f"=SUM(C2:C{max_row})"  # Cash Sales
    sheet.cell(row=total_row, column=4).value = f"=SUM(D2:D{max_row})"  # Visa Sales
    sheet.cell(row=total_row, column=5).value = f"=SUM(E2:E{max_row})"  # Total Revenue
    sheet.cell(row=total_row, column=6).value = f"=SUM(F2:F{max_row})"  # Expenses
    sheet.cell(row=total_row, column=8).value = f"=SUM(H2:H{max_row})"  # Daily Profit
    
    # Format the totals row
    for col in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=total_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='double', color='000000')
        )
    
    # Add average row
    avg_row = total_row + 1
    sheet.cell(row=avg_row, column=1).value = "المتوسط / Average"
    sheet.cell(row=avg_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=avg_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add average formulas for numeric columns
    sheet.cell(row=avg_row, column=3).value = f"=AVERAGE(C2:C{max_row})"  # Cash Sales
    sheet.cell(row=avg_row, column=4).value = f"=AVERAGE(D2:D{max_row})"  # Visa Sales
    sheet.cell(row=avg_row, column=5).value = f"=AVERAGE(E2:E{max_row})"  # Total Revenue
    sheet.cell(row=avg_row, column=6).value = f"=AVERAGE(F2:F{max_row})"  # Expenses
    sheet.cell(row=avg_row, column=8).value = f"=AVERAGE(H2:H{max_row})"  # Daily Profit
    
    # Format the average row
    for col in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=avg_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True, italic=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='thin', color='000000')
        )
    
    # Apply number formatting to the totals and averages
    for row in [total_row, avg_row]:
        for col in [3, 4, 5, 6, 8]:  # Monetary columns
            cell = sheet.cell(row=row, column=col)
            cell.number_format = '#,##0.00 [$﷼]'

# Function to add formulas to Monthly Summary sheet
def add_monthly_summary_formulas(sheet):
    # Get the last row with data
    max_row = sheet.max_row
    
    # Add formulas for each row
    for row in range(2, max_row + 1):
        # Total Revenue = Total Cash Sales + Total Visa Sales
        sheet.cell(row=row, column=6).value = f"=D{row}+E{row}"
        
        # Net Profit = Total Revenue - Total Expenses
        sheet.cell(row=row, column=8).value = f"=F{row}-G{row}"
        
        # Average Transaction Value = Total Revenue / Transaction Count
        sheet.cell(row=row, column=10).value = f"=F{row}/I{row}"
    
    # Add a totals section at the bottom
    total_row = max_row + 2
    sheet.cell(row=total_row, column=1).value = "المجموع الكلي / Grand Total"
    sheet.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add sum formulas for numeric columns
    sheet.cell(row=total_row, column=4).value = f"=SUM(D2:D{max_row})"  # Total Cash Sales
    sheet.cell(row=total_row, column=5).value = f"=SUM(E2:E{max_row})"  # Total Visa Sales
    sheet.cell(row=total_row, column=6).value = f"=SUM(F2:F{max_row})"  # Total Revenue
    sheet.cell(row=total_row, column=7).value = f"=SUM(G2:G{max_row})"  # Total Expenses
    sheet.cell(row=total_row, column=8).value = f"=SUM(H2:H{max_row})"  # Net Profit
    sheet.cell(row=total_row, column=9).value = f"=SUM(I2:I{max_row})"  # Transaction Count
    
    # Format the totals row
    for col in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=total_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='double', color='000000')
        )
    
    # Apply number formatting to the totals
    for col in [4, 5, 6, 7, 8, 10]:  # Monetary columns
        cell = sheet.cell(row=total_row, column=col)
        cell.number_format = '#,##0.00 [$﷼]'
    
    # Add branch comparison section
    branch_row = total_row + 3
    sheet.cell(row=branch_row, column=1).value = "مقارنة الفروع / Branch Comparison"
    sheet.cell(row=branch_row, column=1).font = Font(name='Arial', size=14, bold=True)
    sheet.cell(row=branch_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    sheet.merge_cells(start_row=branch_row, start_column=1, end_row=branch_row, end_column=10)
    
    # Add branch headers
    branch_header_row = branch_row + 1
    sheet.cell(row=branch_header_row, column=1).value = "الفرع / Branch"
    sheet.cell(row=branch_header_row, column=2).value = "إجمالي المبيعات / Total Sales"
    sheet.cell(row=branch_header_row, column=3).value = "إجمالي المصروفات / Total Expenses"
    sheet.cell(row=branch_header_row, column=4).value = "صافي الربح / Net Profit"
    sheet.cell(row=branch_header_row, column=5).value = "نسبة الربح / Profit Margin"
    
    # Format branch headers
    for col in range(1, 6):
        cell = sheet.cell(row=branch_header_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
        cell.fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='thin', color='000000')
        )
        sheet.column_dimensions[get_column_letter(col)].width = 20
    
    # Add branch data with SUMIF formulas
    branches = ['Industrial', 'Fesah', 'Omaq']
    for i, branch in enumerate(branches):
        row = branch_header_row + i + 1
        
        # Branch name
        sheet.cell(row=row, column=1).value = branch
        
        # Total Sales (SUMIF for branch)
        sheet.cell(row=row, column=2).value = f'=SUMIF(C2:C{max_row},"{branch}",F2:F{max_row})'
        
        # Total Expenses (SUMIF for branch)
        sheet.cell(row=row, column=3).value = f'=SUMIF(C2:C{max_row},"{branch}",G2:G{max_row})'
        
        # Net Profit
        sheet.cell(row=row, column=4).value = f"=B{row}-C{row}"
        
        # Profit Margin
        sheet.cell(row=row, column=5).value = f"=D{row}/B{row}"
        sheet.cell(row=row, column=5).number_format = '0.00%'
        
        # Format cells
        for col in range(1, 6):
            cell = sheet.cell(row=row, column=col)
            cell.font = Font(name='Arial', size=11)
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = Border(
                left=Side(style='thin', color='000000'),
                right=Side(style='thin', color='000000'),
                top=Side(style='thin', color='000000'),
                bottom=Side(style='thin', color='000000')
            )
        
        # Apply number formatting
        for col in [2, 3, 4]:  # Monetary columns
            cell = sheet.cell(row=row, column=col)
            cell.number_format = '#,##0.00 [$﷼]'

# Function to add formulas to Yearly Summary sheet
def add_yearly_summary_formulas(sheet):
    # Get the last row with data
    max_row = sheet.max_row
    
    # Add formulas for each row
    for row in range(2, max_row + 1):
        # Total Revenue = Total Cash Sales + Total Visa Sales
        sheet.cell(row=row, column=5).value = f"=C{row}+D{row}"
        
        # Net Profit = Total Revenue - Total Expenses
        sheet.cell(row=row, column=7).value = f"=E{row}-F{row}"
        
        # Growth Rate (only for rows after the first year for each branch)
        if row > 4:  # After first year entries
            # Check if same branch as 3 rows above (assuming 3 branches)
            sheet.cell(row=row, column=8).value = f'=IF(B{row}=B{row-3},(E{row}-E{row-3})/E{row-3},"")'
        
        # Average Transaction Value = Total Revenue / Transaction Count
        sheet.cell(row=row, column=10).value = f"=E{row}/I{row}"
    
    # Add a totals section at the bottom
    total_row = max_row + 2
    sheet.cell(row=total_row, column=1).value = "المجموع الكلي / Grand Total"
    sheet.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add sum formulas for numeric columns
    sheet.cell(row=total_row, column=3).value = f"=SUM(C2:C{max_row})"  # Total Cash Sales
    sheet.cell(row=total_row, column=4).value = f"=SUM(D2:D{max_row})"  # Total Visa Sales
    sheet.cell(row=total_row, column=5).value = f"=SUM(E2:E{max_row})"  # Total Revenue
    sheet.cell(row=total_row, column=6).value = f"=SUM(F2:F{max_row})"  # Total Expenses
    sheet.cell(row=total_row, column=7).value = f"=SUM(G2:G{max_row})"  # Net Profit
    sheet.cell(row=total_row, column=9).value = f"=SUM(I2:I{max_row})"  # Transaction Count
    
    # Format the totals row
    for col in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=total_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='double', color='000000')
        )
    
    # Apply number formatting to the totals
    for col in [3, 4, 5, 6, 7, 10]:  # Monetary columns
        cell = sheet.cell(row=total_row, column=col)
        cell.number_format = '#,##0.00 [$﷼]'

# Function to add formulas to Inventory sheet
def add_inventory_formulas(sheet):
    # Get the last row with data
    max_row = sheet.max_row
    
    # Add a totals section at the bottom
    total_row = max_row + 2
    sheet.cell(row=total_row, column=1).value = "المجموع / Total"
    sheet.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add sum formulas for numeric columns
    sheet.cell(row=total_row, column=6).value = f"=SUM(F2:F{max_row})"  # Total Available Quantity
    
    # Add total inventory value (Purchase Price * Available Quantity)
    sheet.cell(row=total_row - 1, column=8).value = "إجمالي قيمة المخزون (سعر الشراء) / Total Inventory Value (Purchase Price)"
    sheet.cell(row=total_row - 1, column=8).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row - 1, column=8).alignment = Alignment(horizontal='right', vertical='center')
    
    sheet.cell(row=total_row - 1, column=10).value = f"=SUMPRODUCT(D2:D{max_row},F2:F{max_row})"
    sheet.cell(row=total_row - 1, column=10).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row - 1, column=10).number_format = '#,##0.00 [$﷼]'
    
    # Add total inventory value (Selling Price * Available Quantity)
    sheet.cell(row=total_row, column=8).value = "إجمالي قيمة المخزون (سعر البيع) / Total Inventory Value (Selling Price)"
    sheet.cell(row=total_row, column=8).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row, column=8).alignment = Alignment(horizontal='right', vertical='center')
    
    sheet.cell(row=total_row, column=10).value = f"=SUMPRODUCT(E2:E{max_row},F2:F{max_row})"
    sheet.cell(row=total_row, column=10).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row, column=10).number_format = '#,##0.00 [$﷼]'
    
    # Add potential profit
    sheet.cell(row=total_row + 1, column=8).value = "الربح المحتمل / Potential Profit"
    sheet.cell(row=total_row + 1, column=8).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row + 1, column=8).alignment = Alignment(horizontal='right', vertical='center')
    
    sheet.cell(row=total_row + 1, column=10).value = f"=J{total_row}-J{total_row-1}"
    sheet.cell(row=total_row + 1, column=10).font = Font(name='Arial', size=11, bold=True)
    sheet.cell(row=total_row + 1, column=10).number_format = '#,##0.00 [$﷼]'
    
    # Add inventory alerts section
    alert_row = total_row + 3
    sheet.cell(row=alert_row, column=1).value = "تنبيهات المخزون / Inventory Alerts"
    sheet.cell(row=alert_row, column=1).font = Font(name='Arial', size=14, bold=True)
    sheet.cell(row=alert_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    sheet.merge_cells(start_row=alert_row, start_column=1, end_row=alert_row, end_column=10)
    
    # Add alert headers
    alert_header_row = alert_row + 1
    headers = [
        "رمز المنتج / Product Code",
        "اسم المنتج / Product Name",
        "الفئة / Category",
        "الكمية المتوفرة / Available Quantity",
        "الحد الأدنى للمخزون / Min Stock Level",
        "الفرع / Branch"
    ]
    
    for col, header in enumerate(headers, 1):
        cell = sheet.cell(row=alert_header_row, column=col)
        cell.value = header
        cell.font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
        cell.fill = PatternFill(start_color='FF0000', end_color='FF0000', fill_type='solid')
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='thin', color='000000')
        )
    
    # Add FILTER formula for items below minimum stock level
    # Note: FILTER function is only available in Excel 365, so we'll use a workaround with array formulas
    # For demonstration, we'll add a few sample alerts
    for i in range(3):
        row = alert_header_row + i + 1
        # Sample alert data
        sheet.cell(row=row, column=1).value = f"P{1000 + i}"
        sheet.cell(row=row, column=2).value = ["ماء معدني / Mineral Water", "حليب / Milk", "أرز / Rice"][i]
        sheet.c<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>