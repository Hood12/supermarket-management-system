// Disable ESLint for this file
/* eslint-disable */
import { createLocalizedPathnamesNavigation } from 'next-intl';

export const locales = ['en', 'ar'];
export const defaultLocale = 'en';

export const { Link, redirect, usePathname, useRouter } = createLocalizedPathnamesNavigation({
  locales,
  pathnames: {
    '/': '/',
    '/dashboard': {
      en: '/dashboard',
      ar: '/لوحة-التحكم',
    },
    '/sales': {
      en: '/sales',
      ar: '/المبيعات',
    },
    '/inventory': {
      en: '/inventory',
      ar: '/المخزون',
    },
    '/reports': {
      en: '/reports',
      ar: '/التقارير',
    },
  },
});
