import { useTranslations } from 'next-intl';
import { Link } from '@/lib/navigation';
import { FiHome, FiShoppingCart, FiPackage, FiBarChart2, FiSettings, FiGlobe } from 'react-icons/fi';

export default function Sidebar({ locale }: { locale: string }) {
  const t = useTranslations('common');
  const otherLocale = locale === 'en' ? 'ar' : 'en';
  
  const menuItems = [
    { href: '/dashboard', label: t('dashboard'), icon: FiHome },
    { href: '/sales', label: t('sales'), icon: FiShoppingCart },
    { href: '/inventory', label: t('inventory'), icon: FiPackage },
    { href: '/reports', label: t('reports'), icon: FiBarChart2 },
    { href: '/settings', label: t('settings'), icon: FiSettings },
  ];

  return (
    <aside className="bg-white shadow-md h-screen w-64 fixed top-0 left-0 overflow-y-auto">
      <div className="p-4 border-b">
        <h1 className="text-xl font-bold text-blue-600">{t('appName')}</h1>
      </div>
      
      <nav className="mt-6">
        <ul>
          {menuItems.map((item) => (
            <li key={item.href} className="mb-2">
              <Link 
                href={item.href}
                className="flex items-center px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors"
              >
                <item.icon className="mr-3" />
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="absolute bottom-0 w-full p-4 border-t">
        <Link 
          href={menuItems[0].href} 
          locale={otherLocale}
          className="flex items-center px-4 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors"
        >
          <FiGlobe className="mr-3" />
          <span>{otherLocale === 'ar' ? 'العربية' : 'English'}</span>
        </Link>
      </div>
    </aside>
  );
}
