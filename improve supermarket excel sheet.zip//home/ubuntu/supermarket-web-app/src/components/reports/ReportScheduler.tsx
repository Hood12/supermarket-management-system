"use client";

import { useEffect } from 'react';
import { useTranslations } from 'next-intl';

export default function ReportScheduler() {
  const t = useTranslations('reports');
  
  // This component sets up a client-side scheduler that checks
  // if reports need to be sent based on the configured schedule
  useEffect(() => {
    // Function to check if reports need to be sent
    const checkSchedule = async () => {
      try {
        // Call the scheduled endpoint to check if it's time to send a report
        const response = await fetch('/api/reports/scheduled');
        const data = await response.json();
        
        if (data.success && data.message === 'Scheduled report sent successfully') {
          console.log('Scheduled report sent successfully');
        }
      } catch (error) {
        console.error('Error checking report schedule:', error);
      }
    };
    
    // Check immediately when component mounts
    checkSchedule();
    
    // Set up interval to check every hour
    // In a production app, you would use a more sophisticated approach
    const interval = setInterval(checkSchedule, 60 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);
  
  // This is a hidden component that just runs the scheduler
  return null;
}
