import { NextRequest, NextResponse } from 'next/server';
import { getRequestConfig } from 'next-intl/server';
import { locales } from './lib/config';

export default function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  
  // Check if the pathname is missing a locale
  const pathnameIsMissingLocale = locales.every(
    locale => !pathname.startsWith(`/${locale}/`) && pathname !== `/${locale}`
  );
  
  // Redirect if there is no locale
  if (pathnameIsMissingLocale) {
    // Get the preferred locale from the Accept-Language header
    const acceptLanguage = request.headers.get('accept-language') || '';
    const preferredLocale = acceptLanguage.includes('ar') ? 'ar' : 'en';
    
    // Redirect to the same pathname but with the preferred locale
    return NextResponse.redirect(
      new URL(`/${preferredLocale}${pathname.startsWith('/') ? pathname : `/${pathname}`}`, request.url)
    );
  }
}

export const config = {
  // Skip all paths that should not be internationalized
  matcher: ['/((?!api|_next|.*\\..*).*)']
};

export async function getInternationalizationConfig() {
  return getRequestConfig(async ({ locale }) => {
    return {
      messages: (await import(`./lib/config`)).dictionary[locale]
    };
  });
}
