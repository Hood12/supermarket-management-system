import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';

export async function GET(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    const branches = await dbService.getBranches();
    
    return NextResponse.json({ branches });
  } catch (error) {
    console.error('Error fetching branches:', error);
    return NextResponse.json(
      { error: 'Failed to fetch branches' },
      { status: 500 }
    );
  }
}
