import { NextRequest, NextResponse } from 'next/server';
import { getDbService } from '@/lib/db/database';
import nodemailer from 'nodemailer';

export async function POST(
  request: NextRequest,
  { params }: { params: { locale: string } }
) {
  try {
    const db = process.env.DB as any;
    const dbService = getDbService(db);
    
    // Get email configuration
    const emailConfig = await dbService.getEmailReportConfig();
    
    if (!emailConfig) {
      return NextResponse.json(
        { error: 'Email configuration not found' },
        { status: 404 }
      );
    }
    
    // Get data for report
    const dailySales = await dbService.getDailySales();
    const branches = await dbService.getBranches();
    const lowStockItems = await dbService.getLowStockItems();
    
    // Calculate totals
    const totalCashSales = dailySales.reduce((sum, sale) => sum + sale.cash_sales, 0);
    const totalVisaSales = dailySales.reduce((sum, sale) => sum + sale.visa_sales, 0);
    const totalRevenue = dailySales.reduce((sum, sale) => sum + sale.total_revenue, 0);
    const totalExpenses = dailySales.reduce((sum, sale) => sum + sale.expenses, 0);
    const totalProfit = dailySales.reduce((sum, sale) => sum + sale.daily_profit, 0);
    
    // Group sales by branch
    const branchSales = {};
    branches.forEach(branch => {
      const branchData = dailySales.filter(sale => sale.branch_id === branch.id);
      const branchCashSales = branchData.reduce((sum, sale) => sum + sale.cash_sales, 0);
      const branchVisaSales = branchData.reduce((sum, sale) => sum + sale.visa_sales, 0);
      const branchRevenue = branchData.reduce((sum, sale) => sum + sale.total_revenue, 0);
      const branchExpenses = branchData.reduce((sum, sale) => sum + sale.expenses, 0);
      const branchProfit = branchData.reduce((sum, sale) => sum + sale.daily_profit, 0);
      
      branchSales[branch.id] = {
        name: branch.name,
        name_ar: branch.name_ar,
        cash_sales: branchCashSales,
        visa_sales: branchVisaSales,
        revenue: branchRevenue,
        expenses: branchExpenses,
        profit: branchProfit,
        margin: branchRevenue > 0 ? branchProfit / branchRevenue : 0
      };
    });
    
    // Create email content
    let emailContent = `
      <h1>تقرير السوبرماركت اليومي / Daily Supermarket Report</h1>
      <p>التاريخ / Date: ${new Date().toISOString().split('T')[0]}</p>
      <hr>
    `;
    
    // Add sales summary if enabled
    if (emailConfig.include_sales_summary) {
      emailContent += `
        <h2>ملخص المبيعات / Sales Summary</h2>
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
          <tr>
            <th>البند / Item</th>
            <th>القيمة / Value</th>
          </tr>
          <tr>
            <td>إجمالي المبيعات (كاش) / Total Cash Sales</td>
            <td>${totalCashSales.toFixed(2)} ﷼</td>
          </tr>
          <tr>
            <td>إجمالي المبيعات (فيزا) / Total Visa Sales</td>
            <td>${totalVisaSales.toFixed(2)} ﷼</td>
          </tr>
          <tr>
            <td>إجمالي الإيرادات / Total Revenue</td>
            <td>${totalRevenue.toFixed(2)} ﷼</td>
          </tr>
          <tr>
            <td>إجمالي المصروفات / Total Expenses</td>
            <td>${totalExpenses.toFixed(2)} ﷼</td>
          </tr>
          <tr>
            <td>صافي الربح / Net Profit</td>
            <td>${totalProfit.toFixed(2)} ﷼</td>
          </tr>
        </table>
      `;
    }
    
    // Add branch comparison if enabled
    if (emailConfig.include_branch_comparison) {
      emailContent += `
        <h2>مقارنة الفروع / Branch Comparison</h2>
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
          <tr>
            <th>الفرع / Branch</th>
            <th>الإيرادات / Revenue</th>
            <th>المصروفات / Expenses</th>
            <th>الربح / Profit</th>
            <th>نسبة الربح / Margin</th>
          </tr>
      `;
      
      Object.values(branchSales).forEach(branch => {
        emailContent += `
          <tr>
            <td>${branch.name} / ${branch.name_ar}</td>
            <td>${branch.revenue.toFixed(2)} ﷼</td>
            <td>${branch.expenses.toFixed(2)} ﷼</td>
            <td>${branch.profit.toFixed(2)} ﷼</td>
            <td>${(branch.margin * 100).toFixed(2)}%</td>
          </tr>
        `;
      });
      
      emailContent += `</table>`;
    }
    
    // Add inventory alerts if enabled
    if (emailConfig.include_inventory_alerts && lowStockItems.length > 0) {
      emailContent += `
        <h2>تنبيهات المخزون / Inventory Alerts</h2>
        <table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">
          <tr>
            <th>رمز المنتج / Product Code</th>
            <th>اسم المنتج / Product Name</th>
            <th>الكمية المتوفرة / Available Quantity</th>
            <th>الحد الأدنى للمخزون / Min Stock Level</th>
            <th>الفرع / Branch</th>
          </tr>
      `;
      
      lowStockItems.forEach(item => {
        emailContent += `
          <tr>
            <td>${item.product_code}</td>
            <td>${item.product_name} / ${item.product_name_ar}</td>
            <td>${item.quantity}</td>
            <td>${item.min_stock_level}</td>
            <td>${item.branch_name} / ${item.branch_name_ar}</td>
          </tr>
        `;
      });
      
      emailContent += `</table>`;
    }
    
    // Add footer
    emailContent += `
      <hr>
      <p>تم إنشاء هذا التقرير تلقائيًا بواسطة نظام إدارة السوبرماركت</p>
      <p>This report was automatically generated by the Supermarket Management System</p>
    `;
    
    // Configure email service using Cloudflare Workers Email
    // In a real application, you would use environment variables for these values
    const transporter = nodemailer.createTransport({
      host: 'smtp-relay.brevo.com',
      port: 587,
      secure: false,
      auth: {
        user: process.env.EMAIL_USER || 'your-email@example.com',
        pass: process.env.EMAIL_PASSWORD || 'your-password'
      }
    });
    
    // Send the email
    const mailOptions = {
      from: '"Supermarket System" <noreply@supermarket-system.com>',
      to: emailConfig.recipient_email,
      subject: emailConfig.subject,
      html: emailContent
    };
    
    // In a production environment, we would actually send the email
    // For this example, we'll simulate sending and return the content
    
    // Uncomment this in a production environment:
    // await transporter.sendMail(mailOptions);
    
    return NextResponse.json({ 
      success: true, 
      message: `Report would be sent to ${emailConfig.recipient_email}`,
      emailContent
    });
  } catch (error) {
    console.error('Error sending report:', error);
    return NextResponse.json(
      { error: 'Failed to send report' },
      { status: 500 }
    );
  }
}
