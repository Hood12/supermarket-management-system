import { useTranslations } from 'next-intl';
import SalesEntryForm from '@/components/forms/SalesEntryForm';
import { FiPlus, FiList } from 'react-icons/fi';

export default function SalesPage() {
  const t = useTranslations('sales');

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('title')}</h1>
        
        <div className="flex space-x-4">
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <FiPlus className="mr-2" />
            {t('addSales')}
          </button>
          <button className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            <FiList className="mr-2" />
            {t('salesHistory')}
          </button>
        </div>
      </div>
      
      <div className="mb-8">
        <SalesEntryForm />
      </div>
      
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-6">{t('salesHistory')}</h2>
        
        {/* Sample sales history table */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('date')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('branch')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('cashSales')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('visaSales')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('totalRevenue')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('expenses')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('dailyProfit')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('employeeName')}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {/* Sample data rows */}
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2025-03-22</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Industrial</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">5,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">7,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">3,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">9,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Mohammed</td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2025-03-21</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fesah</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">4,500.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">6,500.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">11,000.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2,800.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">8,200.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Ahmed</td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2025-03-20</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Omaq</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">5,200.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">7,200.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12,400.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">3,200.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">9,200.00 ﷼</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Fatima</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
