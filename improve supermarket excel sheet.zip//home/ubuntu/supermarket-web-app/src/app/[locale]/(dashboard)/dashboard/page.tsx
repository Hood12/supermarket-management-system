import { useTranslations } from 'next-intl';
import { FiDollarSign, FiTrendingUp, FiShoppingBag, FiAlertTriangle } from 'react-icons/fi';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function Dashboard() {
  const t = useTranslations('dashboard');
  const commonT = useTranslations('common');

  // Sample data for demonstration
  const salesData = [
    { name: 'Industrial', sales: 12000, profit: 9000 },
    { name: 'Fesah', sales: 11000, profit: 8200 },
    { name: 'Omaq', sales: 12400, profit: 9200 },
  ];

  const lowStockItems = [
    { id: 1, code: 'P1003', name: 'Rice', quantity: 3, minLevel: 5, branch: 'Industrial' },
    { id: 2, code: 'P1004', name: 'Sugar', quantity: 4, minLevel: 5, branch: 'Fesah' },
  ];

  const StatCard = ({ title, value, icon: Icon, color }) => (
    <div className="bg-white rounded-lg shadow p-5">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="text-white" size={20} />
        </div>
      </div>
    </div>
  );

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">{t('title')}</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title={t('todaySales')} 
          value="₹ 35,400" 
          icon={FiDollarSign} 
          color="bg-blue-500" 
        />
        <StatCard 
          title={t('todayProfit')} 
          value="₹ 26,400" 
          icon={FiTrendingUp} 
          color="bg-green-500" 
        />
        <StatCard 
          title={t('lowStockItems')} 
          value={lowStockItems.length.toString()} 
          icon={FiAlertTriangle} 
          color="bg-orange-500" 
        />
        <StatCard 
          title={t('avgTransactionValue')} 
          value="₹ 1,180" 
          icon={FiShoppingBag} 
          color="bg-purple-500" 
        />
      </div>
      
      {/* Branch Comparison Chart */}
      <div className="bg-white rounded-lg shadow p-5 mb-8">
        <h2 className="text-lg font-semibold mb-4">{t('branchComparison')}</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={salesData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" name={t('monthlySales')} fill="#3b82f6" />
              <Bar dataKey="profit" name={t('monthlyProfit')} fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Low Stock Items */}
      <div className="bg-white rounded-lg shadow p-5">
        <h2 className="text-lg font-semibold mb-4">{t('lowStockItems')}</h2>
        {lowStockItems.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('productCode', { ns: 'inventory' })}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('productName', { ns: 'inventory' })}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('availableQuantity', { ns: 'inventory' })}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('minStockLevel', { ns: 'inventory' })}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {t('branch', { ns: 'inventory' })}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {lowStockItems.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {item.code}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        {item.quantity}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.minLevel}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {item.branch}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500">{commonT('noData')}</p>
        )}
      </div>
    </div>
  );
}
