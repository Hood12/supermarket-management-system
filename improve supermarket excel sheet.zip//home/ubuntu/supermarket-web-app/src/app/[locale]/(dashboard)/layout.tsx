import { useTranslations } from 'next-intl';
import ReportScheduler from '@/components/reports/ReportScheduler';

export default function DashboardLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const t = useTranslations('common');

  return (
    <>
      <div className="flex h-screen bg-gray-50">
        <Sidebar locale={locale} />
        
        <div className="flex-1 ml-64">
          <header className="bg-white shadow-sm">
            <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
              <h1 className="text-lg font-semibold text-gray-900">{t('appName')}</h1>
            </div>
          </header>
          
          <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            {children}
          </main>
        </div>
      </div>
      
      {/* Hidden component that handles report scheduling */}
      <ReportScheduler />
    </>
  );
}

// Import Sidebar component to fix the error
import Sidebar from '@/components/layout/Sidebar';
