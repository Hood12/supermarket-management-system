"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { FiPlus, FiSave, FiSearch, FiFilter } from 'react-icons/fi';

// Form validation schema
const inventoryFilterSchema = z.object({
  branch_id: z.string().optional(),
  category_id: z.string().optional(),
  search: z.string().optional(),
  show_low_stock: z.boolean().optional(),
});

type InventoryFilterData = z.infer<typeof inventoryFilterSchema>;

export default function InventoryPage() {
  const t = useTranslations('inventory');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('all');

  // Sample data for demonstration
  const branches = [
    { id: '1', name: 'Industrial', name_ar: 'الصناعية' },
    { id: '2', name: 'Fesah', name_ar: 'فسح' },
    { id: '3', name: 'Omaq', name_ar: 'عمق' },
  ];

  const categories = [
    { id: '1', name: 'Beverages', name_ar: 'مشروبات' },
    { id: '2', name: 'Canned Goods', name_ar: 'معلبات' },
    { id: '3', name: 'Dairy', name_ar: 'منتجات الألبان' },
    { id: '4', name: 'Frozen Foods', name_ar: 'منتجات مجمدة' },
    { id: '5', name: 'Produce', name_ar: 'فواكه وخضروات' },
    { id: '6', name: 'Cleaning Products', name_ar: 'منتجات التنظيف' },
  ];

  const inventoryItems = [
    { 
      id: 1, 
      code: 'P1001', 
      name: 'Mineral Water', 
      name_ar: 'ماء معدني',
      category: 'Beverages',
      category_ar: 'مشروبات',
      purchase_price: 5.00,
      selling_price: 7.50,
      quantity: 25,
      min_stock_level: 10,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      last_updated: '2025-03-20'
    },
    { 
      id: 2, 
      code: 'P1002', 
      name: 'Milk', 
      name_ar: 'حليب',
      category: 'Dairy',
      category_ar: 'منتجات الألبان',
      purchase_price: 8.00,
      selling_price: 12.00,
      quantity: 15,
      min_stock_level: 8,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      last_updated: '2025-03-21'
    },
    { 
      id: 3, 
      code: 'P1003', 
      name: 'Rice', 
      name_ar: 'أرز',
      category: 'Canned Goods',
      category_ar: 'معلبات',
      purchase_price: 15.00,
      selling_price: 22.50,
      quantity: 3,
      min_stock_level: 5,
      branch: 'Industrial',
      branch_ar: 'الصناعية',
      last_updated: '2025-03-22'
    },
    { 
      id: 4, 
      code: 'P1004', 
      name: 'Sugar', 
      name_ar: 'سكر',
      category: 'Canned Goods',
      category_ar: 'معلبات',
      purchase_price: 10.00,
      selling_price: 15.00,
      quantity: 4,
      min_stock_level: 5,
      branch: 'Fesah',
      branch_ar: 'فسح',
      last_updated: '2025-03-22'
    },
  ];

  const lowStockItems = inventoryItems.filter(item => item.quantity < item.min_stock_level);

  const { control, handleSubmit } = useForm<InventoryFilterData>({
    resolver: zodResolver(inventoryFilterSchema),
    defaultValues: {
      branch_id: '',
      category_id: '',
      search: '',
      show_low_stock: false,
    }
  });

  const onFilterSubmit = (data: InventoryFilterData) => {
    console.log('Filter data:', data);
    // In a real application, this would filter the inventory items
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('title')}</h1>
        
        <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
          <FiPlus className="mr-2" />
          {t('addProduct')}
        </button>
      </div>
      
      {/* Filter Form */}
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">{commonT('filter')}</h2>
        </div>
        
        <form onSubmit={handleSubmit(onFilterSubmit)} className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Branch Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('branch')}
            </label>
            <Controller
              name="branch_id"
              control={control}
              render={({ field }) => (
                <select
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                >
                  <option value="">{commonT('all')}</option>
                  {branches.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.name}
                    </option>
                  ))}
                </select>
              )}
            />
          </div>
          
          {/* Category Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {t('category')}
            </label>
            <Controller
              name="category_id"
              control={control}
              render={({ field }) => (
                <select
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  {...field}
                >
                  <option value="">{commonT('all')}</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              )}
            />
          </div>
          
          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {commonT('search')}
            </label>
            <Controller
              name="search"
              control={control}
              render={({ field }) => (
                <div className="relative">
                  <input
                    type="text"
                    className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 pr-10"
                    placeholder={`${t('productCode')} / ${t('productName')}`}
                    {...field}
                  />
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <FiSearch className="text-gray-400" />
                  </div>
                </div>
              )}
            />
          </div>
          
          {/* Low Stock Checkbox */}
          <div className="flex items-end">
            <Controller
              name="show_low_stock"
              control={control}
              render={({ field }) => (
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="show_low_stock"
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={field.value}
                    onChange={field.onChange}
                  />
                  <label htmlFor="show_low_stock" className="ml-2 block text-sm text-gray-700">
                    {t('lowStock')}
                  </label>
                </div>
              )}
            />
            
            <button
              type="submit"
              className="ml-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiFilter className="mr-2" />
              {commonT('filter')}
            </button>
          </div>
        </form>
      </div>
      
      {/* Inventory Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('all')}
              className={`${
                activeTab === 'all'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {commonT('all')}
            </button>
            <button
              onClick={() => setActiveTab('low_stock')}
              className={`${
                activeTab === 'low_stock'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('lowStock')} ({lowStockItems.length})
            </button>
          </nav>
        </div>
      </div>
      
      {/* Inventory Table */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('productCode')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('productName')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('category')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('purchasePrice')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('sellingPrice')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('availableQuantity')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('minStockLevel')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('branch')}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {t('lastUpdate')}
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {(activeTab === 'all' ? inventoryItems : lowStockItems).map((item) => (
                <tr key={item.id} className={`hover:bg-gray-50 ${item.quantity < item.min_stock_level ? 'bg-red-50' : ''}`}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {item.code}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.category}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.purchase_price.toFixed(2)} ﷼
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.selling_price.toFixed(2)} ﷼
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      item.quantity < item.min_stock_level ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {item.quantity}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.min_stock_level}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.branch}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {item.last_updated}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Inventory Summary */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white shadow-md rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">{t('totalValue')}</h3>
          <p className="text-2xl font-bold text-blue-600">
            {inventoryItems.reduce((total, item) => total + (item.purchase_price * item.quantity), 0).toFixed(2)} ﷼
          </p>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">{t('potentialProfit')}</h3>
          <p className="text-2xl font-bold text-green-600">
            {inventoryItems.reduce((total, item) => total + ((item.selling_price - item.purchase_price) * item.quantity), 0).toFixed(2)} ﷼
          </p>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-2">{t('inventoryAlerts')}</h3>
          <p className="text-2xl font-bold text-orange-600">
            {lowStockItems.length}
          </p>
        </div>
      </div>
    </div>
  );
}
