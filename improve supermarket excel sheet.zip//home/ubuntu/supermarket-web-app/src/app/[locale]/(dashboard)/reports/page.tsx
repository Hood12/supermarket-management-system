"use client";

import { useTranslations } from 'next-intl';
import { useState } from 'react';
import { FiSend, FiClock, FiMail, FiSettings } from 'react-icons/fi';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import ReportActions from '@/components/reports/ReportActions';

export default function ReportsPage() {
  const t = useTranslations('reports');
  const commonT = useTranslations('common');
  const [activeTab, setActiveTab] = useState('preview');

  // Sample data for demonstration
  const salesData = [
    { name: '2025-03-16', sales: 10200, profit: 7650 },
    { name: '2025-03-17', sales: 11500, profit: 8625 },
    { name: '2025-03-18', sales: 9800, profit: 7350 },
    { name: '2025-03-19', sales: 12400, profit: 9300 },
    { name: '2025-03-20', sales: 11000, profit: 8250 },
    { name: '2025-03-21', sales: 11000, profit: 8200 },
    { name: '2025-03-22', sales: 12000, profit: 9000 },
  ];

  const branchData = [
    { name: 'Industrial', sales: 35400, profit: 26550, margin: 0.75 },
    { name: 'Fesah', sales: 32500, profit: 24375, margin: 0.75 },
    { name: 'Omaq', sales: 34200, profit: 25650, margin: 0.75 },
  ];

  const lowStockItems = [
    { id: 1, code: 'P1003', name: 'Rice', quantity: 3, minLevel: 5, branch: 'Industrial' },
    { id: 2, code: 'P1004', name: 'Sugar', quantity: 4, minLevel: 5, branch: 'Fesah' },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{t('title')}</h1>
        
        <ReportActions />
      </div>
      
      {/* Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('preview')}
              className={`${
                activeTab === 'preview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('reportPreview')}
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`${
                activeTab === 'settings'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {t('emailSettings')}
            </button>
          </nav>
        </div>
      </div>
      
      {activeTab === 'settings' ? (
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-6">{t('emailSettings')}</h2>
          
          {/* Email settings form would be here - using the existing form component */}
        </div>
      ) : (
        <div className="print:block" id="report-content">
          {/* Report Preview */}
          <div className="bg-white shadow-md rounded-lg p-6 mb-6 print:mb-8 print:shadow-none">
            <h2 className="text-xl font-semibold mb-6">{t('salesSummary')}</h2>
            
            <div className="h-80 print:h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={salesData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="sales" name={t('monthlySales', { ns: 'dashboard' })} stroke="#3b82f6" activeDot={{ r: 8 }} />
                  <Line type="monotone" dataKey="profit" name={t('monthlyProfit', { ns: 'dashboard' })} stroke="#10b981" />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 rounded-lg p-4 print:border print:border-gray-200">
                <h3 className="text-lg font-semibold mb-2">{t('monthlySales', { ns: 'dashboard' })}</h3>
                <p className="text-2xl font-bold text-blue-600">
                  {salesData.reduce((total, item) => total + item.sales, 0).toFixed(2)} ﷼
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 print:border print:border-gray-200">
                <h3 className="text-lg font-semibold mb-2">{t('monthlyProfit', { ns: 'dashboard' })}</h3>
                <p className="text-2xl font-bold text-green-600">
                  {salesData.reduce((total, item) => total + item.profit, 0).toFixed(2)} ﷼
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4 print:border print:border-gray-200">
                <h3 className="text-lg font-semibold mb-2">{t('profitMargin', { ns: 'dashboard' })}</h3>
                <p className="text-2xl font-bold text-purple-600">
                  {(salesData.reduce((total, item) => total + item.profit, 0) / salesData.reduce((total, item) => total + item.sales, 0) * 100).toFixed(2)}%
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white shadow-md rounded-lg p-6 mb-6 print:mb-8 print:shadow-none print:border print:border-gray-200">
            <h2 className="text-xl font-semibold mb-6">{t('branchComparison')}</h2>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('branch', { ns: 'sales' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('monthlySales', { ns: 'dashboard' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('monthlyProfit', { ns: 'dashboard' })}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t('profitMargin', { ns: 'dashboard' })}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {branchData.map((branch) => (
                    <tr key={branch.name} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {branch.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {branch.sales.toFixed(2)} ﷼
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {branch.profit.toFixed(2)} ﷼
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {(branch.margin * 100).toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="bg-white shadow-md rounded-lg p-6 print:shadow-none print:border print:border-gray-200">
            <h2 className="text-xl font-semibold mb-6">{t('inventoryAlerts')}</h2>
            
            {lowStockItems.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t('productCode', { ns: 'inventory' })}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t('productName', { ns: 'inventory' })}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t('availableQuantity', { ns: 'inventory' })}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t('minStockLevel', { ns: 'inventory' })}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {t('branch', { ns: 'inventory' })}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {lowStockItems.map((item) => (
                      <tr key={item.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.code}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                            {item.quantity}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.minLevel}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.branch}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500">{commonT('noData')}</p>
            )}
          </div>
          
          <div className="mt-8 text-center text-gray-500 text-sm print:mt-8">
            <p>تم إنشاء هذا التقرير تلقائيًا بواسطة نظام إدارة السوبرماركت</p>
            <p>This report was automatically generated by the Supermarket Management System</p>
            <p>{new Date().toLocaleDateString()}</p>
          </div>
        </div>
      )}
      
      {/* Print-only styles */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #report-content, #report-content * {
            visibility: visible;
          }
          #report-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}
