-- Initial database schema for Supermarket Management System

-- Users table for authentication
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT,
  role TEXT NOT NULL CHECK (role IN ('admin', 'manager', 'cashier')),
  branch_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id)
);

-- Branches table
CREATE TABLE IF NOT EXISTS branches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  location TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default branches
INSERT INTO branches (name, name_ar) VALUES 
  ('Industrial', 'الصناعية'),
  ('Fesah', 'فسح'),
  ('Omaq', 'عمق');

-- Expense categories table
CREATE TABLE IF NOT EXISTS expense_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  description TEXT,
  monthly_budget REAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default expense categories
INSERT INTO expense_categories (code, name, name_ar, description, monthly_budget) VALUES
  ('EXP001', 'Rent', 'الإيجار', 'Store rent', 5000),
  ('EXP002', 'Salaries', 'الرواتب', 'Employee salaries', 10000),
  ('EXP003', 'Utilities', 'المرافق', 'Electricity, water, internet', 2000),
  ('EXP004', 'Inventory', 'المخزون', 'Purchasing goods', 20000),
  ('EXP005', 'Marketing', 'التسويق', 'Advertising and promotion', 1500),
  ('EXP006', 'Maintenance', 'الصيانة', 'Equipment and building maintenance', 1000),
  ('EXP007', 'Other', 'أخرى', 'Miscellaneous expenses', 1000);

-- Product categories table
CREATE TABLE IF NOT EXISTS product_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default product categories
INSERT INTO product_categories (name, name_ar) VALUES
  ('Beverages', 'مشروبات'),
  ('Canned Goods', 'معلبات'),
  ('Dairy', 'منتجات الألبان'),
  ('Frozen Foods', 'منتجات مجمدة'),
  ('Produce', 'فواكه وخضروات'),
  ('Cleaning Products', 'منتجات التنظيف');

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  name_ar TEXT NOT NULL,
  category_id INTEGER NOT NULL,
  purchase_price REAL NOT NULL,
  selling_price REAL NOT NULL,
  min_stock_level INTEGER NOT NULL DEFAULT 5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES product_categories(id)
);

-- Insert sample products
INSERT INTO products (code, name, name_ar, category_id, purchase_price, selling_price, min_stock_level) VALUES
  ('P1001', 'Mineral Water', 'ماء معدني', 1, 5.00, 7.50, 10),
  ('P1002', 'Milk', 'حليب', 3, 8.00, 12.00, 8),
  ('P1003', 'Rice', 'أرز', 2, 15.00, 22.50, 5),
  ('P1004', 'Sugar', 'سكر', 2, 10.00, 15.00, 5),
  ('P1005', 'Oil', 'زيت', 2, 18.00, 25.00, 5),
  ('P1006', 'Pasta', 'معكرونة', 2, 7.00, 10.00, 10),
  ('P1007', 'Soap', 'صابون', 6, 6.00, 9.00, 15),
  ('P1008', 'Shampoo', 'شامبو', 6, 12.00, 18.00, 8),
  ('P1009', 'Juice', 'عصير', 1, 9.00, 13.50, 10),
  ('P1010', 'Biscuits', 'بسكويت', 2, 8.00, 12.00, 12);

-- Inventory table
CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  branch_id INTEGER NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id),
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  UNIQUE(product_id, branch_id)
);

-- Insert sample inventory data
INSERT INTO inventory (product_id, branch_id, quantity) VALUES
  (1, 1, 25), (1, 2, 20), (1, 3, 18),
  (2, 1, 15), (2, 2, 12), (2, 3, 10),
  (3, 1, 8), (3, 2, 6), (3, 3, 7),
  (4, 1, 10), (4, 2, 8), (4, 3, 9),
  (5, 1, 12), (5, 2, 10), (5, 3, 8),
  (6, 1, 20), (6, 2, 18), (6, 3, 15),
  (7, 1, 25), (7, 2, 20), (7, 3, 22),
  (8, 1, 15), (8, 2, 12), (8, 3, 10),
  (9, 1, 18), (9, 2, 15), (9, 3, 12),
  (10, 1, 22), (10, 2, 18), (10, 3, 15);

-- Daily sales table
CREATE TABLE IF NOT EXISTS daily_sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL,
  branch_id INTEGER NOT NULL,
  cash_sales REAL NOT NULL DEFAULT 0,
  visa_sales REAL NOT NULL DEFAULT 0,
  total_revenue REAL NOT NULL DEFAULT 0,
  expenses REAL NOT NULL DEFAULT 0,
  expense_category_id INTEGER,
  daily_profit REAL NOT NULL DEFAULT 0,
  employee_name TEXT,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  FOREIGN KEY (expense_category_id) REFERENCES expense_categories(id)
);

-- Insert sample daily sales data
INSERT INTO daily_sales (date, branch_id, cash_sales, visa_sales, total_revenue, expenses, expense_category_id, daily_profit, employee_name) VALUES
  (date('now'), 1, 5000, 7000, 12000, 3000, 1, 9000, 'Mohammed'),
  (date('now', '-1 day'), 2, 4500, 6500, 11000, 2800, 2, 8200, 'Ahmed'),
  (date('now', '-2 day'), 3, 5200, 7200, 12400, 3200, 3, 9200, 'Fatima'),
  (date('now', '-3 day'), 1, 4800, 6800, 11600, 2900, 4, 8700, 'Sara'),
  (date('now', '-4 day'), 2, 5100, 7100, 12200, 3100, 5, 9100, 'Khalid');

-- Monthly summary table (can be generated from daily_sales)
CREATE TABLE IF NOT EXISTS monthly_summary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  branch_id INTEGER NOT NULL,
  total_cash_sales REAL NOT NULL DEFAULT 0,
  total_visa_sales REAL NOT NULL DEFAULT 0,
  total_revenue REAL NOT NULL DEFAULT 0,
  total_expenses REAL NOT NULL DEFAULT 0,
  net_profit REAL NOT NULL DEFAULT 0,
  transaction_count INTEGER NOT NULL DEFAULT 0,
  avg_transaction_value REAL NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  UNIQUE(month, year, branch_id)
);

-- Yearly summary table (can be generated from monthly_summary)
CREATE TABLE IF NOT EXISTS yearly_summary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  year INTEGER NOT NULL,
  branch_id INTEGER NOT NULL,
  total_cash_sales REAL NOT NULL DEFAULT 0,
  total_visa_sales REAL NOT NULL DEFAULT 0,
  total_revenue REAL NOT NULL DEFAULT 0,
  total_expenses REAL NOT NULL DEFAULT 0,
  net_profit REAL NOT NULL DEFAULT 0,
  growth_rate REAL,
  transaction_count INTEGER NOT NULL DEFAULT 0,
  avg_transaction_value REAL NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (branch_id) REFERENCES branches(id),
  UNIQUE(year, branch_id)
);

-- Email reports configuration
CREATE TABLE IF NOT EXISTS email_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  recipient_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  send_time TEXT NOT NULL,
  frequency TEXT NOT NULL,
  include_sales_summary BOOLEAN NOT NULL DEFAULT 1,
  include_profit_summary BOOLEAN NOT NULL DEFAULT 1,
  include_branch_comparison BOOLEAN NOT NULL DEFAULT 1,
  include_inventory_alerts BOOLEAN NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default email report configuration
INSERT INTO email_reports (recipient_email, subject, send_time, frequency) VALUES
  ('muneer1122337@gmail.com', 'تقرير السوبرماركت اليومي / Daily Supermarket Report', '18:00', 'daily');
