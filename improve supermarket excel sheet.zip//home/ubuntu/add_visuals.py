import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
import datetime
from openpyxl.chart import BarChart, Reference, LineChart, PieChart
from openpyxl.chart.label import DataLabelList

# Define paths
input_file = '/home/ubuntu/improved_supermarket_system_with_formulas.xlsx'
output_file = '/home/ubuntu/improved_supermarket_system_with_visuals.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(input_file)

# Function to add sales trend chart to Daily Entry sheet
def add_daily_sales_chart(sheet):
    # Create a bar chart for daily sales
    chart = BarChart()
    chart.title = "مبيعات يومية / Daily Sales"
    chart.style = 10  # Use a modern style
    chart.x_axis.title = "التاريخ / Date"
    chart.y_axis.title = "المبيعات / Sales"
    
    # Get the last row with data
    max_row = 0
    for row in range(2, sheet.max_row):
        if sheet.cell(row=row, column=1).value is not None:
            max_row = row
        else:
            break
    
    if max_row < 2:
        max_row = 11  # Default if no data
    
    # Define data ranges
    dates = Reference(sheet, min_col=1, min_row=2, max_row=max_row)
    cash_sales = Reference(sheet, min_col=3, min_row=1, max_row=max_row)
    visa_sales = Reference(sheet, min_col=4, min_row=1, max_row=max_row)
    
    # Add data series
    chart.add_data(cash_sales, titles_from_data=True)
    chart.add_data(visa_sales, titles_from_data=True)
    chart.set_categories(dates)
    
    # Add data labels
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    
    # Set chart size and position
    chart.width = 15
    chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(chart, "A" + str(max_row + 5))
    
    # Create a line chart for profit trend
    line_chart = LineChart()
    line_chart.title = "اتجاه الربح / Profit Trend"
    line_chart.style = 12
    line_chart.x_axis.title = "التاريخ / Date"
    line_chart.y_axis.title = "الربح / Profit"
    
    # Define data range for profit
    profit = Reference(sheet, min_col=8, min_row=1, max_row=max_row)
    
    # Add data series
    line_chart.add_data(profit, titles_from_data=True)
    line_chart.set_categories(dates)
    
    # Add data labels
    line_chart.dataLabels = DataLabelList()
    line_chart.dataLabels.showVal = True
    
    # Set chart size and position
    line_chart.width = 15
    line_chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(line_chart, "A" + str(max_row + 25))

# Function to add branch comparison chart to Monthly Summary sheet
def add_branch_comparison_chart(sheet):
    # Create a bar chart for branch comparison
    chart = BarChart()
    chart.title = "مقارنة المبيعات حسب الفرع / Sales Comparison by Branch"
    chart.style = 10
    chart.x_axis.title = "الفرع / Branch"
    chart.y_axis.title = "المبيعات / Sales"
    
    # Find the branch comparison section
    branch_row = 0
    for row in range(1, sheet.max_row):
        if sheet.cell(row=row, column=1).value == "مقارنة الفروع / Branch Comparison":
            branch_row = row
            break
    
    if branch_row == 0:
        return  # Branch comparison section not found
    
    # Define data ranges
    branches = Reference(sheet, min_col=1, min_row=branch_row + 2, max_row=branch_row + 5)
    sales = Reference(sheet, min_col=2, min_row=branch_row + 1, max_row=branch_row + 5)
    
    # Add data series
    chart.add_data(sales, titles_from_data=True)
    chart.set_categories(branches)
    
    # Add data labels
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    
    # Set chart size and position
    chart.width = 15
    chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(chart, "A" + str(branch_row + 10))
    
    # Create a pie chart for profit distribution
    pie_chart = PieChart()
    pie_chart.title = "توزيع الربح حسب الفرع / Profit Distribution by Branch"
    pie_chart.style = 10
    
    # Define data range for profit
    profit = Reference(sheet, min_col=4, min_row=branch_row + 1, max_row=branch_row + 5)
    
    # Add data series
    pie_chart.add_data(profit, titles_from_data=True)
    pie_chart.set_categories(branches)
    
    # Add data labels
    pie_chart.dataLabels = DataLabelList()
    pie_chart.dataLabels.showPercent = True
    
    # Set chart size and position
    pie_chart.width = 15
    pie_chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(pie_chart, "A" + str(branch_row + 30))

# Function to add yearly trend chart to Yearly Summary sheet
def add_yearly_trend_chart(sheet):
    # Create a line chart for yearly trend
    chart = LineChart()
    chart.title = "اتجاه المبيعات السنوية / Yearly Sales Trend"
    chart.style = 12
    chart.x_axis.title = "السنة / Year"
    chart.y_axis.title = "المبيعات / Sales"
    
    # Get the last row with data
    max_row = 0
    for row in range(2, sheet.max_row):
        if sheet.cell(row=row, column=1).value is not None:
            max_row = row
        else:
            break
    
    if max_row < 2:
        max_row = 11  # Default if no data
    
    # Define data ranges
    years = Reference(sheet, min_col=1, min_row=2, max_row=max_row)
    revenue = Reference(sheet, min_col=5, min_row=1, max_row=max_row)
    
    # Add data series
    chart.add_data(revenue, titles_from_data=True)
    chart.set_categories(years)
    
    # Add data labels
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    
    # Set chart size and position
    chart.width = 15
    chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(chart, "A" + str(max_row + 5))
    
    # Create a bar chart for profit comparison
    bar_chart = BarChart()
    bar_chart.title = "مقارنة الربح السنوي / Yearly Profit Comparison"
    bar_chart.style = 10
    bar_chart.x_axis.title = "السنة / Year"
    bar_chart.y_axis.title = "الربح / Profit"
    
    # Define data range for profit
    profit = Reference(sheet, min_col=7, min_row=1, max_row=max_row)
    
    # Add data series
    bar_chart.add_data(profit, titles_from_data=True)
    bar_chart.set_categories(years)
    
    # Add data labels
    bar_chart.dataLabels = DataLabelList()
    bar_chart.dataLabels.showVal = True
    
    # Set chart size and position
    bar_chart.width = 15
    bar_chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(bar_chart, "A" + str(max_row + 25))

# Function to add inventory charts to Inventory sheet
def add_inventory_charts(sheet):
    # Create a bar chart for inventory levels
    chart = BarChart()
    chart.title = "مستويات المخزون / Inventory Levels"
    chart.style = 10
    chart.x_axis.title = "المنتج / Product"
    chart.y_axis.title = "الكمية / Quantity"
    
    # Get the last row with data
    max_row = 0
    for row in range(2, sheet.max_row):
        if sheet.cell(row=row, column=1).value is not None:
            max_row = row
        else:
            break
    
    if max_row < 2:
        max_row = 11  # Default if no data
    
    # Define data ranges
    products = Reference(sheet, min_col=2, min_row=2, max_row=max_row)
    quantity = Reference(sheet, min_col=6, min_row=1, max_row=max_row)
    min_level = Reference(sheet, min_col=7, min_row=1, max_row=max_row)
    
    # Add data series
    chart.add_data(quantity, titles_from_data=True)
    chart.add_data(min_level, titles_from_data=True)
    chart.set_categories(products)
    
    # Add data labels
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    
    # Set chart size and position
    chart.width = 15
    chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(chart, "A" + str(max_row + 5))
    
    # Create a pie chart for inventory value by category
    pie_chart = PieChart()
    pie_chart.title = "قيمة المخزون حسب الفئة / Inventory Value by Category"
    pie_chart.style = 10
    
    # We'll need to calculate this data first
    # For simplicity, we'll use a few sample categories
    categories = {}
    for row in range(2, max_row + 1):
        category = sheet.cell(row=row, column=3).value
        value = sheet.cell(row=row, column=4).value * sheet.cell(row=row, column=6).value
        if category in categories:
            categories[category] += value
        else:
            categories[category] = value
    
    # Add the data to the sheet for the chart
    cat_row = max_row + 25
    sheet.cell(row=cat_row, column=1).value = "الفئة / Category"
    sheet.cell(row=cat_row, column=2).value = "قيمة المخزون / Inventory Value"
    
    for i, (category, value) in enumerate(categories.items()):
        sheet.cell(row=cat_row + i + 1, column=1).value = category
        sheet.cell(row=cat_row + i + 1, column=2).value = value
    
    # Define data ranges for the pie chart
    cat_labels = Reference(sheet, min_col=1, min_row=cat_row + 1, max_row=cat_row + len(categories))
    cat_values = Reference(sheet, min_col=2, min_row=cat_row, max_row=cat_row + len(categories))
    
    # Add data series
    pie_chart.add_data(cat_values, titles_from_data=True)
    pie_chart.set_categories(cat_labels)
    
    # Add data labels
    pie_chart.dataLabels = DataLabelList()
    pie_chart.dataLabels.showPercent = True
    
    # Set chart size and position
    pie_chart.width = 15
    pie_chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(pie_chart, "A" + str(cat_row + 5))

# Function to add dashboard charts
def add_dashboard_charts(sheet):
    # Create a bar chart for sales by branch
    chart = BarChart()
    chart.title = "المبيعات حسب الفرع / Sales by Branch"
    chart.style = 10
    chart.x_axis.title = "الفرع / Branch"
    chart.y_axis.title = "المبيعات / Sales"
    
    # Define data ranges
    branches = Reference(sheet, min_col=6, min_row=7, max_row=9)
    sales = Reference(sheet, min_col=7, min_row=6, max_row=9)
    
    # Add data series
    chart.add_data(sales, titles_from_data=True)
    chart.set_categories(branches)
    
    # Add data labels
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    
    # Set chart size and position
    chart.width = 15
    chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(chart, "A25")
    
    # Create a pie chart for profit distribution
    pie_chart = PieChart()
    pie_chart.title = "توزيع الربح حسب الفرع / Profit Distribution by Branch"
    pie_chart.style = 10
    
    # Define data range for profit
    profit = Reference(sheet, min_col=8, min_row=6, max_row=9)
    
    # Add data series
    pie_chart.add_data(profit, titles_from_data=True)
    pie_chart.set_categories(branches)
    
    # Add data labels
    pie_chart.dataLabels = DataLabelList()
    pie_chart.dataLabels.showPercent = True
    
    # Set chart size and position
    pie_chart.width = 15
    pie_chart.height = 10
    
    # Add the chart to the sheet
    sheet.add_chart(pie_chart, "A45")

# Add visual improvements to all sheets
print("Adding charts to Daily Entry sheet...")
try:
    add_daily_sales_chart(wb['Daily Entry'])
except Exception as e:
    print(f"Error adding charts to Daily Entry sheet: {e}")

print("Adding charts to Monthly Summary sheet...")
try:
    add_branch_comparison_chart(wb['Monthly Summary'])
except Exception as e:
    print(f"Error adding charts to Monthly Summary sheet: {e}")

print("Adding charts to Yearly Summary sheet...")
try:
    add_yearly_trend_chart(wb['Yearly Summary'])
except Exception as e:
    print(f"Error adding charts to Yearly Summary sheet: {e}")

print("Adding charts to Inventory sheet...")
try:
    add_inventory_charts(wb['Inventory'])
except Exception as e:
    print(f"Error adding charts to Inventory sheet: {e}")

print("Adding charts to Dashboard sheet...")
try:
    add_dashboard_charts(wb['Dashboard'])
except Exception as e:
    print(f"Error adding charts to Dashboard sheet: {e}")

# Save the workbook
wb.save(output_file)

print(f"Visual improvements added and saved to {output_file}")
print("The following visual improvements have been made:")
print("1. Added daily sales bar chart to Daily Entry sheet")
print("2. Added profit trend line chart to Daily Entry sheet")
print("3. Added branch comparison bar chart to Monthly Summary sheet")
print("4. Added profit distribution pie chart to Monthly Summary sheet")
print("5. Added yearly sales trend line chart to Yearly Summary sheet")
print("6. Added yearly profit comparison bar chart to Yearly Summary sheet")
print("7. Added inventory levels bar chart to Inventory sheet")
print("8. Added inventory value by category pie chart to Inventory sheet")
print("9. Added sales by branch bar chart to Dashboard")
print("10. Added profit distribution pie chart to Dashboard")
