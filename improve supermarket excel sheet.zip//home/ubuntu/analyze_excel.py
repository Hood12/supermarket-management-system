import pandas as pd
import openpyxl
from openpyxl.utils import get_column_letter

file_path = '/home/ubuntu/upload/نظام_محدث_للسوبرماركت.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(file_path)
print('Sheet names:', wb.sheetnames)

# Analyze each sheet
for sheet_name in wb.sheetnames:
    print(f'\n--- Sheet: {sheet_name} ---')
    sheet = wb[sheet_name]
    print(f'Dimensions: {sheet.dimensions}')
    print(f'Max row: {sheet.max_row}, Max column: {sheet.max_column}')
    
    # Print column headers (first row)
    print("\nColumn Headers:")
    for col in range(1, min(sheet.max_column + 1, 20)):  # Limit to first 20 columns
        cell_value = sheet.cell(row=1, column=col).value
        if cell_value:
            print(f"Column {get_column_letter(col)}: {cell_value}")
    
    # Sample data (first few rows)
    print("\nSample Data (first 5 rows):")
    for row in range(2, min(sheet.max_row + 1, 7)):  # Rows 2-6 (up to 5 data rows)
        row_data = []
        for col in range(1, min(sheet.max_column + 1, 10)):  # First 10 columns
            cell_value = sheet.cell(row=row, column=col).value
            row_data.append(str(cell_value) if cell_value is not None else "None")
        print(f"Row {row}: {' | '.join(row_data)}")
    
    # Check for formulas
    print("\nChecking for formulas...")
    formula_count = 0
    for row in range(1, sheet.max_row + 1):
        for col in range(1, sheet.max_column + 1):
            cell = sheet.cell(row=row, column=col)
            if cell.data_type == 'f':
                formula_count += 1
                if formula_count <= 5:  # Show only first 5 formulas
                    print(f"Formula at {get_column_letter(col)}{row}: {cell.value}")
    print(f"Total formulas found: {formula_count}")
    
    # Check for merged cells
    if sheet.merged_cells:
        print("\nMerged cells:")
        for merged_range in list(sheet.merged_cells)[:5]:  # Show only first 5 merged ranges
            print(merged_range)
        print(f"Total merged cell ranges: {len(sheet.merged_cells)}")
    
    # Check for conditional formatting
    if hasattr(sheet, 'conditional_formatting'):
        print("\nConditional formatting:")
        for cf_range in sheet.conditional_formatting:
            print(f"Range: {cf_range}")
        print(f"Total conditional formatting rules: {len(sheet.conditional_formatting)}")
