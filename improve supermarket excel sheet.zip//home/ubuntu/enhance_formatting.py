import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side, Color
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import Rule, CellIsRule, FormulaRule
from openpyxl.utils import get_column_letter
import datetime

# Define paths
input_file = '/home/ubuntu/improved_supermarket_system.xlsx'
output_file = '/home/ubuntu/improved_supermarket_system_formatted.xlsx'

# Load the workbook
wb = openpyxl.load_workbook(input_file)

# Define common styles
header_font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
header_fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
header_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

subheader_font = Font(name='Arial', size=11, bold=True)
subheader_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
subheader_alignment = Alignment(horizontal='center', vertical='center')
subheader_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

data_font = Font(name='Arial', size=11)
data_alignment = Alignment(horizontal='center', vertical='center')
data_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

money_font = Font(name='Arial', size=11)
money_alignment = Alignment(horizontal='right', vertical='center')
money_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

date_font = Font(name='Arial', size=11)
date_alignment = Alignment(horizontal='center', vertical='center')
date_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

# Function to apply number formatting
def apply_number_format(sheet, start_row, end_row, columns, format_code='#,##0.00 [$﷼]'):
    for row in range(start_row, end_row + 1):
        for col in columns:
            cell = sheet.cell(row=row, column=col)
            cell.number_format = format_code
            cell.font = money_font
            cell.alignment = money_alignment
            cell.border = money_border

# Function to apply date formatting
def apply_date_format(sheet, start_row, end_row, columns, format_code='yyyy-mm-dd'):
    for row in range(start_row, end_row + 1):
        for col in columns:
            cell = sheet.cell(row=row, column=col)
            cell.number_format = format_code
            cell.font = date_font
            cell.alignment = date_alignment
            cell.border = date_border

# Function to apply conditional formatting
def apply_conditional_formatting(sheet, range_string, formula, color):
    rule = FormulaRule(formula=[formula], stopIfTrue=True, fill=PatternFill(start_color=color, end_color=color, fill_type='solid'))
    sheet.conditional_formatting.add(range_string, rule)

# Function to apply alternating row colors
def apply_alternating_row_colors(sheet, start_row, end_row, start_col, end_col):
    for row in range(start_row, end_row + 1):
        if row % 2 == 0:  # Even rows
            for col in range(start_col, end_col + 1):
                cell = sheet.cell(row=row, column=col)
                cell.fill = PatternFill(start_color='F2F2F2', end_color='F2F2F2', fill_type='solid')

# Function to freeze panes
def freeze_panes(sheet, row, col):
    sheet.freeze_panes = sheet.cell(row=row, column=col).coordinate

# Function to add sample data
def add_sample_data(sheet, num_rows=10):
    # Get headers from first row
    headers = [sheet.cell(row=1, column=col).value for col in range(1, sheet.max_column + 1)]
    
    # Sample data based on sheet name and headers
    if sheet.title == 'Daily Entry' or sheet.title in ['Industrial', 'Fesah', 'Omaq']:
        # Add sample data for daily entry and branch sheets
        for row in range(2, 2 + num_rows):
            # Date
            sheet.cell(row=row, column=1).value = datetime.datetime.now() - datetime.timedelta(days=row-2)
            
            # Branch (if Daily Entry sheet)
            if sheet.title == 'Daily Entry':
                branches = ['Industrial', 'Fesah', 'Omaq']
                sheet.cell(row=row, column=2).value = branches[(row-2) % 3]
            
            # Cash Sales (random between 1000 and 5000)
            cash_sales = 1000 + (row * 123) % 4000
            sheet.cell(row=row, column=3).value = cash_sales
            
            # Visa Sales (random between 2000 and 8000)
            visa_sales = 2000 + (row * 234) % 6000
            sheet.cell(row=row, column=4).value = visa_sales
            
            # Total Revenue (formula will be added later)
            sheet.cell(row=row, column=5).value = cash_sales + visa_sales
            
            # Expenses (random between 500 and 3000)
            expenses = 500 + (row * 111) % 2500
            sheet.cell(row=row, column=6).value = expenses
            
            # Expense Category
            expense_categories = ['الإيجار / Rent', 'الرواتب / Salaries', 'المرافق / Utilities', 
                                 'المخزون / Inventory', 'التسويق / Marketing', 'الصيانة / Maintenance', 'أخرى / Other']
            sheet.cell(row=row, column=7).value = expense_categories[(row-2) % 7]
            
            # Daily Profit (formula will be added later)
            sheet.cell(row=row, column=8).value = (cash_sales + visa_sales) - expenses
            
            # Employee Name
            employees = ['محمد / Mohammed', 'أحمد / Ahmed', 'فاطمة / Fatima', 'سارة / Sara', 'خالد / Khalid']
            sheet.cell(row=row, column=9).value = employees[(row-2) % 5]
            
            # Notes
            sheet.cell(row=row, column=10).value = f"ملاحظة يوم {row-1} / Note for day {row-1}"
    
    elif sheet.title == 'Inventory':
        # Add sample data for inventory sheet
        categories = ['مشروبات / Beverages', 'معلبات / Canned Goods', 'منتجات الألبان / Dairy', 
                     'منتجات مجمدة / Frozen Foods', 'فواكه وخضروات / Produce', 'منتجات التنظيف / Cleaning Products']
        branches = ['Industrial', 'Fesah', 'Omaq']
        
        for row in range(2, 2 + num_rows):
            # Product Code
            sheet.cell(row=row, column=1).value = f"P{1000 + row-2}"
            
            # Product Name
            products = ['ماء معدني / Mineral Water', 'حليب / Milk', 'أرز / Rice', 'سكر / Sugar', 
                       'زيت / Oil', 'معكرونة / Pasta', 'صابون / Soap', 'شامبو / Shampoo', 'عصير / Juice', 'بسكويت / Biscuits']
            sheet.cell(row=row, column=2).value = products[(row-2) % 10]
            
            # Category
            sheet.cell(row=row, column=3).value = categories[(row-2) % 6]
            
            # Purchase Price
            purchase_price = 5 + (row * 7) % 95
            sheet.cell(row=row, column=4).value = purchase_price
            
            # Selling Price
            sheet.cell(row=row, column=5).value = purchase_price * 1.3  # 30% markup
            
            # Available Quantity
            sheet.cell(row=row, column=6).value = 10 + (row * 5) % 90
            
            # Min Stock Level
            sheet.cell(row=row, column=7).value = 5
            
            # Last Update Date
            sheet.cell(row=row, column=8).value = datetime.datetime.now() - datetime.timedelta(days=(row-2) % 30)
            
            # Branch
            sheet.cell(row=row, column=9).value = branches[(row-2) % 3]
            
            # Notes
            sheet.cell(row=row, column=10).value = f"ملاحظة للمنتج {row-1} / Note for product {row-1}"

    elif sheet.title == 'Monthly Summary':
        # Add sample data for monthly summary
        months = ['يناير / January', 'فبراير / February', 'مارس / March', 'أبريل / April', 
                 'مايو / May', 'يونيو / June', 'يوليو / July', 'أغسطس / August', 
                 'سبتمبر / September', 'أكتوبر / October', 'نوفمبر / November', 'ديسمبر / December']
        branches = ['Industrial', 'Fesah', 'Omaq']
        
        row_idx = 2
        for year in [2024, 2025]:
            for month_idx, month in enumerate(months):
                for branch_idx, branch in enumerate(branches):
                    if row_idx <= 2 + num_rows:
                        # Month
                        sheet.cell(row=row_idx, column=1).value = month
                        
                        # Year
                        sheet.cell(row=row_idx, column=2).value = year
                        
                        # Branch
                        sheet.cell(row=row_idx, column=3).value = branch
                        
                        # Total Cash Sales
                        base_sales = 30000 + (month_idx * 5000)
                        variation = (branch_idx * 3000) + (year - 2024) * 10000
                        cash_sales = base_sales + variation
                        sheet.cell(row=row_idx, column=4).value = cash_sales
                        
                        # Total Visa Sales
                        visa_sales = cash_sales * 1.5
                        sheet.cell(row=row_idx, column=5).value = visa_sales
                        
                        # Total Revenue
                        sheet.cell(row=row_idx, column=6).value = cash_sales + visa_sales
                        
                        # Total Expenses
                        expenses = (cash_sales + visa_sales) * 0.6
                        sheet.cell(row=row_idx, column=7).value = expenses
                        
                        # Net Profit
                        sheet.cell(row=row_idx, column=8).value = (cash_sales + visa_sales) - expenses
                        
                        # Transaction Count
                        sheet.cell(row=row_idx, column=9).value = int((cash_sales + visa_sales) / 100)
                        
                        # Average Transaction Value
                        sheet.cell(row=row_idx, column=10).value = 100
                        
                        row_idx += 1

    elif sheet.title == 'Yearly Summary':
        # Add sample data for yearly summary
        branches = ['Industrial', 'Fesah', 'Omaq']
        
        row_idx = 2
        for year in range(2023, 2026):
            for branch_idx, branch in enumerate(branches):
                if row_idx <= 2 + num_rows:
                    # Year
                    sheet.cell(row=row_idx, column=1).value = year
                    
                    # Branch
                    sheet.cell(row=row_idx, column=2).value = branch
                    
                    # Total Cash Sales
                    base_sales = 300000 + ((year - 2023) * 50000)
                    variation = branch_idx * 30000
                    cash_sales = base_sales + variation
                    sheet.cell(row=row_idx, column=3).value = cash_sales
                    
                    # Total Visa Sales
                    visa_sales = cash_sales * 1.5
                    sheet.cell(row=row_idx, column=4).value = visa_sales
                    
                    # Total Revenue
                    sheet.cell(row=row_idx, column=5).value = cash_sales + visa_sales
                    
                    # Total Expenses
                    expenses = (cash_sales + visa_sales) * 0.6
                    sheet.cell(row=row_idx, column=6).value = expenses
                    
                    # Net Profit
                    sheet.cell(row=row_idx, column=7).value = (cash_sales + visa_sales) - expenses
                    
                    # Growth Rate
                    sheet.cell(row=row_idx, column=8).value = 0.1 + (year - 2023) * 0.05
                    sheet.cell(row=row_idx, column=8).number_format = '0.00%'
                    
                    # Transaction Count
                    sheet.cell(row=row_idx, column=9).value = int((cash_sales + visa_sales) / 100)
                    
                    # Average Transaction Value
                    sheet.cell(row=row_idx, column=10).value = 100
                    
                    row_idx += 1

# Apply formatting to all sheets
for sheet_name in wb.sheetnames:
    sheet = wb[sheet_name]
    
    # Apply formatting to headers (first row)
    for col in range(1, sheet.max_column + 1):
        cell = sheet.cell(row=1, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = header_border
    
    # Freeze the top row
    freeze_panes(sheet, 2, 1)
    
    # Add sample data
    add_sample_data(sheet)
    
    # Apply alternating row colors
    apply_alternating_row_colors(sheet, 2, sheet.max_row, 1, sheet.max_column)
    
    # Apply specific formatting based on sheet type
    if sheet_name == 'Daily Entry' or sheet_name in ['Industrial', 'Fesah', 'Omaq']:
        # Apply date formatting to date column
        apply_date_format(sheet, 2, sheet.max_row, [1], 'yyyy-mm-dd')
        
        # Apply currency formatting to monetary columns
        apply_number_format(sheet, 2, sheet.max_row, [3, 4, 5, 6, 8])
        
        # Apply conditional formatting for profit column
        apply_conditional_formatting(sheet, f'H2:H{sheet.max_row}', 'H2>0', '92D050')  # Green for profit
        apply_conditional_formatting(sheet, f'H2:H{sheet.max_row}', 'H2<0', 'FF0000')  # Red for loss
    
    elif sheet_name == 'Inventory':
        # Apply currency formatting to price columns
        apply_number_format(sheet, 2, sheet.max_row, [4, 5])
        
        # Apply date formatting to date column
        apply_date_format(sheet, 2, sheet.max_row, [8], 'yyyy-mm-dd')
        
        # Apply conditional formatting for stock level
        apply_conditional_formatting(sheet, f'F2:F{sheet.max_row}', 'F2<G2', 'FF0000')  # Red if below min stock
    
    elif sheet_name == 'Monthly Summary' or sheet_name == 'Yearly Summary':
        # Apply currency formatting to monetary columns
        apply_number_format(sheet, 2, sheet.max_row, [4, 5, 6, 7, 8, 10])
        
        # Apply conditional formatting for profit column
        apply_conditional_formatting(sheet, f'H2:H{sheet.max_row}', 'H2>0', '92D050')  # Green for profit
        apply_conditional_formatting(sheet, f'H2:H{sheet.max_row}', 'H2<0', 'FF0000')  # Red for loss
        
        if sheet_name == 'Yearly Summary':
            # Apply percentage formatting to growth rate column
            for row in range(2, sheet.max_row + 1):
                cell = sheet.cell(row=row, column=8)
                cell.number_format = '0.00%'
    
    elif sheet_name == 'Expenses Categories':
        # Apply currency formatting to budget column
        apply_number_format(sheet, 2, sheet.max_row, [4])

# Save the workbook
wb.save(output_file)

print(f"Enhanced data organization and formatting applied and saved to {output_file}")
print("The following formatting improvements have been made:")
print("1. Applied consistent header formatting with background colors")
print("2. Added alternating row colors for better readability")
print("3. Applied appropriate number formatting for monetary values")
print("4. Applied date formatting for date fields")
print("5. Added conditional formatting for profits/losses and inventory levels")
print("6. Froze header rows for easier navigation")
print("7. Add<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>