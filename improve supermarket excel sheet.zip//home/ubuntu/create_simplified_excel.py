import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
import datetime

# Define paths
input_file = '/home/ubuntu/upload/نظام_محدث_للسوبرماركت.xlsx'
output_file = '/home/ubuntu/fixed_supermarket_system.xlsx'

# Load the original workbook
original_wb = openpyxl.load_workbook(input_file)

# Create a new workbook
wb = openpyxl.Workbook()

# Remove the default sheet
default_sheet = wb.active
wb.remove(default_sheet)

# Define common styles
header_font = Font(name='Arial', size=12, bold=True, color='FFFFFF')
header_fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
header_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

data_font = Font(name='Arial', size=11)
data_alignment = Alignment(horizontal='center', vertical='center')
data_border = Border(
    left=Side(style='thin', color='000000'),
    right=Side(style='thin', color='000000'),
    top=Side(style='thin', color='000000'),
    bottom=Side(style='thin', color='000000')
)

# Create Daily Entry sheet (main data entry)
daily_entry = wb.create_sheet('Daily Entry')
daily_entry.sheet_properties.tabColor = "00B0F0"

# Create branch-specific sheets
branches = ['Industrial', 'Fesah', 'Omaq']
branch_sheets = {}

for branch in branches:
    sheet_name = f"{branch}"
    branch_sheets[branch] = wb.create_sheet(sheet_name)
    branch_sheets[branch].sheet_properties.tabColor = "92D050"

# Set up Daily Entry sheet
daily_headers = [
    'التاريخ / Date', 
    'الفرع / Branch', 
    'المبيعات (كاش) / Cash Sales', 
    'المبيعات (فيزا) / Visa Sales', 
    'إجمالي الإيرادات / Total Revenue', 
    'المصروفات / Expenses', 
    'الربح اليومي / Daily Profit', 
    'اسم الموظف / Employee Name',
    'ملاحظات / Notes'
]

for col_idx, header in enumerate(daily_headers, 1):
    cell = daily_entry.cell(row=1, column=col_idx)
    cell.value = header
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_alignment
    cell.border = header_border
    # Set column width
    daily_entry.column_dimensions[get_column_letter(col_idx)].width = 20

# Set up branch-specific sheets with the same headers
for branch, sheet in branch_sheets.items():
    for col_idx, header in enumerate(daily_headers, 1):
        cell = sheet.cell(row=1, column=col_idx)
        cell.value = header
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = header_border
        # Set column width
        sheet.column_dimensions[get_column_letter(col_idx)].width = 20

# Add sample data to Daily Entry sheet
sample_data = [
    (datetime.datetime.now(), "Industrial", 5000, 7000, "=C2+D2", 3000, "=E2-F2", "محمد / Mohammed", ""),
    (datetime.datetime.now() - datetime.timedelta(days=1), "Fesah", 4500, 6500, "=C3+D3", 2800, "=E3-F3", "أحمد / Ahmed", ""),
    (datetime.datetime.now() - datetime.timedelta(days=2), "Omaq", 5200, 7200, "=C4+D4", 3200, "=E4-F4", "فاطمة / Fatima", ""),
    (datetime.datetime.now() - datetime.timedelta(days=3), "Industrial", 4800, 6800, "=C5+D5", 2900, "=E5-F5", "سارة / Sara", ""),
    (datetime.datetime.now() - datetime.timedelta(days=4), "Fesah", 5100, 7100, "=C6+D6", 3100, "=E6-F6", "خالد / Khalid", "")
]

for row_idx, data_row in enumerate(sample_data, 2):
    for col_idx, value in enumerate(data_row, 1):
        cell = daily_entry.cell(row=row_idx, column=col_idx)
        cell.value = value
        cell.font = data_font
        cell.alignment = data_alignment
        cell.border = data_border
        
        # Apply number formatting for monetary values
        if col_idx in [3, 4, 5, 6, 7]:  # Cash, Visa, Revenue, Expenses, Profit
            cell.number_format = '#,##0.00 [$﷼]'
        elif col_idx == 1:  # Date
            cell.number_format = 'yyyy-mm-dd'

# Add sample data to branch sheets
for branch, sheet in branch_sheets.items():
    branch_data = [row for row in sample_data if row[1] == branch]
    
    for row_idx, data_row in enumerate(branch_data, 2):
        for col_idx, value in enumerate(data_row, 1):
            if col_idx != 2:  # Skip branch column for branch-specific sheets
                cell = sheet.cell(row=row_idx, column=col_idx)
                cell.value = value
                cell.font = data_font
                cell.alignment = data_alignment
                cell.border = data_border
                
                # Apply number formatting for monetary values
                if col_idx in [3, 4, 5, 6, 7]:  # Cash, Visa, Revenue, Expenses, Profit
                    cell.number_format = '#,##0.00 [$﷼]'
                elif col_idx == 1:  # Date
                    cell.number_format = 'yyyy-mm-dd'

# Add totals row to Daily Entry sheet
total_row = len(sample_data) + 2
daily_entry.cell(row=total_row, column=1).value = "المجموع / Total"
daily_entry.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
daily_entry.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')

# Add sum formulas for numeric columns
daily_entry.cell(row=total_row, column=3).value = f"=SUM(C2:C{total_row-1})"  # Cash Sales
daily_entry.cell(row=total_row, column=4).value = f"=SUM(D2:D{total_row-1})"  # Visa Sales
daily_entry.cell(row=total_row, column=5).value = f"=SUM(E2:E{total_row-1})"  # Total Revenue
daily_entry.cell(row=total_row, column=6).value = f"=SUM(F2:F{total_row-1})"  # Expenses
daily_entry.cell(row=total_row, column=7).value = f"=SUM(G2:G{total_row-1})"  # Daily Profit

# Format the totals row
for col in range(1, len(daily_headers) + 1):
    cell = daily_entry.cell(row=total_row, column=col)
    cell.font = Font(name='Arial', size=12, bold=True)
    cell.border = Border(
        left=Side(style='thin', color='000000'),
        right=Side(style='thin', color='000000'),
        top=Side(style='thin', color='000000'),
        bottom=Side(style='double', color='000000')
    )
    
    # Apply number formatting for monetary values in totals row
    if col in [3, 4, 5, 6, 7]:  # Cash, Visa, Revenue, Expenses, Profit
        cell.number_format = '#,##0.00 [$﷼]'

# Add similar totals to branch sheets
for branch, sheet in branch_sheets.items():
    branch_data = [row for row in sample_data if row[1] == branch]
    total_row = len(branch_data) + 2
    
    sheet.cell(row=total_row, column=1).value = "المجموع / Total"
    sheet.cell(row=total_row, column=1).font = Font(name='Arial', size=12, bold=True)
    sheet.cell(row=total_row, column=1).alignment = Alignment(horizontal='center', vertical='center')
    
    # Add sum formulas for numeric columns
    sheet.cell(row=total_row, column=3).value = f"=SUM(C2:C{total_row-1})"  # Cash Sales
    sheet.cell(row=total_row, column=4).value = f"=SUM(D2:D{total_row-1})"  # Visa Sales
    sheet.cell(row=total_row, column=5).value = f"=SUM(E2:E{total_row-1})"  # Total Revenue
    sheet.cell(row=total_row, column=6).value = f"=SUM(F2:F{total_row-1})"  # Expenses
    sheet.cell(row=total_row, column=7).value = f"=SUM(G2:G{total_row-1})"  # Daily Profit
    
    # Format the totals row
    for col in range(1, len(daily_headers) + 1):
        cell = sheet.cell(row=total_row, column=col)
        cell.font = Font(name='Arial', size=12, bold=True)
        cell.border = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='double', color='000000')
        )
        
        # Apply number formatting for monetary values in totals row
        if col in [3, 4, 5, 6, 7]:  # Cash, Visa, Revenue, Expenses, Profit
            cell.number_format = '#,##0.00 [$﷼]'

# Save the workbook
wb.save(output_file)

print(f"Fixed supermarket system created and saved to {output_file}")
print("The file includes:")
print("1. Daily Entry sheet with sample data and totals")
print("2. Branch-specific sheets (Industrial, Fesah, Omaq) with relevant data")
print("3. Automatic calculations for Total Revenue and Daily Profit")
print("4. Formatted cells for better readability")
print("5. Proper number formatting for monetary values and dates")
